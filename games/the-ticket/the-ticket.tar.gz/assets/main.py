# -*- coding: utf-8 -*-
"""THE TICKET - Chuong 1 toi Chuong 3.

Pixel game 320x180, phong to len 1280x720 (nearest). Hinh va am thanh
deu tao bang code, khong can file asset.
"""
import os
import sys
import math
import random
import webbrowser
import asyncio
import array

import pygame

FEEDBACK_URL = "https://thcphm.github.io/xuong-cua-thuc/?gopy=the-ticket#game"

W, H = 320, 180
SCALE = 4
WIN_W, WIN_H = W * SCALE, H * SCALE
FPS = 60
SR = 22050
# khung hinh gan cho canh ngoai troi: 1 pixel ve = 6 pixel man hinh (thay vi 4)
OUT_ZOOM = 6
OUT_VW, OUT_VH = 214, 120

WEB = sys.platform == "emscripten"
WEB_FONTS = {"segoeui.ttf": "BeVietnamPro-Regular.ttf", "segoeuii.ttf": "BeVietnamPro-Italic.ttf",
             "segoeuib.ttf": "BeVietnamPro-Bold.ttf", "segoeuil.ttf": "BeVietnamPro-Light.ttf",
             "consola.ttf": "IBMPlexMono-Regular.ttf", "consolab.ttf": "IBMPlexMono-Bold.ttf"}
FONT_DIR = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
SOUND_NAMES = ["blip", "key1", "key2", "key3", "alarm", "buzz", "ok", "click",
               "door", "hiss", "rain", "engine", "music", "phone", "ding",
               "ringtone", "bite", "birds", "marble", "can", "slap", "thud", "tick", "paper",
               "catch", "stream", "cicada", "wind", "village", "raintin", "piano", "clink", "laugh"]


def resource_path(rel):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


# ---------------------------------------------------------------- helpers
def hexc(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def lerp(a, b, t):
    return a + (b - a) * t


def lerpc(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


def clamp(v, a, b):
    return max(a, min(b, v))


def vgrad(surf, rect, c1, c2, bands=24):
    x, y, w, h = rect
    for i in range(h):
        t = i / max(1, h - 1)
        t = round(t * bands) / bands
        pygame.draw.line(surf, lerpc(c1, c2, t), (x, y + i), (x + w - 1, y + i))


def make_glow(radius, color, steps=10):
    s = pygame.Surface((radius * 2, radius * 2))
    s.fill((0, 0, 0))
    for i in range(steps, 0, -1):
        r = int(radius * i / steps)
        k = (1 - i / steps) ** 1.6
        c = tuple(min(255, int(ch * k)) for ch in color)
        pygame.draw.circle(s, c, (radius, radius), r)
    return s


def make_cone(w_top, w_bot, h, color):
    s = pygame.Surface((w_bot, h))
    s.fill((0, 0, 0))
    for y in range(h):
        t = y / h
        ww = int(lerp(w_top, w_bot, t))
        k = (1 - t) ** 1.3 * 0.55
        c = tuple(int(ch * k) for ch in color)
        x0 = (w_bot - ww) // 2
        pygame.draw.line(s, c, (x0, y), (x0 + ww, y))
    return s


def add_glow(c, glow, cx, cy, k=1.0):
    if k <= 0.01:
        return
    g = glow
    if k < 0.99:
        g = glow.copy()
        v = int(255 * k)
        g.fill((v, v, v), special_flags=pygame.BLEND_MULT)
    c.blit(g, (int(cx - g.get_width() / 2), int(cy - g.get_height() / 2)),
           special_flags=pygame.BLEND_ADD)


# 3x5 pixel font cho dong ho, bien bao...
GLYPH = {
    "0": ["111", "101", "101", "101", "111"], "1": ["010", "110", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"], "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"], "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"], "7": ["111", "001", "010", "010", "010"],
    "8": ["111", "101", "111", "101", "111"], "9": ["111", "101", "111", "001", "111"],
    ":": ["0", "1", "0", "1", "0"], " ": ["00", "00", "00", "00", "00"],
    "B": ["110", "101", "110", "101", "110"], "U": ["101", "101", "101", "101", "111"],
    "S": ["111", "100", "111", "001", "111"], "O": ["111", "101", "101", "101", "111"],
    "K": ["101", "101", "110", "101", "101"], "E": ["111", "100", "110", "100", "111"],
    "R": ["110", "101", "110", "101", "101"], "X": ["101", "101", "010", "101", "101"],
    "I": ["111", "010", "010", "010", "111"], "T": ["111", "010", "010", "010", "010"],
    "C": ["111", "100", "100", "100", "111"], "A": ["111", "101", "111", "101", "101"],
    "P": ["111", "101", "111", "100", "100"], "N": ["101", "111", "111", "101", "101"],
    "H": ["101", "101", "111", "101", "101"], "-": ["000", "000", "111", "000", "000"],
    "G": ["111", "100", "101", "101", "111"], "L": ["100", "100", "100", "100", "111"],
    "M": ["101", "111", "111", "101", "101"], "D": ["110", "101", "101", "101", "110"],
    "Y": ["101", "101", "010", "010", "010"], "V": ["101", "101", "101", "101", "010"],
    "F": ["111", "100", "110", "100", "100"], "W": ["101", "101", "111", "111", "101"],
}


def draw_text_px(surf, text, x, y, col):
    for ch in text:
        g = GLYPH.get(ch.upper())
        if g is None:
            x += 4
            continue
        for j, row in enumerate(g):
            for i, v in enumerate(row):
                if v == "1":
                    surf.set_at((x + i, y + j), col)
        x += len(g[0]) + 1
    return x


def text_px_width(text):
    return sum(len(GLYPH.get(ch.upper(), ["000"])[0]) + 1 for ch in text) - 1


def fmt_time(minutes):
    m = int(minutes) % (24 * 60)
    return "%02d:%02d" % (m // 60, m % 60)


# ---------------------------------------------------------------- sprites
# Nhan vat kieu chibi: dau to 16x14, 2 mat, long may, ma hong, mieng cuoi.
# Chieu cao tong giu nguyen (nguoi lon 28, tre em 21) de khong lech cac canh cu.
HEAD_M = [
    "....hhhhhhhh....",
    "..hhhHHHHHhhhh..",
    ".hhhHHhhhhhhhhh.",
    ".hhhhhhhhhhhhhh.",
    ".hhhhhhshhhshhh.",
    ".hhhsssshhsshhs.",
    ".hhSssgggsgggss.",
    ".sSsssgegggegss.",
    ".sSsssgegsgegss.",
    ".sSsccgggsgggcs.",
    "..Sssssmmmsssss.",
    "..SSsssssssssss.",
    "...SSSsssssss...",
    ".....SSsssss....",
]
HEAD_F = [
    "....hhhhhhhh....",
    "..hhhHHHHHhhhh..",
    ".hhhHHhhhhhhhhh.",
    "hhhhhhhhhhhhhhh.",
    "hhhhhhhshhhshhh.",
    "hhhhsshhsshhssh.",
    "hhhSssgggsgggsh.",
    "hhhSssgegggegsh.",
    "hhhSssgegsgegsh.",
    "hhhScsgggsgggch.",
    "hhhSsssmmmssshh.",
    "hhhSSsssssssshh.",
    "hhh.SSSsssss.hh.",
    "hh...SSsss...hh.",
]
HEAD_BUN = [
    ".hhh.hhhhhhh....",
    "hhhhhhHHHHhhhh..",
    "hhhhHHhhhhhhhhh.",
    ".hhhhhhhhhhhhhh.",
    ".hhhhhhshhhshhh.",
    ".hhhsssshhsshhs.",
    ".hhSssgggsgggss.",
    ".sSsssgegggegss.",
    ".sSsssgegsgegss.",
    ".sSsccgggsgggcs.",
    "..Sssssmmmsssss.",
    "..SSsssssssssss.",
    "...SSSsssssss...",
    ".....SSsssss....",
]
HEAD_KID = HEAD_M[:3] + HEAD_M[4:]
HEAD_KID_F = HEAD_F[:3] + HEAD_F[4:]
BODY_M = [
    "....wwwwwwww....",
    "...bwwwwwwwwWw..",
    "..bBwwwwwwwwWww.",
    "..bBwwwwwwwwWww.",
    "..bBwwwwwwwwWww.",
    "..ssWwwwwwwwWss.",
    "....pppppppp....",
]
BODY_F = [
    "hh..wwwwwwww.hh.",
    "hh.wwwwwwwwwWhh.",
    "..wwwwwwwwwwWww.",
    "..wwwwwwwwwwWww.",
    "..wwwwwwwwwwWww.",
    "..ssWwwwwwwwWss.",
    "....pppppppp....",
]
BODY_TYPE = [
    [
        "....wwwwwwww....",
        "...bwwwwwwwwWW..",
        "..bBwwwwwwwwwWW.",
        "..bBwwwwwwwwwwWs",
        "..bBwwwwwwwww...",
        "...bwwwwwwww....",
        "....pppppppp....",
    ],
    [
        "....wwwwwwww....",
        "...bwwwwwwwwWW..",
        "..bBwwwwwwwwwWW.",
        "..bBwwwwwwwwwwW.",
        "..bBwwwwwwwww..s",
        "...bwwwwwwww....",
        "....pppppppp....",
    ],
]
LEGS_STAND = [
    "....ppppPppp....",
    "....pppPPppp....",
    "....ppp..ppp....",
    "....ppp..ppp....",
    "....PPp..PPp....",
    "....ooo..ooo....",
    "....oooo.oooo...",
]
LEGS_WALK_A = [
    "....ppppPppp....",
    "...ppp..Pppp....",
    "...pp....ppp....",
    "..ppP.....ppp...",
    "..pP......PPp...",
    ".oo........ooo..",
    ".ooo.......oooo.",
]
LEGS_WALK_B = [
    "....ppppPppp....",
    ".....ppPPpp.....",
    "......pppp......",
    "......pPpp......",
    "......pPPp......",
    "......oooo......",
    "......ooooo.....",
]
LEGS_SIT = [
    "....pppppppppp..",
    "....PPPPPPPppp..",
    "...........ooo..",
]

OUTLINE = (26, 30, 44)
FACE_DEFAULT = {"m": "#8a3a38", "c": "#f2a98f", "T": "#8fd0f0"}


def apply_expr(head, expr):
    """Doi net mat: neutral, smile, sad, cross, surprise, shut, wet (rung rung), tear."""
    rows = [list(r) for r in head]
    eye = [i for i, r in enumerate(rows) if "e" in r]
    mou = [i for i, r in enumerate(rows) if "m" in r]
    if not eye or not mou:
        return head
    e0, e1, m = eye[0], eye[-1], mou[0]
    c0 = rows[m].index("m")
    cols = [i for i, ch in enumerate(rows[e0]) if ch == "e"]
    fill = rows[m][c0 - 1]
    for y, x in ((m, c0), (m, c0 + 1), (m, c0 + 2)):
        rows[y][x] = fill
    shapes = {"smile": ((m, c0), (m, c0 + 2), (m + 1, c0 + 1)),
              "neutral": ((m, c0), (m, c0 + 1)), "cross": ((m, c0), (m, c0 + 1), (m, c0 + 2)),
              "sad": ((m, c0 + 1), (m + 1, c0), (m + 1, c0 + 2)), "tear": ((m, c0 + 1), (m + 1, c0), (m + 1, c0 + 2)),
              "wet": ((m, c0), (m, c0 + 1)), "shut": ((m, c0), (m, c0 + 1)),
              "wink": ((m, c0), (m, c0 + 2), (m + 1, c0 + 1)),
              "surprise": ((m, c0), (m, c0 + 1), (m + 1, c0), (m + 1, c0 + 1))}
    for y, x in shapes[expr]:
        rows[y][x] = "m"
    if expr in ("sad", "tear", "wet"):  # mi sup xuong
        for c in cols:
            rows[e0][c] = "g"
    if expr == "shut":
        for c in cols:
            rows[e0][c] = "g"
            rows[e1][c - 1] = rows[e1][c + 1] = "e"
    if expr == "wink":
        c = cols[0]
        rows[e0][c] = "g"
        rows[e1][c - 1] = rows[e1][c + 1] = "e"
    b = e0 - 1
    if expr in ("sad", "tear", "wet"):  # long may xech len o giua
        rows[b][cols[0] - 1] = rows[b][cols[1] + 1] = "h"
    if expr == "cross":  # cau may
        rows[b][cols[0] + 1] = rows[b][cols[1] - 1] = "h"
    if expr in ("wet", "tear"):
        for c in cols:
            rows[e1 + 1][c] = "T"
    if expr == "tear":
        rows[e1 + 2][cols[0]] = "T"
    return ["".join(r) for r in rows]

PAL_ME = {
    "h": "#33272a", "H": "#55403a", "s": "#f1c6a3", "S": "#cf977a", "g": "#7a8498",
    "e": "#2a2230", "w": "#d4e3ee", "W": "#9cb4ca", "b": "#7e6b4c", "B": "#5f4f38",
    "p": "#3c4662", "P": "#2a3149", "o": "#2a2230",
}
PAL_LAN = dict(PAL_ME, g="#f1c6a3", h="#4a2c2c", H="#6e423a", w="#e9b8b0", W="#c98f8a",
               p="#4b4560", P="#363148")
HEAD_OLD = [
    ".....ssssss.....",
    "...ssHHssssss...",
    "..hssssssssssh..",
    ".hhsssssssssshh.",
    ".hhsssssssssshh.",
    ".hhssshhsshhsss.",
    ".hSsssgggsgggss.",
    ".sSsssgegggegss.",
    ".sSsssgegsgegss.",
    ".sSsccgggsgggcs.",
    "..Sshhhmmmhhhs..",
    "..Shhhhhhhhhhh..",
    "...hhhhhhhhhh...",
    ".....hhhhhh.....",
]
PAL_OLD = dict(PAL_ME, h="#d9d5cc", H="#f2efe8", s="#dfb48f", S="#b88a68", w="#8b7a60",
               W="#6d5e48", b="#8b7a60", B="#6d5e48", p="#4e4a46", P="#3a3734",
               g="#7a8498", e="#2a2230")
PAL_DRIVER = dict(PAL_ME, h="#2a2426", H="#2a2426", w="#5a7fb0", W="#46668f", b="#5a7fb0",
                  B="#46668f", g="#f1c6a3", p="#2f3a52", P="#232c40")
PASSENGERS = [
    (dict(PAL_ME, h="#6b3b2a", H="#8a5240", w="#f0d68a", W="#c9ad62", p="#3d3a4a",
          P="#2b2936", g="#f1c6a3"), True),
    (dict(PAL_ME, h="#1f1d24", H="#3a3540", w="#6a6f86", W="#50546a", b="#6a6f86",
          B="#50546a", p="#2e3448", P="#222737", g="#f1c6a3", s="#e3b28c", S="#c08e6c"), False),
    (dict(PAL_ME, h="#2b2024", H="#4a3a3e", w="#f2f0ea", W="#c9c6be", b="#c4544a",
          B="#9a3f37", p="#24365e", P="#1a2746"), False),
    (dict(PAL_ME, h="#3a2420", H="#5c3a30", w="#7aa4c4", W="#5b84a3", p="#5b5248",
          P="#433c35", g="#f1c6a3", s="#f3cfb0", S="#d6a487"), True),
    (dict(PAL_ME, h="#141216", H="#2c2830", w="#e2873f", W="#b96a2c", b="#e2873f",
          B="#b96a2c", p="#3a4152", P="#2a3040", g="#f1c6a3", s="#d9a57f", S="#b78462"), False),
    (dict(PAL_ME, h="#5a3a2a", H="#7a5240", w="#a98fc4", W="#8670a3", p="#383444",
          P="#28252f", g="#f1c6a3"), True),
    (dict(PAL_ME, h="#222222", H="#444444", w="#9fbf8f", W="#7d9c6e", b="#9fbf8f", B="#7d9c6e",
          p="#4a4038", P="#352e28", g="#f1c6a3"), False),
]
PAL_TUAN = dict(PAL_ME, h="#1f1d24", H="#3a3540", w="#a9c9a0", W="#7fa178",
                b="#a9c9a0", B="#7fa178", p="#5b5248", P="#433c35", g="#f1c6a3")


def make_sprite(rows, pal):
    w = max(len(r) for r in rows)
    h = len(rows)
    s = pygame.Surface((w + 2, h + 2), pygame.SRCALPHA)
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            col = pal.get(ch) or (FACE_DEFAULT.get(ch) if ch in FACE_DEFAULT else None)
            if col:
                s.set_at((x + 1, y + 1), hexc(col))
    # vien toi 1px cho ro net kieu 16-bit
    m = pygame.mask.from_surface(s)
    out = s.copy()
    for y in range(h + 2):
        for x in range(w + 2):
            if m.get_at((x, y)):
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w + 2 and 0 <= ny < h + 2 and m.get_at((nx, ny)):
                    out.set_at((x, y), OUTLINE)
                    break
    return out


def build_char(pal, female=False, head_rows=None, expr="neutral"):
    head = apply_expr(head_rows or (HEAD_F if female else HEAD_M), expr)
    body = BODY_F if female else BODY_M
    return {
        "idle": make_sprite(head + body + LEGS_STAND, pal),
        "walk": [make_sprite(head + body + LEGS_WALK_A, pal),
                 make_sprite(head + body + LEGS_STAND, pal),
                 make_sprite(head + body + LEGS_WALK_B, pal),
                 make_sprite(head + body + LEGS_STAND, pal)],
        "sit": make_sprite(head + body + LEGS_SIT, pal),
        "type": [make_sprite(head + b + LEGS_SIT, pal) for b in BODY_TYPE],
    }


class Actor:
    def __init__(self, x, pal, female=False, facing=1, state="idle", head=None, expr="neutral"):
        self.x = float(x)
        self.pal = pal
        self.facing = facing
        self.state = state
        self.anim = 0.0
        self.visible = True
        self.female = female
        self.head = head
        self.expr = expr
        self.cache = {}
        self.spr = self.sprites(expr)

    def make(self, expr):
        return build_char(self.pal, self.female, self.head, expr)

    def sprites(self, expr):
        if expr not in self.cache:
            self.cache[expr] = self.make(expr)
        return self.cache[expr]

    def set_expr(self, expr):
        self.expr = expr
        self.spr = self.sprites(expr)
        return self

    def update(self, dt):
        if self.state == "walk":
            self.anim += dt * 7
        elif self.state == "type":
            self.anim += dt * 7 * (0.5 + random.random())
        else:
            self.anim += dt

    def draw(self, c, floor_y):
        if not self.visible:
            return
        if self.state == "walk":
            img = self.spr["walk"][int(self.anim) % 4]
        elif self.state == "sleep":
            img = self.sprites("shut")["sit"]
        elif self.state == "sit":
            img = self.spr["sit"]
        elif self.state == "type":
            img = self.spr["type"][int(self.anim) % 2]
        else:
            img = self.spr["idle"]
            # tho nhe
        if self.facing < 0:
            img = pygame.transform.flip(img, True, False)
        bob = 0
        if self.state == "walk" and int(self.anim) % 2 == 1:
            bob = -1
        c.blit(img, (int(self.x) - img.get_width() // 2, floor_y - img.get_height() + 1 + bob))


def make_ticket():
    s = pygame.Surface((72, 32), pygame.SRCALPHA)
    cream = (243, 230, 196)
    edge = (186, 156, 116)
    red = (196, 84, 74)
    pygame.draw.rect(s, edge, (0, 0, 72, 32), border_radius=3)
    pygame.draw.rect(s, cream, (1, 1, 70, 30), border_radius=3)
    for cy in (0, 31):
        pygame.draw.circle(s, (0, 0, 0, 0), (52, cy), 3)
    for y in range(5, 28, 3):
        s.set_at((52, y), edge)
    s.fill(red, (4, 4, 45, 8))
    draw_text_px(s, "BUS TICKET", 6, 5, cream)
    tmp = pygame.Surface((18, 5), pygame.SRCALPHA)
    draw_text_px(tmp, "11:11", 0, 0, (70, 52, 46))
    s.blit(pygame.transform.scale(tmp, (36, 10)), (9, 16))
    pygame.draw.circle(s, red, (62, 16), 6, 1)
    draw_text_px(s, "11", 59, 14, red)
    for x in range(5, 48, 2):
        s.set_at((x, 28), edge)
    return s


def make_app_icon():
    """Icon tam ve 32x32 cho cua so va file exe."""
    s = pygame.Surface((32, 32), pygame.SRCALPHA)
    ink = hexc("#2a2230")
    paper = hexc("#f3e6c4")
    red = hexc("#c8483c")
    pygame.draw.rect(s, ink, (1, 7, 30, 19), border_radius=2)
    pygame.draw.rect(s, paper, (2, 8, 28, 17), border_radius=2)
    s.fill(red, (3, 9, 18, 5))
    s.fill(hexc("#e8796c"), (3, 9, 18, 1))
    for y in range(9, 25, 2):
        s.set_at((22, y), hexc("#9a7a55"))
    for cy in (7, 25):
        pygame.draw.circle(s, (0, 0, 0, 0), (22, cy), 2)
        s.set_at((20, cy), ink)
        s.set_at((24, cy), ink)
    draw_text_px(s, "11:11", 4, 17, hexc("#46342e"))
    pygame.draw.circle(s, red, (26, 16), 3, 1)
    s.set_at((26, 16), red)
    return s


# ---------------------------------------------------------------- audio
def mf(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


class Audio:
    def __init__(self):
        self.ok = False
        self.s = {}
        self.master = 1.0
        self.muted = False
        self.ch_vol = {}
        try:
            pygame.mixer.init(SR, -16, 2, 512)
            pygame.mixer.set_num_channels(16)
            pygame.mixer.set_reserved(4)
            self.ok = True
        except Exception:
            return
        for name in SOUND_NAMES:
            path = resource_path(os.path.join("sfx", name + (".ogg" if WEB else ".wav")))
            try:
                if os.path.exists(path):
                    self.s[name] = pygame.mixer.Sound(path)
                    continue
            except Exception:
                pass
            self.s[name] = self.mk(self.generate(name))

    def generate(self, name):
        rnd = random.Random(sum(map(ord, name)))
        if name == "blip":
            return self.tone(660, 0.03, 0.10, decay=60)
        if name == "key1":
            return self.noise(0.025, 0.35, 140, 0.6, rnd)
        if name == "key2":
            return self.noise(0.02, 0.30, 160, 0.8, rnd)
        if name == "key3":
            return self.noise(0.03, 0.30, 120, 0.5, rnd)
        if name == "alarm":
            out = []
            for i in range(6):
                out += self.tone(880 if i % 2 == 0 else 660, 0.16, 0.18, wave="square", decay=3)
                out += [0.0] * int(SR * 0.04)
            return out
        if name == "buzz":
            out = []
            for i in range(2):
                out += self.tone(140, 0.22, 0.35, wave="square", decay=1)
                out += [0.0] * int(SR * 0.12)
            return self.lowpass(out, 0.25)
        if name == "ok":
            return self.tone(784, 0.12, 0.15, decay=10) + self.tone(1046, 0.3, 0.15, decay=8)
        if name == "click":
            return self.noise(0.05, 0.6, 90, 0.4, rnd)
        if name == "door":
            return self.noise(0.35, 0.45, 9, 0.08, rnd)
        if name == "hiss":
            return self.noise(1.0, 0.35, 3.5, 0.5, rnd)
        if name == "rain":
            return self.loop_noise(4.0, 0.16, 0.22, rnd)
        if name == "engine":
            return self.engine(3.0, rnd)
        if name == "music":
            return self.music()
        if name == "ding":
            a = self.tone(988, 0.5, 0.22, decay=4)
            b = self.tone(784, 1.0, 0.22, decay=3)
            out = a[:int(SR * 0.35)] + [0.0] * 0
            return [x for x in out] + b
        if name == "phone":
            return self.phone(rnd)
        if name == "ringtone":
            out = []
            for m in (76, 79, 84, 79, 76, 79, 84, 88):
                f = mf(m)
                seg = self.tone(f, 0.16, 0.22, decay=11)
                seg2 = self.tone(f * 4, 0.16, 0.05, decay=30)
                out += [a + b for a, b in zip(seg, seg2)]
            out += [0.0] * int(SR * 0.5)
            return out
        if name == "bite":
            return self.noise(0.06, 0.55, 45, 0.7, rnd) + self.noise(0.08, 0.45, 40, 0.6, rnd)
        if name == "birds":
            n = int(SR * 5.0)
            out = [0.0] * n
            t = 0.2
            while t < 4.6:
                f0 = rnd.uniform(2600, 3800)
                for k in range(rnd.randint(2, 4)):
                    i0 = int((t + k * 0.09) * SR)
                    L = int(SR * 0.05)
                    for i in range(L):
                        tt = i / SR
                        f = f0 + 1800 * tt / 0.05
                        e = math.sin(math.pi * i / L)
                        if i0 + i < n:
                            out[i0 + i] += math.sin(2 * math.pi * f * tt) * e * 0.05
                t += rnd.uniform(0.6, 1.4)
            y = 0.0
            for i in range(n):
                y += 0.02 * (rnd.uniform(-1, 1) - y)
                out[i] += y * 0.25
            return out
        if name == "marble":
            a = self.tone(2350, 0.05, 0.3, decay=70)
            b = self.tone(3400, 0.05, 0.16, decay=90)
            return [x + y for x, y in zip(a, b)]
        if name == "can":
            out = None
            for f, v in ((1480, 0.16), (2210, 0.13), (3120, 0.1), (4400, 0.06)):
                t = self.tone(f, 0.28, v, decay=16)
                out = t if out is None else [x + y for x, y in zip(out, t)]
            return out
        if name == "slap":
            return self.noise(0.14, 0.4, 16, 0.25, rnd)
        if name == "thud":
            return self.lowpass(self.tone(92, 0.14, 0.6, decay=26), 0.4)
        if name == "tick":
            return self.noise(0.04, 0.6, 90, 0.35, rnd)
        if name == "paper":
            out = []
            for k in range(7):
                out += self.noise(rnd.uniform(0.02, 0.05), 0.4, 30, 0.75, rnd)
            return out
        if name == "catch":
            a = self.lowpass(self.tone(320, 0.08, 0.5, decay=40), 0.5)
            return a + self.lowpass(self.tone(250, 0.09, 0.35, decay=40), 0.5)
        if name == "stream":
            base = self.loop_noise(5.0, 0.13, 0.32, rnd)
            n = len(base)
            t = 0.1
            while t < 4.3:
                f = rnd.uniform(500, 1300)
                L = int(SR * rnd.uniform(0.03, 0.08))
                i0 = int(t * SR)
                for i in range(L):
                    if i0 + i < n:
                        base[i0 + i] += math.sin(2 * math.pi * (f + 900 * i / L) * i / SR) * math.sin(math.pi * i / L) * 0.05
                t += rnd.uniform(0.05, 0.28)
            return base
        if name == "cicada":
            n = int(SR * 4.0)
            out = [0.0] * n
            y = 0.0
            for i in range(n):
                t = i / SR
                y += 0.8 * (rnd.uniform(-1, 1) - y)
                env = 0.6 + 0.4 * math.sin(2 * math.pi * 0.25 * t)
                am = 0.5 + 0.5 * math.sin(2 * math.pi * 62 * t)
                out[i] = math.sin(2 * math.pi * 4300 * t) * y * am * env * 0.11
            return out
        if name == "wind":
            base = self.loop_noise(6.0, 0.2, 0.05, rnd)
            n = len(base)
            return [v * (0.6 + 0.4 * math.sin(2 * math.pi * i / n)) for i, v in enumerate(base)]
        if name == "village":
            return self.village()
        if name == "raintin":
            base = self.loop_noise(5.0, 0.2, 0.7, rnd)
            n = len(base)
            for _ in range(900):
                i0 = rnd.randrange(0, n - 300)
                v = rnd.uniform(0.05, 0.16)
                f = rnd.uniform(1800, 3600)
                for i in range(240):
                    base[i0 + i] += math.sin(2 * math.pi * f * i / SR) * math.exp(-i / 50.0) * v
            return self.lowpass(base, 0.8)
        if name == "piano":
            return self.piano()
        if name == "laugh":  # vai dua tre cuoi lech nhau
            total = int(SR * 1.1)
            out = [0.0] * total
            for v, (start, f0) in enumerate(((0.0, 560), (0.07, 690), (0.16, 480))):
                t0 = start
                for k in range(5):
                    n = int(SR * 0.085)
                    f = f0 - k * 14 + rnd.uniform(-20, 20)
                    i0 = int(t0 * SR)
                    for i in range(n):
                        t = i / SR
                        e = math.sin(math.pi * i / n)
                        val = math.sin(2 * math.pi * f * t + 0.9 * math.sin(2 * math.pi * 2.4 * f * t))
                        if i0 + i < total:
                            out[i0 + i] += val * e * 0.12
                    t0 += 0.085 + 0.05
            return self.lowpass(out, 0.5)
        if name == "clink":
            a = self.tone(3100, 0.12, 0.2, decay=45)
            b = self.tone(4650, 0.12, 0.1, decay=60)
            return [x + y for x, y in zip(a, b)]
        return [0.0]

    # --- tao song
    def tone(self, f, dur, vol, wave="sine", decay=8.0, attack=0.004):
        n = int(SR * dur)
        out = [0.0] * n
        tp = 2 * math.pi
        for i in range(n):
            t = i / SR
            e = min(1.0, t / attack) * math.exp(-decay * t)
            ph = (f * t) % 1.0
            if wave == "square":
                v = 1.0 if ph < 0.5 else -1.0
            else:
                v = math.sin(tp * ph)
            out[i] = v * e * vol
        return out

    def noise(self, dur, vol, decay, lp, rnd):
        n = int(SR * dur)
        out = [0.0] * n
        y = 0.0
        for i in range(n):
            y += lp * (rnd.uniform(-1, 1) - y)
            out[i] = y * vol * math.exp(-decay * i / SR)
        return out

    def loop_noise(self, dur, vol, lp, rnd):
        n = int(SR * dur)
        out = [0.0] * n
        y = 0.0
        for i in range(n):
            y += lp * (rnd.uniform(-1, 1) - y)
            out[i] = y * vol
        fade = int(SR * 0.3)
        for i in range(fade):  # cross-fade cho vong lap muot
            k = i / fade
            out[i] = out[i] * k + out[n - fade + i] * (1 - k)
        return out[: n - fade]

    def lowpass(self, data, a):
        y = 0.0
        out = []
        for v in data:
            y += a * (v - y)
            out.append(y)
        return out

    def engine(self, dur, rnd):
        n = int(SR * dur)
        out = [0.0] * n
        y = 0.0
        for i in range(n):
            t = i / SR
            y += 0.05 * (rnd.uniform(-1, 1) - y)
            v = 0.5 * math.sin(2 * math.pi * 46 * t) + 0.3 * math.sin(2 * math.pi * 92 * t)
            v *= 0.6 + 0.4 * math.sin(2 * math.pi * 11 * t)
            out[i] = (v * 0.35 + y * 1.2) * 0.5
        return out

    def music(self):
        chord_len = 3.2
        chords = [[53, 57, 60, 64], [52, 55, 59, 62], [50, 53, 57, 60], [48, 52, 55, 59]]
        total = int(SR * chord_len * len(chords))
        buf = [0.0] * total
        tp = 2 * math.pi
        L = int(SR * chord_len * 1.2)
        for ci, ch in enumerate(chords):
            start = int(ci * chord_len * SR)
            for m in ch:
                f = mf(m)
                for i in range(0, L):
                    t = i / SR
                    e = min(1.0, t / 0.9) * min(1.0, (L - i) / (SR * 0.8))
                    v = math.sin(tp * f * t) + 0.25 * math.sin(tp * 2 * f * t + 0.7)
                    buf[(start + i) % total] += v * e * 0.03
            fb = mf(ch[0] - 12)
            for i in range(L):
                t = i / SR
                e = min(1.0, t / 0.2) * math.exp(-0.6 * t)
                buf[(start + i) % total] += math.sin(tp * fb * t) * e * 0.07
            # arpeggio nhe kieu piano dien
            pattern = [0, 2, 1, 3, 2, 1, 3, 2]
            step = chord_len / len(pattern)
            for k, idx in enumerate(pattern):
                if (ci + k) % 3 == 2:
                    continue
                f = mf(ch[idx] + 12)
                s0 = start + int(k * step * SR)
                n = int(SR * 1.1)
                for i in range(n):
                    t = i / SR
                    e = min(1.0, t / 0.005) * math.exp(-4.5 * t)
                    v = math.sin(tp * f * t) + 0.3 * math.sin(tp * 3 * f * t) * math.exp(-9 * t)
                    buf[(s0 + i) % total] += v * e * 0.035
        return self.lowpass(buf, 0.5)

    def village(self):
        # nhac lang que: ngu cung, tieng gay nhe (tu sang tac)
        step = 0.34
        melody = [67, 0, 69, 71, 74, 0, 71, 69, 67, 0, 64, 67, 69, 0, 0, 0,
                  71, 0, 74, 76, 74, 0, 71, 69, 71, 0, 67, 64, 62, 0, 0, 0,
                  67, 0, 69, 71, 74, 76, 74, 71, 69, 0, 71, 69, 67, 0, 64, 0,
                  62, 0, 64, 67, 69, 0, 67, 64, 67, 0, 0, 0, 0, 0, 0, 0]
        bass = [43, 40, 38, 43, 43, 40, 38, 43]
        total = int(SR * step * len(melody))
        buf = [0.0] * total
        tp = 2 * math.pi

        def pluck(m, at, vol, dec, n_s):
            f = mf(m)
            s0 = int(at * SR)
            n = int(SR * n_s)
            for i in range(n):
                t = i / SR
                e = min(1.0, t / 0.003) * math.exp(-dec * t)
                v = math.sin(tp * f * t) + 0.4 * math.sin(tp * 2 * f * t) * math.exp(-5 * t) + 0.18 * math.sin(tp * 3 * f * t) * math.exp(-9 * t)
                buf[(s0 + i) % total] += v * e * vol
        for k, m in enumerate(melody):
            if m:
                pluck(m + 12, k * step, 0.11, 3.2, 1.3)
        for k, m in enumerate(bass):
            at = k * step * 8
            pluck(m + 12, at, 0.13, 1.6, 2.2)
            pluck(m + 19, at + step * 4, 0.08, 2.0, 1.6)
        return self.lowpass(buf, 0.55)

    def piano(self):
        # piano cham cho bua com (tu sang tac)
        step = 0.5
        chords = [[53, 60, 65, 69], [50, 57, 62, 65], [46, 53, 58, 62], [48, 55, 60, 64]]
        melody = [77, 0, 76, 72, 74, 0, 0, 0, 74, 0, 72, 69, 70, 0, 0, 0,
                  70, 0, 69, 65, 67, 0, 69, 70, 72, 0, 0, 0, 0, 0, 0, 0]
        melody = melody + [72, 0, 74, 77, 76, 0, 72, 0, 74, 0, 77, 79, 77, 0, 0, 0,
                           70, 0, 72, 74, 72, 0, 69, 67, 65, 0, 0, 0, 0, 0, 0, 0]
        chords = chords + chords
        total = int(SR * step * 64)
        buf = [0.0] * total
        tp = 2 * math.pi

        def note(m, at, vol, n_s):
            f = mf(m)
            s0 = int(at * SR)
            for i in range(int(SR * n_s)):
                t = i / SR
                e = min(1.0, t / 0.006) * math.exp(-1.9 * t)
                v = math.sin(tp * f * t) + 0.32 * math.sin(tp * 2 * f * t) * math.exp(-3 * t) + 0.1 * math.sin(tp * 3 * f * t) * math.exp(-6 * t)
                buf[(s0 + i) % total] += v * e * vol
        for bar, ch in enumerate(chords):
            for k, idx in enumerate((0, 1, 2, 3, 2, 1, 2, 3)):
                note(ch[idx], (bar * 8 + k) * step, 0.05, 2.2)
        for k, m in enumerate(melody):
            if m:
                note(m, k * step, 0.09, 2.4)
        return self.lowpass(buf, 0.6)

    def phone(self, rnd):
        # video YouTube bat loa ngoai: nhac chip + giong noi lao xao, am thanh "re"
        n = int(SR * 3.0)
        out = [0.0] * n

        def put(seg, at):
            i0 = int(at * SR)
            for i, v in enumerate(seg):
                if 0 <= i0 + i < n:
                    out[i0 + i] += v
        notes = [72, 74, 76, 79, 81, 84, 79, 76]
        t = 0.0
        k = 0
        while t < 2.95:
            put(self.tone(mf(notes[(k * 3 + k // 4) % len(notes)]), 0.1, 0.07, "square", 14), t)
            if k % 2 == 0:
                put(self.tone(mf(48 + (k // 8) % 2 * 5), 0.2, 0.08, "square", 8), t)
            t += 0.125
            k += 1
        t = 0.05
        while t < 2.85:
            d = rnd.uniform(0.06, 0.15)
            put(self.tone(rnd.uniform(170, 330), d, 0.13, "square", 5), t)
            t += d + rnd.uniform(0.01, 0.07)
        prev = 0.0
        res = []
        for v in out:  # loc bot tram cho giong loa dien thoai
            res.append((v - prev * 0.85) * 0.9)
            prev = v
        return self.lowpass(res, 0.55)

    def mk(self, data):
        arr = array.array("h")
        for v in data:
            iv = int(clamp(v, -1.0, 1.0) * 32000)
            arr.append(iv)
            arr.append(iv)
        return pygame.mixer.Sound(buffer=arr.tobytes())

    # --- phat
    def play(self, name, vol=1.0):
        if not self.ok:
            return
        snd = self.s.get(name)
        if snd:
            ch = snd.play()
            if ch:
                ch.set_volume(vol * self.gain())

    def loop(self, ch, name, vol=1.0, fade=800):
        if not self.ok:
            return
        c = pygame.mixer.Channel(ch)
        self.ch_vol[ch] = vol
        c.set_volume(vol * self.gain())
        c.play(self.s[name], loops=-1, fade_ms=fade)

    def stop(self, ch, fade=800):
        if self.ok:
            pygame.mixer.Channel(ch).fadeout(fade)

    def ensure(self, ch, name, vol=1.0):
        """Chi bat vong lap neu kenh chua phat dung am thanh nay."""
        if not self.ok:
            return
        c = pygame.mixer.Channel(ch)
        if c.get_busy() and c.get_sound() is self.s.get(name):
            self.ch_vol[ch] = vol
            c.set_volume(vol * self.gain())
        else:
            self.loop(ch, name, vol, 600)

    def stop_all(self, fade=300):
        for ch in (CH_MUSIC, CH_AMB, CH_ENGINE, CH_PHONE):
            self.stop(ch, fade)

    def volume(self, ch, vol):
        self.ch_vol[ch] = vol
        if self.ok:
            pygame.mixer.Channel(ch).set_volume(vol * self.gain())

    def gain(self):
        return 0.0 if self.muted else self.master

    def apply(self, master=None, muted=None):
        """Doi am luong tong, ap dung ngay cho nhac nen dang phat."""
        if master is not None:
            self.master = clamp(master, 0.0, 1.0)
        if muted is not None:
            self.muted = muted
        if self.ok:
            for ch, vol in self.ch_vol.items():
                pygame.mixer.Channel(ch).set_volume(vol * self.gain())


CH_MUSIC, CH_AMB, CH_ENGINE, CH_PHONE = 0, 1, 2, 3


# ---------------------------------------------------------------- scenes
def gen_buildings(seed, x0, x1, base, hmin, hmax, wmin, wmax):
    rnd = random.Random(seed)
    out = []
    x = x0
    while x < x1:
        w = rnd.randint(wmin, wmax)
        h = rnd.randint(hmin, hmax)
        wins = []
        for wy in range(base - h + 4, base - 3, 5):
            for wx in range(x + 2, x + w - 3, 4):
                wins.append((wx, wy, rnd.random()))
        out.append((x, w, h, wins, rnd.random()))
        x += w + rnd.randint(0, 3)
    return out


def draw_birds(c, t, n=4):
    for k in range(n):
        x = int((k * 83 + t * (12 + k * 3)) % (W + 40)) - 20
        y = 20 + k * 9 + int(math.sin(t * 2 + k) * 2)
        up = int(t * 6 + k) % 2 == 0
        col = (70, 76, 100)
        c.set_at((x, y), col)
        c.set_at((x - 1, y - 1 if up else y + 1), col)
        c.set_at((x + 1, y - 1 if up else y + 1), col)
        c.set_at((x - 2, y - 1 if up else y), col)
        c.set_at((x + 2, y - 1 if up else y), col)


def draw_buildings(c, blds, base, col, lit, wcol, dcol, ox=0, period=0):
    for x0, w, h, wins, r in blds:
        x = x0 + ox
        if period:
            x = (x0 + ox) % period - 40
            if x > W or x + w < 0:
                continue
        dx = x - x0
        pygame.draw.rect(c, col, (x, base - h, w, h))
        if r > 0.6:  # ang ten / be nuoc tren noc
            pygame.draw.line(c, col, (x + w // 2, base - h), (x + w // 2, base - h - 5))
        for wx, wy, rv in wins:
            c.fill(wcol if rv < lit else dcol, (wx + dx, wy, 2, 2))


FLOOR = 150
WINDOWS = [(60, 18, 70, 72), (140, 18, 70, 72), (220, 18, 70, 72)]
DESKS = [58, 128, 206]


class Office:
    def __init__(self, game):
        self.g = game
        self.minutes = 17 * 60 + 30.0
        self.clock_run = True
        self.alarm = False
        self.fixed = False
        self.lights = True
        self.door_t = 0.0
        self.mon_on = [True, True, True]
        self.far = gen_buildings(11, 50, 300, 92, 24, 56, 10, 22)
        self.near = gen_buildings(12, 50, 300, 92, 10, 36, 14, 28)
        self.me = Actor(DESKS[2] - 4, PAL_ME, state="type")
        self.lan = Actor(DESKS[0] - 4, PAL_LAN, female=True, state="type")
        self.tuan = Actor(DESKS[1] - 4, PAL_TUAN, state="type")
        self.actors = [self.lan, self.tuan, self.me]
        self.glow_mon = make_glow(26, (90, 150, 210))
        self.glow_red = make_glow(30, (230, 60, 60))
        self.glow_green = make_glow(26, (80, 200, 120))
        self.glow_lamp = make_glow(30, (255, 190, 110))
        self.glow_ceil = make_glow(34, (230, 230, 210))
        self.glow_exit = make_glow(12, (60, 220, 120))
        self.glow_sun = make_glow(40, (255, 170, 90))
        self.time = 0.0
        rnd = random.Random(5)
        self.stars = [(rnd.randint(60, 290), rnd.randint(18, 60), rnd.random()) for _ in range(30)]
        self.seams = [(rnd.randint(0, W), y) for y in range(FLOOR + 4, H, 5) for _ in range(4)]

    @property
    def dark(self):
        return clamp((self.minutes - 1050) / (1380 - 1050), 0, 1)

    def update(self, dt):
        self.time += dt
        if self.clock_run:
            self.minutes += dt * 0.25
        self.door_t = max(0.0, self.door_t - dt)
        for a in self.actors:
            a.update(dt)

    def sky_colors(self):
        if self.minutes < 12 * 60:  # buoi sang
            return hexc("#8fc5e6"), hexc("#f1e8cf")
        t = self.dark
        keys = [
            (0.0, hexc("#7d84bd"), hexc("#f7b47c")),
            (0.25, hexc("#4b4a85"), hexc("#d7798a")),
            (0.5, hexc("#262a55"), hexc("#5b4a78")),
            (1.0, hexc("#10142c"), hexc("#262a52")),
        ]
        for i in range(len(keys) - 1):
            a, b = keys[i], keys[i + 1]
            if t <= b[0]:
                k = (t - a[0]) / (b[0] - a[0])
                return lerpc(a[1], b[1], k), lerpc(a[2], b[2], k)
        return keys[-1][1], keys[-1][2]

    def draw(self, c):
        t = self.dark
        top, bot = self.sky_colors()
        # ---- bau troi + thanh pho ngoai cua so
        for r in WINDOWS:
            c.set_clip(r)
            vgrad(c, (r[0], r[1], r[2], r[3]), top, bot)
            if t > 0.45:
                for sx, sy, sr in self.stars:
                    if sr < (t - 0.45) * 2:
                        tw = 0.6 + 0.4 * math.sin(self.time * 2 + sr * 30)
                        c.set_at((sx, sy), lerpc((60, 60, 90), (230, 230, 255), tw))
            if t < 0.5:
                sun_y = 70 + t * 70
                pygame.draw.circle(c, lerpc((255, 214, 150), (230, 120, 90), t * 2), (250, int(sun_y)), 9)
            if t > 0.7:
                pygame.draw.circle(c, (240, 232, 200), (98, 32), 6)
                pygame.draw.circle(c, top, (101, 30), 5)
            far_col = lerpc(hexc("#9a86a6"), hexc("#1d2241"), t * 1.3)
            near_col = lerpc(hexc("#776a8e"), hexc("#151931"), t * 1.3)
            lit = clamp((t - 0.15) * 0.9, 0, 0.55)
            draw_buildings(c, self.far, 92, far_col, lit * 0.8, (236, 198, 120), lerpc(far_col, (0, 0, 0), 0.25))
            draw_buildings(c, self.near, 92, near_col, lit, (250, 212, 130), lerpc(near_col, (0, 0, 0), 0.25))
            c.set_clip(None)
        # ---- tuong
        wall = hexc("#d9ccb2")
        c.fill(wall, (0, 0, W, 18))
        c.fill(wall, (0, 18, 60, 94))
        c.fill(wall, (130, 18, 10, 94))
        c.fill(wall, (210, 18, 10, 94))
        c.fill(wall, (290, 18, 30, 94))
        c.fill(wall, (60, 90, 230, 22))
        c.fill(hexc("#c5b593"), (0, 112, W, FLOOR - 112))
        c.fill(hexc("#a8987a"), (0, 112, W, 1))
        c.fill(hexc("#bba98a"), (0, 0, W, 6))
        c.fill(hexc("#a8987a"), (0, 6, W, 1))
        # khung cua so
        frame = hexc("#6d5a44")
        for x, y, w, h in WINDOWS:
            pygame.draw.rect(c, frame, (x - 2, y - 2, w + 4, h + 4), 2)
            c.fill(frame, (x + w // 2 - 1, y, 2, h))
            c.fill(frame, (x, y + 30, w, 1))
            c.fill(hexc("#8c7356"), (x - 4, y + h + 2, w + 8, 3))
            c.fill(hexc("#5d4c39"), (x - 4, y + h + 5, w + 8, 1))
            # rem cuon
            c.fill(hexc("#e8dfcc"), (x, y, w, 5))
            c.fill(hexc("#cfc3aa"), (x, y + 5, w, 1))
        # den tran
        for lx in (75, 155, 235):
            col = (250, 248, 232) if self.lights else (120, 118, 112)
            c.fill(hexc("#8f8778"), (lx - 1, 7, 42, 4))
            c.fill(col, (lx, 8, 40, 2))
        # cua ra vao
        c.fill(frame, (5, 101, 25, FLOOR - 101))
        if self.door_t > 0:
            c.fill(hexc("#2b2530"), (7, 103, 21, FLOOR - 103))
        else:
            c.fill(hexc("#9b7a58"), (7, 103, 21, FLOOR - 103))
            c.fill(hexc("#8a6b4c"), (10, 107, 15, 16))
            c.fill(hexc("#8a6b4c"), (10, 127, 15, 18))
            c.fill(hexc("#e6c66e"), (24, 126, 2, 2))
        # bien EXIT
        c.fill(hexc("#1f6e45"), (9, 93, 17, 7))
        draw_text_px(c, "EXIT", 10, 94, (200, 255, 210))
        # dong ho dien tu
        c.fill(hexc("#3a3236"), (32, 24, 25, 11))
        c.fill(hexc("#18151a"), (33, 25, 23, 9))
        draw_text_px(c, fmt_time(self.minutes), 35, 27, (255, 110, 90))
        # lich
        c.fill(hexc("#f5efe2"), (36, 52, 16, 18))
        c.fill(hexc("#c4544a"), (36, 52, 16, 5))
        draw_text_px(c, "30", 40, 60, (60, 50, 50))
        c.fill(hexc("#c4544a"), (39, 59, 10, 1))
        # bang trang
        c.fill(hexc("#a7a39b"), (294, 30, 24, 34))
        c.fill(hexc("#f4f3ee"), (295, 31, 22, 31))
        for i, ln in enumerate((14, 9, 17, 11)):
            c.fill(hexc("#5a7fb0") if i != 2 else hexc("#c4544a"), (298, 35 + i * 6, ln, 1))
        c.fill(hexc("#8f8b84"), (296, 64, 20, 1))
        # san go
        c.fill(hexc("#a27d59"), (0, FLOOR, W, H - FLOOR))
        c.fill(hexc("#6d5a44"), (0, FLOOR, W, 2))
        for y in range(FLOOR + 5, H, 5):
            c.fill(hexc("#8f6c4c"), (0, y, W, 1))
        for sx, sy in self.seams:
            c.fill(hexc("#8f6c4c"), (sx, sy, 1, 5))
        # tu ho so + cay
        c.fill(hexc("#8d96a0"), (264, 116, 24, FLOOR - 116))
        for i in range(3):
            c.fill(hexc("#737c86"), (266, 119 + i * 11, 20, 1))
            c.fill(hexc("#cfd4d8"), (273, 123 + i * 11, 6, 1))
        pot = hexc("#b56a45")
        c.fill(pot, (298, 138, 14, 12))
        c.fill(hexc("#94553a"), (297, 137, 16, 2))
        leaf = (hexc("#5f8a4a"), hexc("#7aa85a"), hexc("#4a6e3a"))
        for i, (lx, ly, lw) in enumerate(((300, 128, 4), (305, 122, 5), (309, 127, 4), (296, 132, 5),
                                           (308, 133, 5), (303, 116, 3), (299, 122, 4))):
            pygame.draw.ellipse(c, leaf[i % 3], (lx, ly, lw, 10))
        # ---- ban ghe + nguoi
        for i, dx in enumerate(DESKS):
            cx = dx - 4
            chair = hexc("#3b3a44")
            c.fill(chair, (cx - 9, FLOOR - 21, 3, 15))
            c.fill(chair, (cx - 8, FLOOR - 7, 13, 2))
            c.fill(hexc("#55535e"), (cx - 2, FLOOR - 5, 2, 4))
            c.fill(chair, (cx - 6, FLOOR - 2, 10, 1))
            c.set_at((cx - 6, FLOOR - 1), chair)
            c.set_at((cx + 3, FLOOR - 1), chair)
        for a in self.actors:
            a.draw(c, FLOOR)
        for i, dx in enumerate(DESKS):
            top_y = FLOOR - 10
            c.fill(hexc("#8c7356"), (dx, top_y, 48, 2))
            c.fill(hexc("#6d5a44"), (dx, top_y + 2, 48, 1))
            c.fill(hexc("#6d5a44"), (dx + 1, top_y + 3, 2, 7))
            c.fill(hexc("#7a644c"), (dx + 32, top_y + 3, 14, 7))
            c.fill(hexc("#6d5a44"), (dx + 32, top_y + 3, 14, 1))
            c.fill(hexc("#e0c070"), (dx + 38, top_y + 6, 2, 1))
            # ban phim
            c.fill(hexc("#45434d"), (dx + 4, top_y - 1, 10, 1))
            # man hinh
            mx = dx + 18
            c.fill(hexc("#2c2a33"), (mx, FLOOR - 25, 20, 13))
            c.fill(hexc("#2c2a33"), (mx + 9, FLOOR - 12, 2, 2))
            c.fill(hexc("#2c2a33"), (mx + 5, FLOOR - 11, 10, 1))
            if i == 2 and self.alarm:
                on = int(self.time * 4) % 2 == 0
                c.fill((214, 66, 66) if on else (120, 30, 40), (mx + 1, FLOOR - 24, 18, 11))
                draw_text_px(c, "ERR", mx + 4, FLOOR - 21, (255, 230, 220))
            elif i == 2 and self.fixed:
                c.fill((70, 170, 110), (mx + 1, FLOOR - 24, 18, 11))
                draw_text_px(c, "OK", mx + 6, FLOOR - 21, (230, 255, 235))
            elif self.mon_on[i]:
                c.fill(hexc("#294865"), (mx + 1, FLOOR - 24, 18, 11))
                for k in range(4):
                    ln = (5 + (k * 7 + i * 3 + int(self.time * 2 if i == 2 else 0)) % 10)
                    c.fill(hexc("#8fd0e8") if k % 2 else hexc("#e8d08f"), (mx + 3, FLOOR - 22 + k * 2, ln, 1))
            else:
                c.fill(hexc("#16151b"), (mx + 1, FLOOR - 24, 18, 11))
            # ly ca phe
            c.fill(hexc("#efe6d6"), (dx + 41, top_y - 3, 3, 3))
        # den ban cua toi
        lx = DESKS[2] + 44
        c.fill(hexc("#3d3a40"), (lx - 3, FLOOR - 11, 7, 1))
        pygame.draw.line(c, hexc("#3d3a40"), (lx, FLOOR - 11), (lx - 3, FLOOR - 22))
        pygame.draw.line(c, hexc("#3d3a40"), (lx - 3, FLOOR - 22), (lx + 2, FLOOR - 27))
        c.fill(hexc("#c9a24a"), (lx, FLOOR - 28, 5, 3))
        # ---- anh sang
        night_on = lerpc((255, 222, 190), (205, 202, 222), t)
        tint_col = night_on if self.lights else (92, 98, 150)
        tint = pygame.Surface((W, H))
        tint.fill(tint_col)
        for r in WINDOWS:
            tint.fill(lerpc((255, 255, 255), (200, 200, 230), t), r)
        c.blit(tint, (0, 0), special_flags=pygame.BLEND_MULT)
        if self.lights:
            for lx in (75, 155, 235):
                add_glow(c, self.glow_ceil, lx + 20, 14, 0.25 * t)
        for i, dx in enumerate(DESKS):
            mx = dx + 28
            if i == 2 and self.alarm:
                add_glow(c, self.glow_red, mx, FLOOR - 18, 0.8 if int(self.time * 4) % 2 == 0 else 0.3)
            elif i == 2 and self.fixed:
                add_glow(c, self.glow_green, mx, FLOOR - 18, 0.6)
            elif self.mon_on[i]:
                add_glow(c, self.glow_mon, mx, FLOOR - 18, 0.25 + 0.5 * t)
        add_glow(c, self.glow_lamp, lx + 2, FLOOR - 16, 0.1 + 0.4 * t)
        add_glow(c, self.glow_exit, 17, 96, 0.3 + 0.6 * t)


SIDE = 132    # mep via he phia sau
GROUND = 147  # chan nguoi dung
CURB = 151


class Street:
    def __init__(self, game):
        self.g = game
        self.minutes = 23 * 60 + 4.0
        self.clock_rate = 1 / 2.5
        self.time = 0.0
        self.far = gen_buildings(21, -4, 330, 120, 30, 80, 12, 26)
        self.near = gen_buildings(22, 84, 330, SIDE, 22, 50, 18, 34)
        rnd = random.Random(9)
        self.stars = [(rnd.randint(0, W), rnd.randint(2, 70), rnd.random()) for _ in range(60)]
        self.rain = [[rnd.uniform(0, W + 40), rnd.uniform(0, H), rnd.uniform(150, 200)] for _ in range(110)]
        self.me = Actor(-8, PAL_ME)
        self.bus_x = 400.0
        self.door_open = False
        self.glow_moon = make_glow(26, (120, 120, 150))
        self.glow_lamp = make_glow(30, (255, 200, 120))
        self.cone = make_cone(8, 60, 80, (150, 116, 72))
        self.glow_store = make_glow(46, (255, 220, 160))
        self.glow_sign = make_glow(20, (240, 90, 130))
        self.glow_board = make_glow(18, (255, 160, 60))
        self.glow_head = make_cone(4, 24, 70, (120, 112, 92))
        self.glow_head = pygame.transform.rotate(self.glow_head, -90)
        self.glow_bus = make_glow(40, (255, 220, 140))
        self.glow_sun = make_glow(36, (255, 220, 160))
        self.morning = False
        self.clock_cap = 23 * 60 + 11
        self.wide_view = True
        self.cam = None
        self.cam_top = GROUND - 99
        self.world_w = W

    def update(self, dt):
        self.time += dt
        self.minutes = min(self.clock_cap, self.minutes + dt * self.clock_rate)
        self.me.update(dt)
        if self.me.visible or self.cam is None:
            target = self.me.x + 28
            self.cam = target if self.cam is None else self.cam + (target - self.cam) * min(1.0, dt * 2.5)
        for d in self.rain:
            d[0] -= d[2] * 0.25 * dt
            d[1] += d[2] * dt
            if d[1] > H:
                d[1] = random.uniform(-20, 0)
                d[0] = random.uniform(0, W + 40)

    def draw_bus(self, c):
        x = int(self.bus_x)
        if x > W + 5:
            return
        bot = 172
        h = 50
        top = bot - h
        cream = hexc("#eadcb8")
        teal = hexc("#3d8a86")
        dark = hexc("#2a2a33")
        c.fill(cream, (x + 2, top, 156, h - 8))
        c.fill(cream, (x, top + 3, 160, h - 11))
        c.fill(teal, (x, top + 28, 160, 9))
        c.fill(hexc("#e0a24a"), (x, top + 26, 160, 2))
        c.fill(hexc("#c9bb98"), (x, top + 37, 160, 4))
        c.fill(dark, (x, bot - 8, 160, 2))
        # kinh lai
        c.fill(hexc("#1e2638"), (x + 1, top + 5, 9, 19))
        c.fill(hexc("#ffe4a0"), (x + 2, top + 6, 7, 17))
        c.fill(hexc("#8a8580"), (x + 5, top + 12, 4, 3))
        c.fill(hexc("#dfb48f"), (x + 5, top + 15, 3, 3))
        c.fill(hexc("#5a7fb0"), (x + 4, top + 18, 5, 5))
        # bang tuyen
        c.fill(dark, (x + 12, top + 1, 34, 7))
        draw_text_px(c, "11 BUS", x + 15, top + 2, (255, 170, 60))
        # cua
        dx = x + 14
        if self.door_open:
            c.fill(hexc("#ffeab2"), (dx, top + 9, 13, h - 17))
            c.fill(hexc("#c79e5e"), (dx, top + 30, 13, 2))
        else:
            c.fill(hexc("#30384a"), (dx, top + 9, 13, h - 17))
            c.fill(hexc("#ffe4a0"), (dx + 1, top + 10, 5, 15))
            c.fill(hexc("#ffe4a0"), (dx + 7, top + 10, 5, 15))
            c.fill(hexc("#30384a"), (dx + 6, top + 9, 1, h - 17))
        # cua so khach
        for i in range(6):
            wx = x + 32 + i * 21
            c.fill(hexc("#30384a"), (wx, top + 7, 18, 17))
            c.fill(hexc("#ffe4a0"), (wx + 1, top + 8, 16, 15))
            c.fill(hexc("#f2cf86"), (wx + 1, top + 18, 16, 5))
        # mot bong nguoi ngoi o hang cuoi
        sx = x + 32 + 4 * 21 + 6
        c.fill(hexc("#8a7a6a"), (sx, top + 13, 5, 5))
        c.fill(hexc("#6a5a4e"), (sx - 1, top + 18, 7, 5))
        # banh xe
        for wx in (x + 30, x + 128):
            pygame.draw.circle(c, dark, (wx, bot - 6), 7)
            pygame.draw.circle(c, hexc("#77737a"), (wx, bot - 6), 3)
            c.fill(hexc("#1b1b22"), (wx - 9, bot - 14, 18, 2))
        # den pha
        c.fill(hexc("#fff4c8"), (x, bot - 17, 3, 3))
        c.fill(hexc("#e05a4a"), (x + 157, bot - 17, 3, 3))

    def draw(self, c):
        t = self.time
        mo = self.morning
        if mo:
            vgrad(c, (0, 0, W, 125), hexc("#8fbfe6"), hexc("#f7d9b4"))
            pygame.draw.circle(c, (255, 244, 214), (52, 46), 9)
            add_glow(c, self.glow_sun, 52, 46, 0.6)
            draw_birds(c, t)
            draw_buildings(c, self.far, 120, hexc("#a9b3cf"), 0.0, (0, 0, 0), hexc("#97a2c0"))
            draw_buildings(c, self.near, SIDE, hexc("#8a96b6"), 0.0, (0, 0, 0), hexc("#7884a6"))
        else:
            vgrad(c, (0, 0, W, 125), hexc("#0e1228"), hexc("#2d2c58"))
            for sx, sy, sr in self.stars:
                tw = 0.5 + 0.5 * math.sin(t * 1.5 + sr * 40)
                c.set_at((sx, sy), lerpc((50, 52, 90), (220, 220, 250), tw * sr))
            pygame.draw.circle(c, (238, 230, 200), (44, 26), 8)
            pygame.draw.circle(c, hexc("#141936"), (48, 23), 7)
            add_glow(c, self.glow_moon, 44, 26, 0.5)
            draw_buildings(c, self.far, 120, hexc("#1d2243"), 0.22, (200, 170, 110), hexc("#171b36"))
            draw_buildings(c, self.near, SIDE, hexc("#262b4f"), 0.3, (240, 200, 120), hexc("#1e2241"))
        # cua hang tien loi 24h
        sx0 = 8
        c.fill(hexc("#6a76a0") if mo else hexc("#343b66"), (sx0, 86, 72, SIDE - 86))
        c.fill(hexc("#b8455f"), (sx0, 86, 72, 9))
        draw_text_px(c, "24H", sx0 + 30, 88, (255, 230, 236))
        c.fill(hexc("#dce8ee") if mo else hexc("#f6e7b4"), (sx0 + 4, 99, 64, 29))
        for k in range(3):
            c.fill(hexc("#c8b27e"), (sx0 + 4, 106 + k * 8, 64, 1))
            for j in range(10):
                col = ((214, 120, 98), (98, 160, 190), (230, 190, 90), (140, 190, 120))[(j + k) % 4]
                c.fill(col, (sx0 + 6 + j * 6, 102 + k * 8, 4, 4))
        c.fill(hexc("#6a76a0") if mo else hexc("#343b66"), (sx0 + 35, 99, 2, 29))
        # via he
        side, seam = (hexc("#a9a9b6"), hexc("#9898a6")) if mo else (hexc("#4b4d66"), hexc("#40425a"))
        c.fill(side, (0, SIDE, W, CURB - SIDE))
        for x in range(0, W, 16):
            c.fill(seam, (x, SIDE, 1, CURB - SIDE))
        c.fill(seam, (0, SIDE + 9, W, 1))
        c.fill(hexc("#c9c9d2") if mo else hexc("#77788e"), (0, CURB, W, 2))
        c.fill(hexc("#9a9aa8") if mo else hexc("#5a5b70"), (0, CURB + 2, W, 2))
        # duong
        road = hexc("#6a6b78") if mo else hexc("#292a36")
        c.fill(road, (0, CURB + 4, W, H - CURB - 4))
        for x in range(-10, W, 34):
            c.fill(hexc("#d8d6c8") if mo else hexc("#8b8a78"), (x, 168, 16, 2))
        # phan chieu den tren mat duong uot
        for rx, col in (() if mo else ((44, (90, 80, 60)), (150, (110, 90, 55)), (236, (90, 70, 40)))):
            for k in range(0, 24, 2):
                ww = 6 - k // 5
                c.fill(lerpc(col, hexc("#292a36"), k / 24), (rx - ww // 2 + int(math.sin(t * 3 + k) * 1), CURB + 6 + k, ww, 1))
        # cot den duong
        lx = 146
        c.fill(hexc("#3a3c4c"), (lx, 58, 3, GROUND - 58))
        c.fill(hexc("#3a3c4c"), (lx - 2, GROUND - 2, 7, 3))
        c.fill(hexc("#3a3c4c"), (lx, 58, 12, 2))
        c.fill(hexc("#3a3c4c"), (lx + 8, 58, 8, 4))
        c.fill(hexc("#c8c8c0") if mo else hexc("#ffe2a6"), (lx + 9, 62, 6, 1))
        # tram xe buyt
        roof = hexc("#3c4760")
        c.fill(roof, (194, 94, 72, 5))
        c.fill(hexc("#55617d"), (194, 99, 72, 1))
        c.fill(hexc("#2e3448"), (196, 100, 2, GROUND - 100))
        c.fill(hexc("#2e3448"), (262, 100, 2, GROUND - 100))
        glass = pygame.Surface((62, 34), pygame.SRCALPHA)
        glass.fill((150, 190, 215, 50))
        pygame.draw.line(glass, (210, 230, 245, 90), (6, 32), (22, 2))
        c.blit(glass, (199, 104))
        # poster quang cao
        c.fill(hexc("#e6d2a3"), (244, 106, 14, 22))
        c.fill(hexc("#c4544a"), (246, 109, 10, 8))
        c.fill(hexc("#6a7fa0"), (246, 120, 10, 2))
        # ghe cho
        c.fill(hexc("#8b6b4c"), (204, 133, 34, 3))
        c.fill(hexc("#2e3448"), (206, 136, 2, GROUND - 136))
        c.fill(hexc("#2e3448"), (234, 136, 2, GROUND - 136))
        # bang gio
        c.fill(hexc("#151418"), (214, 101, 30, 9))
        draw_text_px(c, fmt_time(self.minutes), 220, 103, (255, 170, 60))
        # bien BUS
        c.fill(hexc("#3a3c4c"), (276, 92, 2, GROUND - 92))
        c.fill(hexc("#2f6fb0"), (269, 84, 16, 10))
        draw_text_px(c, "BUS", 271, 86, (240, 245, 255))
        # nguoi
        for a in getattr(self, "extras", ()):
            a.draw(c, GROUND)
        self.me.draw(c, GROUND)
        # xe buyt (o lan duong, truoc via he)
        self.draw_bus(c)
        # mua
        if mo:
            add_glow(c, self.glow_board, 229, 105, 0.25)
            return
        rc = (112, 128, 170)
        for x, y, sp in self.rain:
            pygame.draw.line(c, rc, (int(x), int(y)), (int(x - 1), int(y + 4)))
        # ---- anh sang
        add_glow(c, self.glow_lamp, lx + 12, 64, 0.6)
        c.blit(self.cone, (lx + 12 - 30, 64), special_flags=pygame.BLEND_ADD)
        add_glow(c, self.glow_store, sx0 + 36, 116, 0.55)
        add_glow(c, self.glow_sign, sx0 + 36, 90, 0.6)
        add_glow(c, self.glow_board, 229, 105, 0.5)
        if self.bus_x < W:
            bx = int(self.bus_x)
            add_glow(c, self.glow_bus, bx + 80, 140, 0.12)
            c.blit(self.glow_head, (bx - 70, 144), special_flags=pygame.BLEND_ADD)


BUS_FLOOR = 140
BUS_X0, BUS_X1 = 36, 294
BUS_DOOR = 76
BUS_SEATS = [98 + 21 * i for i in range(9)]
HANDLE_Y = 108


class BusInterior:
    """Xe buyt nhin ngang kieu mat cat: thay ben trong, pho dem troi phia sau."""

    def __init__(self, game):
        self.g = game
        self.time = 0.0
        self.scroll = 0.0
        self.speed = 0.0
        self.target_speed = 0.0
        self.far = gen_buildings(41, 0, 420, 100, 30, 76, 12, 26)
        self.near = gen_buildings(42, 0, 520, 130, 20, 52, 16, 30)
        self.shops = [(i * 173 + 30, ((214, 120, 98), (98, 160, 190), (230, 190, 90))[i % 3]) for i in range(3)]
        self.me = Actor(BUS_DOOR, PAL_ME)
        self.me_seat = None
        self.driver = Actor(BUS_X0 + 17, PAL_DRIVER, facing=-1, state="sit")
        self.seated = {}
        self.standing = []
        self.door_open = False
        self.phone_idx = None
        self.sleep = 0.0
        self.closeup = 0.0
        self.show_seat_hint = False
        self.ticket = make_ticket()
        rnd = random.Random(3)
        self.rain = [[rnd.uniform(0, W), rnd.uniform(0, H), rnd.uniform(130, 180)] for _ in range(80)]
        self.glow_lamp = make_glow(24, (255, 196, 120))
        self.glow_ceil = make_glow(26, (255, 232, 190))
        self.glow_phone = make_glow(9, (120, 170, 255))
        self.glow_shop = make_glow(30, (255, 220, 160))
        self.wall = self.build_wall()
        self.morning = False
        self.allowed = None

    # ---- hanh khach
    def add_passenger(self, idx, k, state="sit"):
        pal, fem = PASSENGERS[k % len(PASSENGERS)]
        a = Actor(BUS_SEATS[idx], pal, female=fem, facing=-1, state=state)
        a.anim = random.random() * 5
        self.seated[idx] = a
        return a

    def near_seat(self):
        for i, sx in enumerate(BUS_SEATS):
            if self.allowed is not None and i not in self.allowed:
                continue
            if i not in self.seated and abs(self.me.x - sx) < 6:
                return i
        return None

    def actors(self):
        out = [self.driver] + list(self.seated.values()) + self.standing
        if self.me not in out:
            out.append(self.me)
        return out

    def update(self, dt):
        self.time += dt
        self.speed += (self.target_speed - self.speed) * min(1.0, dt * 0.9)
        if abs(self.speed - self.target_speed) < 0.5:
            self.speed = self.target_speed
        self.scroll += self.speed * dt
        for a in self.actors():
            a.update(dt)
        for d in self.rain:
            d[0] += (self.speed * 0.9 + 20) * dt
            d[1] += d[2] * dt
            if d[1] > H or d[0] > W + 10:
                d[1] = random.uniform(-30, 0)
                d[0] = random.uniform(-40, W)

    # ---- tuong xe (ve 1 lan)
    def build_wall(self):
        s = pygame.Surface((W, H), pygame.SRCALPHA)
        x0, x1 = BUS_X0, BUS_X1
        cream = hexc("#eadcb8")
        teal = hexc("#3d8a86")
        frame = hexc("#3a4152")
        # mui xe
        s.fill(cream, (x0 + 3, 95, x1 - x0 - 6, 2))
        s.fill(cream, (x0 + 1, 97, x1 - x0 - 2, 5))
        s.fill(hexc("#c9bb98"), (x0 + 1, 101, x1 - x0 - 2, 1))
        s.fill(hexc("#2a2a33"), (x0 + 14, 96, 30, 5))
        draw_text_px(s, "11 BUS", x0 + 17, 96, (255, 170, 60))
        # tran ben trong
        s.fill(hexc("#efe8d6"), (x0 + 1, 102, x1 - x0 - 2, 3))
        for lx in range(x0 + 30, x1 - 20, 46):
            s.fill(hexc("#fff4d4"), (lx, 102, 22, 1))
        # vach sau
        s.fill(hexc("#d8cdb2"), (x0 + 1, 105, x1 - x0 - 2, BUS_FLOOR - 105))
        s.fill(hexc("#b8ab8e"), (x0 + 1, 126, x1 - x0 - 2, BUS_FLOOR - 126))
        s.fill(hexc("#a4977a"), (x0 + 1, 126, x1 - x0 - 2, 1))
        # cua so vach sau (lo trong de thay pho)
        for wx in range(x0 + 56, x1 - 10, 38):
            s.fill(frame, (wx - 1, 107, 34, 19))
            s.fill((0, 0, 0, 0), (wx, 108, 32, 17))
            s.fill(frame, (wx, 116, 32, 1))
        # kinh lai phia truoc
        s.fill(frame, (x0, 100, 9, 30))
        s.fill((0, 0, 0, 0), (x0 + 1, 102, 7, 24))
        s.fill(hexc("#2a2a33"), (x0 + 9, 120, 2, 8))
        pygame.draw.circle(s, hexc("#2a2a33"), (x0 + 11, 121), 3, 1)
        # duoi xe
        s.fill(frame, (x1 - 3, 100, 3, 42))
        s.fill(hexc("#e05a4a"), (x1 - 2, 130, 2, 4))
        # san + vay xe
        s.fill(hexc("#5a5f6e"), (x0, BUS_FLOOR, x1 - x0, 2))
        s.fill(hexc("#e0a24a"), (x0, BUS_FLOOR + 2, x1 - x0, 1))
        s.fill(teal, (x0, BUS_FLOOR + 3, x1 - x0, 6))
        s.fill(hexc("#c9bb98"), (x0, BUS_FLOOR + 9, x1 - x0, 2))
        s.fill(hexc("#fff4c8"), (x0, BUS_FLOOR + 3, 2, 3))
        # thanh vin
        s.fill(hexc("#b9bec6"), (x0 + 24, 104, x1 - x0 - 30, 1))
        return s

    def draw_outside(self, c):
        sc = self.scroll
        mo = self.morning
        if mo:
            vgrad(c, (0, 0, W, 132), hexc("#8fbfe6"), hexc("#f7d9b4"))
            draw_birds(c, self.time, 3)
            draw_buildings(c, self.far, 100, hexc("#a9b3cf"), 0.0, (0, 0, 0), hexc("#97a2c0"),
                           ox=sc * 0.12, period=420)
            draw_buildings(c, self.near, 130, hexc("#8a96b6"), 0.0, (0, 0, 0), hexc("#7884a6"),
                           ox=sc * 0.45, period=520)
        else:
            vgrad(c, (0, 0, W, 132), hexc("#0e1228"), hexc("#2b2a55"))
            rnd = random.Random(8)
            for i in range(50):
                sx = (rnd.randint(0, 400) + sc * 0.02) % 400 - 40
                c.set_at((int(sx), rnd.randint(2, 70)), lerpc((40, 40, 70), (200, 200, 240), rnd.random()))
            draw_buildings(c, self.far, 100, hexc("#1d2243"), 0.22, (200, 170, 110), hexc("#171b36"),
                           ox=sc * 0.12, period=420)
            draw_buildings(c, self.near, 130, hexc("#262b4f"), 0.3, (240, 200, 120), hexc("#1e2241"),
                           ox=sc * 0.45, period=520)
        # via he + cua hang troi qua
        c.fill(hexc("#a9a9b6") if mo else hexc("#4b4d66"), (0, 130, W, 20))
        for x in range(0, W + 16, 16):
            xx = int((x + sc) % (W + 16)) - 16
            c.fill(hexc("#9898a6") if mo else hexc("#40425a"), (xx, 130, 1, 20))
        for bx, col in self.shops:
            xx = int((bx + sc * 0.8) % 520) - 100
            if -80 < xx < W:
                c.fill(hexc("#6a76a0") if mo else hexc("#343b66"), (xx, 100, 64, 30))
                c.fill(hexc("#dce8ee") if mo else hexc("#f6e7b4"), (xx + 4, 106, 56, 22))
                for j in range(8):
                    c.fill(col, (xx + 7 + j * 7, 110, 4, 4))
                    c.fill(col, (xx + 7 + j * 7, 118, 4, 4))
        # cot den troi qua
        self.lamps = []
        for n in range(4):
            lx = int((n * 110 + sc) % 440) - 60
            if -20 < lx < W + 20:
                c.fill(hexc("#3a3c4c"), (lx, 58, 2, 92))
                c.fill(hexc("#3a3c4c"), (lx - 8, 58, 10, 2))
                c.fill(hexc("#c8c8c0") if mo else hexc("#ffe2a6"), (lx - 8, 60, 5, 1))
                self.lamps.append(lx - 6)
        # duong
        c.fill(hexc("#6a6b78") if mo else hexc("#292a36"), (0, 150, W, H - 150))
        for x in range(0, W + 40, 40):
            xx = int((x + sc * 1.0) % (W + 40)) - 40
            c.fill(hexc("#d8d6c8") if mo else hexc("#8b8a78"), (xx, 170, 18, 2))
        if mo:
            return
        # mua
        rc = (100, 116, 160)
        for x, y, sp in self.rain:
            pygame.draw.line(c, rc, (int(x), int(y)), (int(x + 2), int(y + 4)))
        for lx in self.lamps:
            add_glow(c, self.glow_lamp, lx, 62, 0.7)
        for bx, col in self.shops:
            xx = int((bx + sc * 0.8) % 520) - 100
            if -80 < xx < W:
                add_glow(c, self.glow_shop, xx + 32, 116, 0.35)

    def draw_seat(self, c, sx):
        fab = hexc("#3d6d8a")
        c.fill(hexc("#2c4f66"), (sx + 4, 118, 4, 19))
        c.fill(fab, (sx + 5, 118, 3, 18))
        c.fill(hexc("#5f8fab"), (sx + 5, 118, 3, 1))
        c.fill(hexc("#2c4f66"), (sx - 6, 135, 13, 3))
        c.fill(fab, (sx - 6, 135, 12, 2))
        c.fill(hexc("#7a7f8a"), (sx + 1, 138, 2, 2))
        c.fill(hexc("#b9bec6"), (sx + 7, 116, 1, 3))

    def draw(self, c):
        t = self.time
        self.draw_outside(c)
        # kinh co mau nhe
        c.blit(self.wall, (0, 0))
        glass = pygame.Surface((32, 17), pygame.SRCALPHA)
        glass.fill((70, 90, 130, 40))
        for wx in range(BUS_X0 + 56, BUS_X1 - 10, 38):
            c.blit(glass, (wx, 108))
        # cua xe
        dx = BUS_DOOR - 7
        if self.door_open:
            c.fill(hexc("#3a4152"), (dx - 1, 104, 16, 1))
            c.fill(hexc("#3a4152"), (dx - 1, 104, 1, BUS_FLOOR - 104))
            c.fill(hexc("#3a4152"), (dx + 14, 104, 1, BUS_FLOOR - 104))
            c.fill(hexc("#fff6e2") if self.morning else hexc("#1c2040"), (dx, 105, 14, BUS_FLOOR - 112))
            c.fill(hexc("#4b4d66"), (dx, BUS_FLOOR - 7, 14, 7))
            c.fill(hexc("#ffe2a6"), (dx + 3, 110, 1, 1))
        else:
            c.fill(hexc("#3a4152"), (dx - 1, 104, 16, BUS_FLOOR - 104))
            c.fill(hexc("#5d6f8f"), (dx + 1, 106, 5, 18))
            c.fill(hexc("#5d6f8f"), (dx + 8, 106, 5, 18))
        # tay nam
        sway = math.sin(t * 2.3) * min(1.0, self.speed / 50.0)
        for i, hx in enumerate(range(BUS_X0 + 40, BUS_X1 - 8, 14)):
            off = int(round(sway * (1 if i % 2 else 0.6)))
            c.fill(hexc("#9aa0aa"), (hx, 105, 1, 2))
            pygame.draw.rect(c, hexc("#e6c66e"), (hx - 1 + off, 107, 3, 3), 1)
        for sx in BUS_SEATS:
            self.draw_seat(c, sx)
        for a in [self.driver] + list(self.seated.values()):
            a.draw(c, BUS_FLOOR)
        if self.me_seat is not None and self.me.state in ("sit", "sleep"):
            self.me.draw(c, BUS_FLOOR)
        # dien thoai bat loa
        if self.phone_idx is not None:
            px = BUS_SEATS[self.phone_idx] - 5
            c.fill(hexc("#1b1b22"), (px, 126, 2, 3))
            c.fill(hexc("#9fd0ff"), (px, 126, 1, 2))
            for k in range(2):
                ph = (t * 0.8 + k * 0.5) % 1.0
                nx = px - 2 + int(math.sin(ph * 6 + k) * 2)
                ny = int(122 - ph * 12)
                col = lerpc((255, 220, 120), (40, 40, 60), ph)
                c.fill(col, (nx, ny, 1, 4))
                c.fill(col, (nx - 2, ny + 3, 2, 2))
                c.fill(col, (nx + 1, ny, 2, 1))
        # nguoi dung
        people = list(self.standing)
        if self.me not in people and (self.me_seat is None or self.me.state not in ("sit", "sleep")):
            people.append(self.me)
        for a in people:
            if not a.visible:
                continue
            if a in self.standing and a.state != "walk":
                # tay gio len vin tay nam: ve sau nguoi, chi lo phan tren dau
                hx = int(a.x) + a.facing * 2
                c.fill(hexc("#9aa0aa"), (hx, 105, 1, 2))
                c.fill(OUTLINE, (hx - 1, HANDLE_Y, 4, 18))
                c.fill(hexc(a.pal["w"]), (hx, HANDLE_Y + 2, 2, 16))
                c.fill(hexc(a.pal["s"]), (hx, HANDLE_Y, 2, 2))
                pygame.draw.rect(c, hexc("#e6c66e"), (hx - 1, 107, 4, 3), 1)
            a.draw(c, BUS_FLOOR)
        # chi ghe trong
        if self.show_seat_hint:
            i = self.near_seat()
            for k, sx in enumerate(BUS_SEATS):
                if k in self.seated:
                    continue
                bob = int(math.sin(t * 5) * 1.5)
                col = (255, 236, 160) if k == i else (150, 150, 120)
                pygame.draw.polygon(c, col, [(sx - 2, 112 + bob), (sx + 2, 112 + bob), (sx, 114 + bob)])
        # anh sang
        for lx in range(BUS_X0 + 30, BUS_X1 - 20, 46):
            add_glow(c, self.glow_ceil, lx + 11, 112, 0.08 if self.morning else 0.28)
        if self.phone_idx is not None:
            add_glow(c, self.glow_phone, BUS_SEATS[self.phone_idx] - 5, 126, 0.8)
        # ngu gat: toi dan + mi mat
        if self.sleep > 0.001:
            v = int(255 * (1 - 0.85 * self.sleep))
            ov = pygame.Surface((W, H))
            ov.fill((v, v, int(v * 1.05) if v < 243 else 255))
            c.blit(ov, (0, 0), special_flags=pygame.BLEND_MULT)
            lid = int(self.sleep * 92)
            c.fill((0, 0, 0), (0, 0, W, lid))
            c.fill((0, 0, 0), (0, H - lid, W, lid))
        # can canh tam ve
        if self.closeup > 0.001:
            ov = pygame.Surface((W, H))
            v = int(255 * (1 - 0.7 * self.closeup))
            ov.fill((v, v, v))
            c.blit(ov, (0, 0), special_flags=pygame.BLEND_MULT)
            big = pygame.transform.scale(self.ticket, (144, 64))
            y = int(30 + (1 - self.closeup) * 20 + math.sin(t * 1.5) * 1.5)
            big.set_alpha(int(255 * self.closeup))
            c.blit(big, (W // 2 - 72, y))


KID_BODY = [
    ".....wwwwww.....",
    "....bwrrwwwW....",
    "...bBwwrwwwWs...",
    "...sBwwwwwWs....",
    ".....pppppp.....",
]
KID_LEGS = [
    ".....sSs.sSs....",
    ".....sSs.sSs....",
    ".....ooo.ooo....",
]
KID_LEGS_RUN = [
    "....sS...ss.....",
    "...sS.....ss....",
    "..oo.......oo...",
]
KID_LEGS_SIT = [
    ".....sSSSSsss...",
    "............oo..",
]
PAL_KID = dict(PAL_ME, h="#2a2024", H="#45383a", w="#f4f2ea", W="#cfcabd", b="#f4f2ea",
               B="#cfcabd", p="#2f4e8a", P="#22396a", g="#f1c6a3", r="#f4f2ea")
PAL_FATHER = dict(PAL_ME, h="#1d1a1c", H="#3a3436", w="#e6e1d3", W="#bdb7a6", b="#e6e1d3",
                  B="#bdb7a6", g="#e3b28c", s="#e3b28c", S="#c08e6c", p="#5a5048", P="#433b35")
PAL_MOTHER = dict(PAL_ME, h="#2a1c1c", H="#4a3030", w="#c2577a", W="#9c4462", g="#f1c6a3",
                  p="#3a3240", P="#2a2430")


def build_kid(pal, pose="idle"):
    legs = {"idle": KID_LEGS, "run": KID_LEGS_RUN, "sit": KID_LEGS_SIT}[pose]
    return make_sprite(HEAD_KID + KID_BODY + legs, pal)


def put(surf, spr, x, base, flip=False):
    if flip:
        spr = pygame.transform.flip(spr, True, False)
    surf.blit(spr, (int(x) - spr.get_width() // 2, base - spr.get_height() + 1))


def photo_family():
    s = pygame.Surface((64, 52))
    s.fill(hexc("#e2b98a"))
    s.fill(hexc("#cf9f6e"), (0, 0, 64, 4))
    s.fill(hexc("#b5523c"), (5, 8, 11, 13))
    s.fill(hexc("#f4ead8"), (6, 12, 9, 8))
    draw_text_px(s, "15", 7, 13, (180, 60, 50))
    s.fill(hexc("#7a5a3c"), (40, 6, 19, 15))
    s.fill(hexc("#9fd08a"), (41, 7, 17, 13))
    s.fill(hexc("#7a5a3c"), (49, 7, 1, 13))
    s.fill(hexc("#d7b46a"), (0, 38, 64, 14))
    for y in range(40, 52, 3):
        s.fill(hexc("#c9a35a"), (0, y, 64, 1))
    put(s, build_kid(PAL_KID, "sit"), 32, 44)
    put(s, build_char(PAL_FATHER)["sit"], 11, 47)
    put(s, build_char(PAL_MOTHER, female=True)["sit"], 53, 47, flip=True)
    pygame.draw.ellipse(s, hexc("#a8643a"), (17, 38, 30, 8))
    pygame.draw.ellipse(s, hexc("#8a4f2c"), (17, 41, 30, 5))
    for bx, by in ((21, 38), (27, 37), (37, 38), (32, 40)):
        s.fill(hexc("#f4f2ea"), (bx, by, 4, 2))
    s.fill(hexc("#7cb36a"), (31, 37, 5, 2))
    s.fill(hexc("#e0a24a"), (25, 40, 4, 1))
    return s


def photo_football():
    s = pygame.Surface((64, 52))
    vgrad(s, (0, 0, 64, 30), hexc("#f6b37a"), hexc("#ef8f8f"), 8)
    pygame.draw.circle(s, hexc("#ffe3a0"), (46, 22), 6)
    rnd = random.Random(2)
    for x in range(0, 64, 4):
        h = rnd.randint(2, 6)
        s.fill(hexc("#5a6a4a"), (x, 28 - h, 5, h + 2))
    s.fill(hexc("#6fa04a"), (0, 29, 64, 23))
    for y in range(31, 52, 4):
        s.fill(hexc("#679843"), (0, y, 64, 2))
    s.fill(hexc("#f4f2ea"), (53, 20, 1, 20))
    s.fill(hexc("#f4f2ea"), (53, 20, 10, 1))
    for x in range(55, 63, 2):
        s.fill(hexc("#c8d4c0"), (x, 21, 1, 18))
    k1 = dict(PAL_KID, w="#e8a33c", W="#c4832a", b="#e8a33c", B="#c4832a", p="#3a3a4a", P="#2a2a36")
    k2 = dict(PAL_KID, w="#7cb36a", W="#5f9450", b="#7cb36a", B="#5f9450", h="#4a2c20")
    put(s, build_kid(PAL_KID, "run"), 15, 49)
    put(s, build_kid(k1, "idle"), 33, 47, flip=True)
    put(s, build_kid(k2, "run"), 46, 50, flip=True)
    pygame.draw.circle(s, hexc("#f4f2ea"), (24, 47), 2)
    s.set_at((24, 47), (40, 40, 40))
    return s


def photo_school():
    s = pygame.Surface((64, 52))
    s.fill(hexc("#a8d4f0"))
    pygame.draw.circle(s, hexc("#f4f8fb"), (10, 6), 4)
    pygame.draw.circle(s, hexc("#f4f8fb"), (15, 6), 3)
    s.fill(hexc("#c4544a"), (0, 9, 64, 4))
    s.fill(hexc("#f0c75a"), (0, 13, 64, 22))
    for x in range(4, 64, 10):
        s.fill(hexc("#6f9fc8"), (x, 17, 6, 6))
        s.fill(hexc("#6f9fc8"), (x, 27, 6, 6))
    s.fill(hexc("#2f5f9f"), (16, 12, 32, 8))
    draw_text_px(s, "TRUONG", 20, 13, (250, 250, 250))
    s.fill(hexc("#9a9a9a"), (2, 22, 4, 22))
    s.fill(hexc("#9a9a9a"), (58, 22, 4, 22))
    s.fill(hexc("#d9c59a"), (0, 40, 64, 12))
    s.fill(hexc("#c9b58a"), (0, 40, 64, 1))
    school = dict(PAL_KID, r="#d8402f", b="#3f7fbf", B="#2f5f90")
    k2 = dict(school, h="#3a2420", b="#d0a03a", B="#a87e28")
    k3 = dict(school, h="#1a1618", b="#c4544a", B="#9a3f37")
    put(s, build_kid(k2, "idle"), 18, 50)
    put(s, build_kid(school, "idle"), 32, 50)
    put(s, build_kid(k3, "idle"), 46, 50, flip=True)
    return s


def photo_ghost():
    s = pygame.Surface((64, 52))
    s.fill(hexc("#1b1d33"))
    s.fill(hexc("#23263f"), (0, 0, 64, 30))
    pygame.draw.circle(s, hexc("#8a7f6a"), (44, 13), 11)
    pygame.draw.circle(s, hexc("#b8a77e"), (44, 13), 9)
    g = hexc("#3a3550")
    pygame.draw.circle(s, g, (44, 11), 4)
    s.fill(g, (40, 11, 9, 7))
    for x in range(40, 49, 2):
        s.set_at((x, 18), g)
    s.set_at((42, 10), hexc("#b8a77e"))
    s.set_at((46, 10), hexc("#b8a77e"))
    pygame.draw.polygon(s, hexc("#5a5340"), [(30, 31), (36, 6), (54, 18)])
    head = build_kid(PAL_KID, "idle").subsurface((0, 0, 14, 12))
    s.blit(head, (14, 21))
    s.blit(pygame.transform.flip(head, True, False), (27, 22))
    pygame.draw.ellipse(s, hexc("#6a8fc4"), (2, 28, 58, 28))
    for x in range(6, 58, 6):
        for y in range(32, 52, 6):
            s.fill(hexc("#5a7fb4"), (x, y, 2, 2))
    s.fill(hexc("#f0d070"), (30, 30, 3, 2))
    s.fill(hexc("#c4c4c4"), (26, 30, 4, 2))
    return s


def polaroid(photo):
    s = pygame.Surface((68, 60))
    s.fill(hexc("#f6f2e8"))
    s.blit(photo, (2, 2))
    return s


ROOM_FLOOR = 150
BED_X = 216


class Room:
    def __init__(self, game):
        self.g = game
        self.time = 0.0
        self.lights = False
        self.jacket = False
        self.lying = False
        self.door_t = 0.0
        self.phone_t = 0.0
        self.screen = "photos"
        self.photo = 0
        self.swipe = 0.0
        self.sleep = 0.0
        self.me = Actor(52, PAL_ME)
        self.me.visible = False
        self.marker = None
        self.photos = [
            ("15 năm trước", polaroid(photo_family())),
            ("12 năm trước", polaroid(photo_football())),
            ("16 năm trước", polaroid(photo_school())),
            ("14 năm trước", polaroid(photo_ghost())),
        ]
        idle = self.me.spr["idle"]
        self.lie_spr = pygame.transform.rotate(pygame.transform.flip(idle, True, False), -90)
        rnd = random.Random(12)
        self.win_rain = [[rnd.uniform(176, 212), rnd.uniform(90, 122), rnd.uniform(60, 90)] for _ in range(14)]
        self.out_rain = [[rnd.uniform(0, W), rnd.uniform(0, H), rnd.uniform(130, 180)] for _ in range(50)]
        self.city = [(rnd.randint(178, 210), rnd.randint(98, 120), rnd.random()) for _ in range(16)]
        self.glow_bulb = make_glow(56, (255, 214, 150))
        self.glow_phone = make_glow(26, (110, 150, 230))
        self.glow_win = make_glow(30, (80, 100, 160))
        self.morning = False
        self.rush = None
        self.clock = 0.0
        self.has_keys = False
        self.has_bag = False
        self.glow_sunwin = make_glow(50, (255, 214, 160))
        # cac do vat co the xem: (x, ten, cac dong suy nghi)
        self.items = [
            (86, "fridge", ["Hoá đơn tiền điện tháng này...", "Lại tăng nữa rồi."]),
            (136, "desk", ["Hai ly mì gói. Bữa tối hôm qua, và hôm kia."]),
            (194, "window", ["Mưa vẫn chưa tạnh.", "Giờ này ở quê chắc mọi người ngủ hết rồi."]),
            (240, "bed", None),
        ]

    def near_item(self):
        for it in self.items:
            if abs(self.me.x - it[0]) < 9:
                return it
        return None

    def update(self, dt):
        self.time += dt
        self.door_t = max(0.0, self.door_t - dt)
        self.me.update(dt)
        for d in self.win_rain:
            d[1] += d[2] * dt
            if d[1] > 122:
                d[1] = 90
                d[0] = random.uniform(176, 211)
        for d in self.out_rain:
            d[0] -= d[2] * 0.2 * dt
            d[1] += d[2] * dt
            if d[1] > H:
                d[1] = random.uniform(-20, 0)
                d[0] = random.uniform(0, W + 30)

    def draw(self, c):
        t = self.time
        F = ROOM_FLOOR
        # ngoai troi (2 ben va tren mai)
        mo = self.morning
        if mo:
            vgrad(c, (0, 0, W, H), hexc("#8fbfe6"), hexc("#f7d9b4"))
            draw_birds(c, t, 3)
        else:
            vgrad(c, (0, 0, W, H), hexc("#0e1228"), hexc("#262650"))
            for x, y, sp in self.out_rain:
                pygame.draw.line(c, (70, 82, 120), (int(x), int(y)), (int(x - 1), int(y + 4)))
        c.fill(hexc("#2a2a33"), (32, 56, 256, 124))
        # tuong
        c.fill(hexc("#c9cdb6"), (40, 64, 240, F - 64))
        c.fill(hexc("#b6ba9f"), (40, 130, 240, F - 130))
        c.fill(hexc("#a4a88e"), (40, 130, 240, 1))
        c.fill(hexc("#e2e4d6"), (40, 64, 240, 3))
        for bx, by, r in ((52, 70, 6), (60, 72, 4), (268, 68, 7), (258, 74, 3)):
            pygame.draw.circle(c, hexc("#b9bda4"), (bx, by), r)
        pygame.draw.lines(c, hexc("#aeb299"), False, [(120, 67), (123, 74), (121, 80), (125, 88)])
        # san gach
        for i, x in enumerate(range(40, 280, 10)):
            for j, y in enumerate(range(F, H, 6)):
                c.fill(hexc("#c8bfae") if (i + j) % 2 == 0 else hexc("#bdb3a1"), (x, y, 10, 6))
        c.fill(hexc("#8f8778"), (40, F, 240, 1))
        # cua
        c.fill(hexc("#5d4733"), (43, 103, 21, F - 103))
        if self.door_t > 0:
            c.fill(hexc("#16141c"), (45, 105, 17, F - 105))
        else:
            c.fill(hexc("#7a5b3e"), (45, 105, 17, F - 105))
            c.fill(hexc("#6a4e35"), (48, 109, 11, 14))
            c.fill(hexc("#6a4e35"), (48, 127, 11, 18))
            c.fill(hexc("#d8b860"), (59, 127, 2, 2))
        c.fill(hexc("#efefe6"), (66, 117, 3, 5))
        c.fill(hexc("#9a9a90"), (67, 118, 1, 2))
        # moc ao + ao khoac
        c.fill(hexc("#555560"), (72, 101, 3, 1))
        if self.jacket:
            jc = hexc("#5b6b4a")
            c.fill(jc, (69, 102, 9, 19))
            c.fill(hexc("#4a573c"), (69, 102, 2, 19))
            c.fill(hexc("#7a8a62"), (72, 102, 3, 3))
            c.fill(hexc("#4a573c"), (73, 112, 4, 4))
            c.fill(hexc("#f3e6c4"), (74, 110, 2, 2))   # mep tam ve lo ra
        # tu lanh mini + hoa don
        c.fill(hexc("#c9cacd"), (78, 123, 17, F - 123))
        c.fill(hexc("#e8e8ea"), (79, 124, 15, F - 125))
        c.fill(hexc("#c9cacd"), (79, 134, 15, 1))
        c.fill(hexc("#9a9ca2"), (91, 127, 1, 5))
        c.fill(hexc("#fbfbf6"), (82, 126, 7, 9))
        c.fill(hexc("#c4544a"), (83, 127, 5, 1))
        for k in range(3):
            c.fill(hexc("#9a9aa4"), (83, 129 + k * 2, 4, 1))
        c.fill(hexc("#d8402f"), (85, 125, 1, 1))
        if mo and not self.has_keys:
            c.fill(hexc("#e6c66e"), (86, 120, 4, 2))
            c.fill(hexc("#c4544a"), (90, 120, 2, 3))
        # ban nho + noi com dien
        c.fill(hexc("#8c7356"), (97, 133, 14, 2))
        c.fill(hexc("#6d5a44"), (98, 135, 2, F - 135))
        c.fill(hexc("#6d5a44"), (108, 135, 2, F - 135))
        c.fill(hexc("#f0ece2"), (99, 125, 10, 8))
        c.fill(hexc("#d8d2c4"), (99, 125, 10, 2))
        c.fill(hexc("#d8402f"), (103, 129, 2, 1))
        # ban hoc
        c.fill(hexc("#8c7356"), (114, 132, 44, 2))
        c.fill(hexc("#6d5a44"), (115, 134, 2, F - 134))
        c.fill(hexc("#6d5a44"), (155, 134, 2, F - 134))
        c.fill(hexc("#2e2f38"), (130, 121, 14, 10))
        c.fill(hexc("#2c3e55") if not self.lying else hexc("#1a2230"), (131, 122, 12, 8))
        c.fill(hexc("#55565f"), (128, 131, 18, 1))
        for k, cx in enumerate((118, 123)):
            c.fill(hexc("#f4f2ea"), (cx, 127, 4, 5))
            c.fill(hexc("#d8402f"), (cx, 128, 4, 1))
        c.fill(hexc("#8c6a4c"), (149, 125, 6, 7))
        c.fill(hexc("#e9c99a"), (150, 126, 4, 5))
        if mo:
            c.fill(hexc("#5a3e2c"), (146, 129, 6, 3))   # cai bop bi bo quen
            c.fill(hexc("#7a5a40"), (146, 129, 6, 1))
        # ghe nhua do
        c.fill(hexc("#d0453a"), (121, 140, 12, 2))
        c.fill(hexc("#b2382f"), (122, 142, 2, F - 142))
        c.fill(hexc("#b2382f"), (130, 142, 2, F - 142))
        # quat dung
        c.fill(hexc("#d9d9d4"), (165, 128, 2, F - 128))
        c.fill(hexc("#d9d9d4"), (161, F - 2, 10, 2))
        pygame.draw.circle(c, hexc("#bfc3c8"), (166, 123), 6)
        pygame.draw.circle(c, hexc("#8f949a"), (166, 123), 6, 1)
        c.fill(hexc("#6a9fc8"), (165, 122, 3, 3))
        # cua so
        c.fill(hexc("#6d5a44"), (174, 88, 40, 36))
        if mo:
            vgrad(c, (176, 90, 36, 32), hexc("#a8d0ee"), hexc("#fbe2c0"), 8)
            pygame.draw.circle(c, (255, 246, 220), (204, 112), 5)
            for k, (bx, bh) in enumerate(((176, 8), (184, 13), (196, 6), (204, 10))):
                c.fill(hexc("#b4bdd6"), (bx, 122 - bh, 8, bh))
        else:
            c.fill(hexc("#151a33"), (176, 90, 36, 32))
            for x, y, r in self.city:
                if r < 0.7:
                    c.set_at((x, y), (200, 170, 110) if r < 0.4 else (120, 110, 150))
            for x, y, sp in self.win_rain:
                c.fill((90, 105, 150), (int(x), int(y), 1, 3))
        c.fill(hexc("#6d5a44"), (193, 90, 1, 32))
        c.fill(hexc("#c48a6a"), (176, 88, 7, 34))
        c.fill(hexc("#a87256"), (178, 88, 1, 34))
        if mo and not self.has_bag:
            c.fill(hexc("#5f4f38"), (196, 140, 10, 10))
            c.fill(hexc("#7e6b4c"), (197, 139, 8, 10))
            c.fill(hexc("#5f4f38"), (199, 143, 4, 3))
        # poster
        c.fill(hexc("#2f3a5a"), (226, 86, 20, 26))
        pygame.draw.circle(c, hexc("#e8a33c"), (236, 96), 5)
        c.fill(hexc("#e6dcc6"), (229, 105, 14, 1))
        c.fill(hexc("#e6dcc6"), (231, 108, 10, 1))
        # giuong
        c.fill(hexc("#5d4733"), (BED_X, 138, 62, F - 138))
        c.fill(hexc("#4a3828"), (BED_X, 138, 62, 1))
        c.fill(hexc("#e9e4d8"), (BED_X + 2, 132, 58, 6))
        c.fill(hexc("#d4cebf"), (BED_X + 2, 137, 58, 1))
        c.fill(hexc("#f4f0e6"), (BED_X + 48, 127, 12, 6))
        if self.lying:
            c.blit(self.lie_spr, (BED_X + 28, 121))
            # chan dap toi vai, chi lo dau tren goi
            bl, bd = hexc("#5b7fb0"), hexc("#4a6c9a")
            c.fill(bl, (BED_X + 3, 127, 45, 10))
            c.fill(bl, (BED_X + 8, 125, 38, 2))
            c.fill(bd, (BED_X + 8, 125, 38, 1))
            c.fill(bd, (BED_X + 3, 127, 5, 1))
            c.fill(bd, (BED_X + 46, 126, 2, 1))
            for x in range(BED_X + 6, BED_X + 46, 5):
                c.fill(hexc("#7a9cc8"), (x, 129, 2, 7))
            c.fill(hexc("#d4cebf"), (BED_X + 3, 137, 45, 1))
            if self.phone_t > 0.01 or self.sleep < 0.5:
                c.fill(hexc(PAL_ME["w"]), (BED_X + 44, 119, 2, 6))
                c.fill(hexc(PAL_ME["s"]), (BED_X + 45, 116, 2, 3))
                c.fill(hexc("#1b1b22"), (BED_X + 46, 112, 2, 6))
                c.fill(hexc("#9fd0ff"), (BED_X + 47, 113, 1, 4))
        else:
            c.fill(hexc("#5b7fb0"), (BED_X + 4, 128, 16, 6))
            for x in range(BED_X + 6, BED_X + 20, 5):
                c.fill(hexc("#7a9cc8"), (x, 129, 2, 4))
        # bong den
        c.fill(hexc("#3a3a40"), (160, 64, 1, 10))
        c.fill(hexc("#fff0c8") if self.lights else hexc("#8a8a84"), (158, 74, 4, 4))
        # nguoi
        self.me.draw(c, F)
        # dau cham than tren do vat gan
        if self.marker is not None:
            bob = int(math.sin(t * 5) * 1.5)
            mx = self.marker
            c.fill((255, 236, 160), (mx, 108 + bob, 1, 3))
            c.set_at((mx, 112 + bob), (255, 236, 160))
        # anh sang
        tint = pygame.Surface((W, H))
        if mo:
            tint.fill((246, 240, 232))
        else:
            tint.fill((255, 238, 212) if self.lights else (78, 84, 130))
        tint.fill((200, 200, 230), (176, 90, 36, 32))
        c.blit(tint, (0, 0), special_flags=pygame.BLEND_MULT)
        if mo:
            add_glow(c, self.glow_sunwin, 194, 108, 0.45)
            beam = pygame.Surface((W, H))
            beam.fill((0, 0, 0))
            pygame.draw.polygon(beam, (46, 38, 22), [(176, 90), (212, 90), (250, 150), (206, 150)])
            c.blit(beam, (0, 0), special_flags=pygame.BLEND_ADD)
        elif self.lights:
            add_glow(c, self.glow_bulb, 160, 82, 0.22)
        else:
            add_glow(c, self.glow_win, 194, 112, 0.4)
        if self.lying and (self.phone_t > 0.01 or self.sleep < 0.5) and not self.lights and not mo:
            add_glow(c, self.glow_phone, BED_X + 48, 117, 0.75 * (1 - self.sleep))
        if self.phone_t > 0.001:
            self.draw_phone(c)
        if self.sleep > 0.001:
            v = int(255 * (1 - 0.85 * self.sleep))
            ov = pygame.Surface((W, H))
            ov.fill((v, v, v))
            c.blit(ov, (0, 0), special_flags=pygame.BLEND_MULT)
            lid = int(self.sleep * 92)
            c.fill((0, 0, 0), (0, 0, W, lid))
            c.fill((0, 0, 0), (0, H - lid, W, lid))

    # ---- dien thoai can canh
    PX, PY, PW, PH = 116, 6, 88, 142

    def draw_phone(self, c):
        k = self.phone_t
        ov = pygame.Surface((W, H))
        v = int(255 * (1 - 0.6 * k))
        ov.fill((v, v, v))
        c.blit(ov, (0, 0), special_flags=pygame.BLEND_MULT)
        x, y, w, h = self.PX, int(self.PY + (1 - k) * 40), self.PW, self.PH
        pygame.draw.rect(c, hexc("#121218"), (x, y, w, h), border_radius=8)
        pygame.draw.rect(c, hexc("#3a3a46"), (x, y, w, h), 1, border_radius=8)
        sx, sy, sw, sh = x + 4, y + 10, w - 8, h - 18
        c.fill(hexc("#f2efe8") if self.screen == "photos" else hexc("#15171f"), (sx, sy, sw, sh))
        c.fill(hexc("#2a2a33"), (x + w // 2 - 8, y + 4, 16, 2))
        c.set_clip((sx, sy, sw, sh))
        if self.screen == "photos":
            c.fill(hexc("#e2ddd2"), (sx, sy, sw, 16))
            px = sx + (sw - 68) // 2
            off = int(self.swipe * (sw + 10))
            cur = self.photos[self.photo][1]
            c.blit(cur, (px - off, sy + 30))
            if self.swipe > 0 and self.photo + 1 < len(self.photos):
                c.blit(self.photos[self.photo + 1][1], (px - off + sw + 10, sy + 30))
            ic = hexc("#8a8690")
            iy = sy + 104
            hx = sx + 14
            for dx2, dy2 in ((0, 0), (1, 0), (3, 0), (4, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1),
                             (1, 2), (2, 2), (3, 2), (2, 3)):
                c.set_at((hx + dx2, iy + dy2), hexc("#d8546a"))
            pygame.draw.rect(c, ic, (sx + sw // 2 - 3, iy, 6, 4), 1)
            c.set_at((sx + sw // 2 - 2, iy + 4), ic)
            pygame.draw.lines(c, ic, False, [(sx + sw - 19, iy + 3), (sx + sw - 15, iy), (sx + sw - 15, iy + 1),
                                             (sx + sw - 13, iy + 1)])
            for i in range(len(self.photos)):
                col = hexc("#6a6a74") if i == self.photo else hexc("#c4c0b8")
                c.fill(col, (sx + sw // 2 - 9 + i * 5, sy + 98, 3, 3))
        else:
            tmp = pygame.Surface((19, 5), pygame.SRCALPHA)
            draw_text_px(tmp, "06:30", 0, 0, (240, 240, 245))
            c.blit(pygame.transform.scale(tmp, (57, 15)), (sx + (sw - 57) // 2, sy + 38))
            tx, ty = sx + sw // 2 - 8, sy + 72
            pygame.draw.rect(c, hexc("#5fbf7a"), (tx, ty, 16, 8), border_radius=4)
            pygame.draw.circle(c, hexc("#f4f4f4"), (tx + 12, ty + 4), 3)
        c.set_clip(None)
        # cho lop chu do phan giao dien ve
        self.screen_rect = (sx, sy, sw, sh)

    def draw_hud(self, scr, f):
        if self.rush is not None:
            x, y = WIN_W - 300, 24
            box = pygame.Surface((270, 150), pygame.SRCALPHA)
            box.fill((24, 22, 36, 210))
            scr.blit(box, (x, y))
            pygame.draw.rect(scr, (233, 220, 192), (x, y, 270, 150), 2)
            clk = f.mono_b.render(fmt_time(self.clock), True, (255, 130, 110))
            scr.blit(clk, (x + 270 - clk.get_width() - 14, y + 10))
            scr.blit(f.name.render("Gom đồ!", True, (240, 230, 210)), (x + 16, y + 8))
            for i, (key, label) in enumerate(self.rush_items):
                done = self.rush[key]
                yy = y + 50 + i * 32
                pygame.draw.rect(scr, (200, 200, 210), (x + 18, yy + 6, 18, 18), 2)
                if done:
                    pygame.draw.lines(scr, (120, 220, 140), False, [(x + 21, yy + 15), (x + 26, yy + 21), (x + 34, yy + 8)], 3)
                scr.blit(f.small.render(label, True, (150, 150, 160) if done else (236, 232, 220)), (x + 48, yy + 2))
        if self.phone_t < 0.95 or self.sleep > 0.05:
            return
        sx, sy, sw, sh = self.screen_rect
        cx = (sx + sw // 2) * SCALE
        if self.screen == "photos":
            t = f.small.render("Kỷ niệm", True, (60, 56, 66))
            scr.blit(t, (cx - t.get_width() // 2, sy * SCALE + 6))
            label = self.photos[self.photo][0] if self.swipe < 0.5 else self.photos[min(self.photo + 1, 3)][0]
            t = f.small.render("Ngày này · " + label, True, (90, 86, 96))
            scr.blit(t, (cx - t.get_width() // 2, (sy + 20) * SCALE - 4))
        else:
            t = f.name.render("Báo thức", True, (230, 230, 240))
            scr.blit(t, (cx - t.get_width() // 2, (sy + 8) * SCALE))
            t = f.small.render("Thứ Hai – Thứ Sáu", True, (160, 160, 175))
            scr.blit(t, (cx - t.get_width() // 2, (sy + 58) * SCALE))
            t = f.small.render("Đang reo..." if self.morning else "Ngày mai, 06:30", True,
                               (240, 150, 130) if self.morning else (160, 160, 175))
            scr.blit(t, (cx - t.get_width() // 2, (sy + 86) * SCALE))


PAL_DRIVER_OLD = dict(PAL_DRIVER, g="#7a8498", h="#8a8580", H="#a9a49e", s="#dfb48f", S="#b88a68")


def me_pal(jacket, bag):
    pal = dict(PAL_ME)
    if jacket:
        pal.update(w="#5b6b4a", W="#4a573c")
    if not bag:
        pal.update(b=pal["w"], B=pal["W"])
    return pal


def set_outfit(actor, jacket, bag):
    actor.pal = me_pal(jacket, bag)
    actor.cache = {}
    actor.spr = actor.sprites(actor.expr)


def make_crumpled_ticket():
    t = make_ticket()
    s = pygame.Surface((72, 32), pygame.SRCALPHA)
    s.blit(t, (0, 0))
    crease = (222, 206, 170)
    m = pygame.mask.from_surface(t)
    for (x0, y0, x1, y1) in ((24, 13, 30, 31), (40, 1, 44, 13), (53, 20, 71, 24)):
        steps = max(abs(x1 - x0), abs(y1 - y0))
        for i in range(steps + 1):
            x = int(lerp(x0, x1, i / steps))
            y = int(lerp(y0, y1, i / steps))
            if m.get_at((x, y)) and t.get_at((x, y))[:3] == (243, 230, 196):
                s.set_at((x, y), crease)
    for x in range(72):
        for y in range(32):
            if m.get_at((x, y)) and (x < 3 or y < 2 or y > 29 or x > 68) and (x + y) % 3 == 0:
                s.set_at((x, y), (214, 196, 156))
    big = pygame.transform.scale(s, (144, 64))
    return pygame.transform.rotate(big, 0)


def make_banhmi():
    s = pygame.Surface((60, 20), pygame.SRCALPHA)
    crust, light, dark = hexc("#d9963f"), hexc("#efc06a"), hexc("#a8692c")
    pygame.draw.ellipse(s, dark, (0, 3, 60, 16))
    pygame.draw.ellipse(s, crust, (1, 3, 58, 14))
    pygame.draw.ellipse(s, light, (6, 4, 46, 6))
    for x in (12, 22, 32, 42):
        pygame.draw.line(s, dark, (x, 6), (x + 5, 9))
    # nhan: rau, thit, do chua lo ra
    s.fill(hexc("#6fb04a"), (8, 14, 40, 2))
    s.fill(hexc("#c4544a"), (14, 15, 22, 2))
    s.fill(hexc("#f0a04a"), (30, 15, 12, 2))
    s.fill(hexc("#a8692c"), (6, 16, 46, 2))
    out = pygame.Surface((60, 20), pygame.SRCALPHA)
    out.blit(s, (0, 0))
    return pygame.transform.scale(out, (120, 40))


class Ending:
    def __init__(self, game):
        self.time = 0.0
        self.ticket = make_ticket()
        rnd = random.Random(4)
        self.stars = [(rnd.randint(0, W), rnd.randint(0, H), rnd.random()) for _ in range(80)]
        self.glow = make_glow(50, (120, 100, 70))

    def update(self, dt):
        self.time += dt

    def draw(self, c):
        vgrad(c, (0, 0, W, H), hexc("#0b0d1c"), hexc("#1e1c36"))
        for sx, sy, sr in self.stars:
            tw = 0.5 + 0.5 * math.sin(self.time * 1.2 + sr * 50)
            c.set_at((sx, sy), lerpc((30, 30, 60), (200, 200, 240), tw * sr))
        y = 96 + math.sin(self.time * 1.4) * 3
        add_glow(c, self.glow, W // 2, int(y) + 16, 0.8)
        c.blit(self.ticket, (W // 2 - 36, int(y)))


class Title(Street):
    def __init__(self, game):
        Street.__init__(self, game)
        self.wide_view = False  # man hinh tieu de giu khung rong
        self.minutes = 23 * 60 + 11
        self.ticket = make_ticket()
        self.me.visible = False
        self.glow_t = make_glow(46, (140, 110, 70))

    def update(self, dt):
        Street.update(self, dt)
        self.minutes = 23 * 60 + 11

    def draw(self, c):
        Street.draw(self, c)
        dim = pygame.Surface((W, H))
        dim.fill((120, 120, 150))
        c.blit(dim, (0, 0), special_flags=pygame.BLEND_MULT)
        y = 72 + math.sin(self.time * 1.4) * 3
        add_glow(c, self.glow_t, W // 2, int(y) + 16, 0.7)
        c.blit(self.ticket, (W // 2 - 36, int(y)))


# ---------------------------------------------------------------- UI
def load_font(names, size):
    if WEB:
        # Trinh duyet khong co font he thong: dung font mo kem theo, co nho lai cho bang Segoe UI
        path = resource_path(os.path.join("assets", "fonts", WEB_FONTS[names[0]]))
        return pygame.font.Font(path, max(10, int(size * 0.9)))
    for n in names:
        p = os.path.join(FONT_DIR, n)
        if os.path.exists(p):
            try:
                return pygame.font.Font(p, size)
            except Exception:
                pass
    return pygame.font.SysFont("segoeui,tahoma,arial", size)


class Fonts:
    def __init__(self):
        self.text = load_font(["segoeui.ttf", "tahoma.ttf", "arial.ttf"], 30)
        self.thought = load_font(["segoeuii.ttf", "segoeui.ttf", "tahoma.ttf"], 30)
        self.name = load_font(["segoeuib.ttf", "tahomabd.ttf", "arialbd.ttf"], 26)
        self.hint = load_font(["segoeui.ttf", "tahoma.ttf"], 24)
        self.small = load_font(["segoeui.ttf", "tahoma.ttf"], 22)
        self.cap = load_font(["segoeuil.ttf", "segoeui.ttf", "tahoma.ttf"], 46)
        self.cap_sub = load_font(["segoeui.ttf", "tahoma.ttf"], 30)
        self.title = load_font(["segoeuib.ttf", "tahomabd.ttf", "arialbd.ttf"], 112)
        self.mono = load_font(["consola.ttf", "cour.ttf"], 21)
        self.mono_b = load_font(["consolab.ttf", "consola.ttf"], 22)


def wrap(font, text, maxw):
    words = text.split(" ")
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if font.size(test)[0] <= maxw:
            cur = test
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


class Dialog:
    def __init__(self, name, text, thought, audio, speed=42.0, auto=False):
        self.speed = speed
        self.auto = auto
        self.hold = 0.0
        self.name = name
        self.text = text
        self.thought = thought
        self.shown = 0.0
        self.done = False
        self.age = 0.0
        self.audio = audio
        self.last = 0

    def update(self, dt, confirm):
        self.age += dt
        n = len(self.text)
        if self.shown < n:
            self.shown = min(n, self.shown + dt * self.speed)
            k = int(self.shown) // 3
            if k != self.last:
                self.last = k
                if self.text[int(self.shown) - 1:int(self.shown)].strip():
                    self.audio.play("blip", 0.5 if self.thought else 0.8)
            if confirm and self.age > 0.12:
                self.shown = n
        elif confirm and self.age > 0.12:
            self.done = True
        elif self.auto:  # canh tu chay: doc xong tu sang cau sau
            self.hold += dt
            if self.hold > 1.3 + n / 30.0:
                self.done = True


TERMINAL = [
    "$ ssh admin@prod-server-01",
    "Connected. Last login: Fri 17:44",
    "$ systemctl status shop-api",
    "  shop-api.service: FAILED (code 137)",
    "$ df -h /",
    "  /dev/sda1   98% used",
    "$ journalctl -u shop-api --since today",
    "  ERROR out of memory: killed pid 2231",
    "  ERROR db: too many connections",
    "$ sudo rm -rf /var/log/archive/old/*",
    "  freed 41.2 GB",
    "$ sudo systemctl restart postgresql",
    "  postgresql: active (running)",
    "$ sudo systemctl restart shop-api",
    "  shop-api.service: active (running)",
    "$ curl -I https://shop.client.vn/health",
    "  HTTP/1.1 200 OK",
    "  >> ALL SYSTEMS OPERATIONAL <<",
]


class Minigame:
    START, END = 17 * 60 + 46, 23 * 60

    def __init__(self, game, office):
        self.g = game
        self.o = office
        self.p = 0.0
        self.done = False
        self.shake = 0.0
        self.age = 0.0

    def update(self, dt):
        self.age += dt
        if self.p < 1 and self.g.space_pressed:
            self.p = min(1.0, self.p + 0.045)
            self.g.audio.play(random.choice(("key1", "key2", "key3")), 0.7)
            self.shake = 0.08
        self.shake = max(0.0, self.shake - dt)
        self.o.minutes = self.START + self.p * (self.END - self.START)
        if self.o.lights and self.o.minutes >= 21 * 60 + 30:
            self.o.lights = False
            self.g.audio.play("click")
        if self.p >= 1 and not self.done:
            self.done = True

    def draw(self, scr, f):
        x, y, w, h = 40, 30, 600, 392
        ox = random.randint(-1, 1) if self.shake > 0 else 0
        x += ox
        panel = pygame.Surface((w, h), pygame.SRCALPHA)
        panel.fill((14, 16, 22, 238))
        scr.blit(panel, (x, y))
        pygame.draw.rect(scr, (60, 64, 80), (x, y, w, h), 3)
        pygame.draw.rect(scr, (60, 64, 80), (x, y, w, 30))
        for i, col in enumerate(((224, 96, 90), (230, 190, 90), (110, 190, 110))):
            pygame.draw.circle(scr, col, (x + 18 + i * 20, y + 15), 6)
        scr.blit(f.small.render("admin@prod-server-01 — ssh", True, (200, 204, 214)), (x + 80, y + 2))
        total = len(TERMINAL)
        n_full = int(self.p * total)
        frac = self.p * total - n_full
        lines = TERMINAL[:n_full]
        if n_full < total:
            cur = TERMINAL[n_full]
            lines = lines + [cur[:int(len(cur) * frac)]]
        lines = lines[-12:]
        for i, ln in enumerate(lines):
            col = (150, 220, 150)
            if "ERROR" in ln or "FAILED" in ln or "98%" in ln:
                col = (240, 110, 100)
            elif ln.startswith("$"):
                col = (220, 220, 230)
            elif "OPERATIONAL" in ln or "200 OK" in ln:
                col = (120, 240, 160)
            scr.blit(f.mono.render(ln, True, col), (x + 16, y + 40 + i * 25))
        if int(self.age * 2.5) % 2 == 0 and not self.done:
            cy = y + 40 + (len(lines) - 1) * 25
            cx = x + 16 + f.mono.size(lines[-1] if lines else "")[0] + 2
            pygame.draw.rect(scr, (150, 220, 150), (cx, cy + 3, 11, 20))
        # thanh tien do
        by = y + h - 50
        pygame.draw.rect(scr, (40, 44, 56), (x + 16, by, w - 32, 22))
        pygame.draw.rect(scr, (120, 200, 140) if self.done else (220, 160, 80),
                         (x + 16, by, int((w - 32) * self.p), 22))
        pygame.draw.rect(scr, (90, 96, 112), (x + 16, by, w - 32, 22), 2)
        pct = f.small.render("%d%%" % int(self.p * 100), True, (230, 230, 236))
        scr.blit(pct, (x + w // 2 - pct.get_width() // 2, by - 1))
        clk = f.mono_b.render(fmt_time(self.o.minutes), True, (255, 130, 110))
        scr.blit(clk, (x + w - clk.get_width() - 16, y + 4))


# ---------------------------------------------------------------- chuong 2: lang cu
K2_STAND = [".....xSs.sSs....", ".....sSs.sSs....", ".....ooo.OOO...."]
K2_RUN_A = ["....xS...ss.....", "...sS.....ss....", "..oo.......OO..."]
K2_RUN_B = ["......xSss......", "......sS.ss.....", ".....oo..OO....."]
K2_SIT = [".....xSSSSsss...", "............OO.."]


def kid_pal(hair, shirt, shirt2, shorts, shorts2, skin="#d8a275", skin2="#b47f58",
            sleeveless=False, scar=False, foot="#7a5a3a", foot2=None):
    return dict(PAL_ME, h=hair, H=lerp_hex(hair, "#ffffff", 0.18), s=skin, S=skin2, g=skin,
                e="#2a2230", w=shirt, W=shirt2, b=skin if sleeveless else shirt,
                B=skin2 if sleeveless else shirt2, p=shorts, P=shorts2, r=shirt,
                o=foot, O=foot2 or foot, x="#a0503f" if scar else skin2)


def lerp_hex(a, b, t):
    return "#%02x%02x%02x" % lerpc(hexc(a), hexc(b), t)


KID_SHAPES = {
    "normal": (KID_BODY, K2_STAND, K2_RUN_A, K2_RUN_B, K2_SIT),
    "thin": (["......wwww......", ".....bwrrwW.....", ".....bwwrwW.....", ".....bwwwwW.....", ".....swwwws.....", "......pppp......"],
             ["......xS.sS.....", "......sS.sS.....", "......oo.OO....."],
             [".....xS...s.....", "....sS.....s....", "...oo......OO..."],
             ["......xSs.......", "......sS.s......", ".....oo..OO....."],
             ["......xSSSss....", "...........OO..."]),
    "fat": (["....wwwwwwww....", "..bwwwrrwwwwWw..", ".bBwwwwwrwwwWWw.", ".bBwwwwwwwwwWWs.", "..swwwwwwwwwWs..", "...pppppppppp..."],
            ["....xSSs.sSSs...", "....sSSs.sSSs...", "....oooo.OOOO..."],
            ["...xSS....sSs...", "..sSS......sSs..", ".ooo.......OOO.."],
            ["......xSSss.....", "......sSS.ss....", ".....ooo..OOO..."],
            ["....xSSSSSSsss..", "............OOO."]),
}


def narrow_head(rows):
    return ["." + r[0] + r[2:14] + r[15] + "." for r in rows]


def widen_head(rows):
    out = []
    for i, r in enumerate(rows):
        if i >= 8:  # ma phung phinh
            a = list(r)
            first = next(k for k, ch in enumerate(a) if ch != ".")
            last = len(a) - 1 - next(k for k, ch in enumerate(reversed(a)) if ch != ".")
            if first > 0:
                a[first - 1] = "S"
            if last < len(a) - 1:
                a[last + 1] = "s"
            r = "".join(a)
        out.append(r)
    return out


def build_kid_char(pal, female=False, build="normal", expr="smile"):
    head = HEAD_KID_F if female else HEAD_KID
    if build == "thin":
        head = narrow_head(head)
    elif build == "fat":
        head = widen_head(head)
    head = apply_expr(head, expr)
    body, stand, run_a, run_b, sit = KID_SHAPES[build]

    def mk(legs):
        return make_sprite(head + body + legs, pal)
    idle = mk(stand)
    return {"idle": idle, "walk": [mk(run_a), idle, mk(run_b), idle], "sit": mk(sit)}


class Kid(Actor):
    def __init__(self, x, pal, female=False, facing=1, state="idle", build=None, expr="smile"):
        self.x = float(x)
        self.pal = pal
        self.facing = facing
        self.state = state
        self.anim = 0.0
        self.visible = True
        self.female = female or bool(pal.get("_f"))
        self.head = None
        self.build = build or pal.get("_b", "normal")
        self.expr = expr
        self.cache = {}
        self.spr = self.sprites(expr)

    def make(self, expr):
        return build_kid_char(self.pal, self.female, self.build, expr)


# "Thang nhoc": ao thun bac mau, quan dui, dep le khong cung mau, seo o dau goi
PAL_KID_ME = kid_pal("#2a2024", "#9fb5a8", "#7f9488", "#54648a", "#414f70", scar=True,
                     foot="#c0483c", foot2="#3f78b8")
# Ban cua NVC: Teo trai om, Na con gai, Hung trai map
PAL_KID_TEO = dict(kid_pal("#1e1a1c", "#e8e4d6", "#c4bfae", "#6a5a44", "#514433", sleeveless=True), _b="thin")
PAL_KID_NA = dict(kid_pal("#3a2018", "#d2505a", "#a83e48", "#d2505a", "#a83e48", skin="#e2b088", skin2="#c08e6a", foot="#d8a040"), _f=True)
PAL_KID_HUNG = dict(kid_pal("#17151a", "#6f93b8", "#557596", "#7a4a3c", "#5e382d", sleeveless=True, skin="#c8935f", skin2="#a57446"), _b="fat")
PAL_GIRL_THAM = kid_pal("#20181c", "#d98aa0", "#b56d82", "#5c4a78", "#47395f", skin="#e2b088", skin2="#c08e6a")
PAL_GIRL_NA = kid_pal("#3a241e", "#e8cf72", "#c2a955", "#a8574f", "#86433d", skin="#dcaa80", skin2="#ba8860")
PAL_BA_NGA = dict(PAL_MOTHER, h="#3c3634", H="#8c8680", w="#6f8a7a", W="#566d5f", b="#6f8a7a", B="#566d5f",
                  p="#2f2a32", P="#221e26", s="#e3b48e", S="#c08e6c", g="#e3b48e")
PAL_ONG = dict(PAL_ME, h="#8c8780", H="#b4aea4", s="#d8a982", S="#b48760", g="#d8a982", w="#d6cfb8", W="#b0a890",
               b="#d6cfb8", B="#b0a890", p="#4a4a48", P="#363634", o="#5a4636")
PAL_BA_NOI = dict(PAL_ME, h="#5a5450", H="#8a847c", s="#deb18c", S="#bb8d68", g="#deb18c", w="#6e5a78", W="#574662", b="#6e5a78", B="#574662",
                  p="#2f2a32", P="#221e26", o="#5a4636")
PAL_HA_CAO = dict(PAL_OLD, h="#cfcac0", H="#ece8df", w="#ece6d6", W="#c6bfae", b="#ece6d6", B="#c6bfae",
                  p="#50463c", P="#3a332b", g="#dfb48f")

# mau ve lang
C_DIRT = hexc("#b98f5f")
C_DIRT_D = hexc("#a27a50")
C_DIRT_L = hexc("#cfa878")
C_GRASS = hexc("#7f9a4a")
C_GRASS_D = hexc("#64803a")
C_GRASS_L = hexc("#9fb65e")
C_LEAF = hexc("#5f8440")
C_LEAF_D = hexc("#3f6230")
C_LEAF_L = hexc("#86a854")

PLACE_FLOOR = {"gate": 150, "road": 150, "xom": 150, "bamboo": 150, "shop": 150,
               "cart": 150, "dinh": 150, "tree": 150, "porch": 150, "alley": 150, "home_out": 150, "home": 150, "meal": 150, "school": 150, "field": 150, "now": 150, "now_lane": 150, "home_now": 150}
PLACE_TINT = {"gate": (255, 246, 226), "road": (255, 246, 226), "xom": (255, 244, 222),
              "bamboo": (246, 246, 220), "shop": (250, 230, 200), "cart": (255, 242, 214),
              "dinh": (255, 246, 220), "tree": (255, 236, 200), "porch": (166, 172, 200), "alley": (156, 162, 194),
              "home_out": (150, 156, 190), "home": (255, 232, 190), "meal": (255, 226, 176),
              "school": (176, 186, 226), "field": (176, 186, 226), "now": (255, 248, 232), "now_lane": (255, 246, 228), "home_now": (255, 246, 226)}
INDOOR = ("shop", "home", "meal")  # canh trong nha: khung gan x2


def speckle(c, rect, cols, n, rnd):
    x, y, w, h = rect
    for _ in range(n):
        c.set_at((rnd.randrange(x, x + w), rnd.randrange(y, y + h)), rnd.choice(cols))


def paint_cloud(c, x, y, rnd):
    parts = [(rnd.randint(-18, 18), rnd.randint(4, 8)) for _ in range(6)]
    for dx, r in parts:
        pygame.draw.circle(c, (226, 216, 206), (x + dx, y + 2), r)
    for dx, r in parts:
        pygame.draw.circle(c, (250, 244, 230), (x + dx, y), max(2, r - 1))


def paint_sky(c, top, bot, hor, rnd, clouds=4):
    vgrad(c, (0, 0, W, hor), hexc(top), hexc(bot))
    for _ in range(clouds):
        paint_cloud(c, rnd.randint(0, W), rnd.randint(10, max(12, hor // 2)), rnd)


def paint_far(c, y, rnd, col="#7f9c78", col2="#94ae88"):
    """Dai cay xa o chan troi."""
    a, b = hexc(col), hexc(col2)
    for x in range(-4, W + 4, 5):
        r = rnd.randint(4, 9)
        pygame.draw.circle(c, a, (x, y - rnd.randint(0, 5)), r)
    c.fill(a, (0, y, W, 6))
    for _ in range(420):  # dom la sang, khong ve vong tron
        px, py = rnd.randint(0, W - 2), rnd.randint(y - 12, y + 3)
        if c.get_at((px, py))[:3] == a:
            c.fill(b, (px, py, rnd.randint(1, 3), 1))


def paint_rice(c, y0, y1, rnd):
    vgrad(c, (0, y0, W, y1 - y0), hexc("#a9c267"), hexc("#86a64c"), 8)
    for y in range(y0 + 1, y1, 3):
        col = (118 + rnd.randint(0, 22), 150 + rnd.randint(0, 20), 70)
        for x in range(rnd.randint(0, 3), W, 4):
            c.set_at((x, y), col)
    for x in range(10, W, 76):
        pygame.draw.line(c, hexc("#b7a06a"), (x, y1), (x + 26, y0), 1)


def paint_road(c, y0, rnd):
    c.fill(C_GRASS, (0, y0, W, H - y0))
    speckle(c, (0, y0, W, 5), [C_GRASS_D, C_GRASS_L], 240, rnd)
    c.fill(C_DIRT, (0, y0 + 5, W, 31))
    c.fill(C_GRASS, (0, y0 + 36, W, H - y0 - 36))
    speckle(c, (0, y0 + 36, W, H - y0 - 36), [C_GRASS_D, C_GRASS_L], 420, rnd)
    speckle(c, (0, y0 + 5, W, 31), [C_DIRT_D, C_DIRT_L], 900, rnd)
    for y in (y0 + 13, y0 + 26):  # vet banh xe bo
        px = rnd.randint(0, 3)
        for x in range(0, W, 2):
            if rnd.random() < 0.9:
                c.set_at((x, y + px), C_DIRT_D)
            if rnd.random() < 0.08:
                px = clamp(px + rnd.choice((-1, 1)), 0, 3)
    for _ in range(26):  # soi
        x, y = rnd.randint(0, W), rnd.randint(y0 + 6, y0 + 34)
        c.fill(hexc("#d9c4a0"), (x, y, 2, 1))
        c.set_at((x, y + 1), hexc("#8a6a48"))
    paint_tufts(c, y0 + 2, 26, rnd)
    paint_tufts(c, y0 + 40, 30, rnd)


def paint_tufts(c, y, n, rnd):
    for _ in range(n):
        x = rnd.randint(0, W)
        for k in (-1, 0, 1):
            h = rnd.randint(2, 4)
            pygame.draw.line(c, C_GRASS_D if k else C_GRASS_L, (x, y + 3), (x + k * 2, y + 3 - h))


LEAF_RAMP = [hexc(k) for k in ("#2e4a2c", "#3d6231", "#527e38", "#6d9a42", "#8db450", "#aeca68")]


def paint_canopy(c, blobs, rnd, clump=(4, 8)):
    """Tan cay lien khoi: nen toi, nhieu cum la nho, dom la sang phia tren. Tra ve cac cum."""
    clumps = []
    for cx, cy, rx, ry in blobs:
        for _ in range(int(rx * ry / 9) + 6):
            a, d = rnd.uniform(0, 6.283), rnd.random() ** 0.55
            x, y = cx + math.cos(a) * rx * d, cy + math.sin(a) * ry * d
            clumps.append((int(x), int(y), rnd.randint(*clump), (cy - y) / max(1, ry)))
    put_px = c.set_at
    for x, y, r, lift in clumps:
        rr = r + 2
        for dy in range(-rr, rr + 1):
            for dx in range(-rr, rr + 1):
                if dx * dx + dy * dy <= rr * rr * rnd.uniform(0.55, 1.0):
                    put_px((x + dx, y + dy), LEAF_RAMP[1 if lift > -0.2 else 0])
    clumps.sort(key=lambda k: k[1])
    for x, y, r, lift in clumps:
        base = 2.0 + lift * 0.8
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dy * dy > r * r * rnd.uniform(0.5, 1.0):
                    continue
                shade = base + (-dx - dy * 1.4) / r * 0.9 + rnd.uniform(-0.45, 0.45)
                put_px((x + dx, y + dy), LEAF_RAMP[int(clamp(round(shade), 1, 4))])
    for x, y, r, lift in clumps:
        if lift < -0.35:
            continue
        for _ in range(rnd.randint(1, 3)):
            px, py = x - rnd.randint(0, r), y - rnd.randint(0, r)
            col = LEAF_RAMP[5 if rnd.random() < 0.35 else 4]
            put_px((px, py), col)
            put_px((px + 1, py - 1 if rnd.random() < 0.5 else py + 1), col)
    return clumps


def paint_trunk(c, x, base, top, w, rnd, lean=0):
    """Than cay thon dan, loe o goc, co van vo."""
    light, mid, dark = hexc("#8a6a48"), hexc("#6e5238"), hexc("#4b3726")
    h = max(1, base - top)
    for y in range(top, base + 1):
        t = (base - y) / h
        half = w / 2.0 * (1 - 0.42 * t)
        if t < 0.14:
            half += (0.14 - t) * w * 1.7
        cx = x + lean * t * t
        x0, x1 = int(cx - half), int(cx + half)
        pygame.draw.line(c, mid, (x0, y), (x1, y))
        c.set_at((x0, y), dark)
        c.set_at((x1, y), dark)
        if x1 - x0 > 6:
            c.fill(light, (x0 + 1, y, max(1, (x1 - x0) // 4), 1))
            c.fill(dark, (x1 - (x1 - x0) // 4, y, (x1 - x0) // 4, 1))
    for _ in range(int(h * w / 16)):
        y = rnd.randint(top, base - 4)
        t = (base - y) / h
        half = int(w / 2.0 * (1 - 0.42 * t))
        px = int(x + lean * t * t) + rnd.randint(-max(1, half - 1), max(1, half - 1))
        pygame.draw.line(c, rnd.choice((dark, light, dark)), (px, y), (px, y + rnd.randint(1, 4)))


def paint_branch(c, x0, y0, x1, y1, w):
    px, py = x0, y0
    for k in range(1, 9):
        t = k / 8
        nx = lerp(x0, x1, t)
        ny = lerp(y0, y1, t) + math.sin(t * 3.14) * -2
        ww = max(1, int(round(w * (1 - 0.7 * t))))
        pygame.draw.line(c, hexc("#4b3726"), (px, py + 1), (nx, ny + 1), ww + 1)
        pygame.draw.line(c, hexc("#6e5238"), (px, py), (nx, ny), ww)
        px, py = nx, ny


def paint_tree(c, x, base, h, r, rnd):
    top = base - h
    w = max(6, r // 3)
    paint_trunk(c, x, base, top, w, rnd)
    paint_branch(c, x, top + r // 3, x - int(r * 0.72), top + r // 8, max(2, w // 3))
    paint_branch(c, x, top + r // 4, x + int(r * 0.74), top + r // 10, max(2, w // 3))
    paint_canopy(c, [(x, top - 2, r, int(r * 0.62)),
                     (x - int(r * 0.72), top + int(r * 0.2), int(r * 0.62), int(r * 0.42)),
                     (x + int(r * 0.74), top + int(r * 0.18), int(r * 0.66), int(r * 0.44)),
                     (x + rnd.randint(-r // 4, r // 4), top - int(r * 0.45), int(r * 0.6), int(r * 0.34))], rnd)


def paint_bamboo(c, x, base, h, rnd, spread=9):
    for i in range(rnd.randint(5, 7)):
        bx = x + rnd.randint(-spread, spread)
        lean = rnd.randint(-14, 14)
        hh = h + rnd.randint(-14, 14)
        col = lerpc(hexc("#8aa24a"), hexc("#5f7f3a"), rnd.random())
        n = 16
        px, py = bx, base
        for k in range(1, n + 1):
            t = k / n
            nx = int(bx + lean * t * t)
            ny = int(base - hh * t)
            pygame.draw.line(c, col, (px, py), (nx, ny), 2)
            c.fill(hexc("#46602c"), (nx - 1, ny, 3, 1))
            px, py = nx, ny
            if t > 0.4:
                side = 1 if k % 2 else -1
                for j in range(rnd.randint(3, 5)):
                    lx = nx + side * rnd.randint(3, 13)
                    ly = ny + rnd.randint(0, 7)
                    pygame.draw.line(c, rnd.choice((C_LEAF, C_LEAF_D, C_LEAF_L, hexc("#a2b85e"))), (nx, ny), (lx, ly))


def paint_banana(c, x, base, rnd):
    pygame.draw.line(c, hexc("#8fa058"), (x, base), (x, base - 26), 3)
    pygame.draw.line(c, hexc("#6d7f40"), (x - 1, base), (x - 1, base - 26))
    for s, ln, dy in ((-1, 22, 6), (1, 24, 4), (-1, 18, -6), (1, 16, -8), (0, 8, -18)):
        pts = [(x, base - 26)]
        for k in range(1, 6):
            t = k / 5
            pts.append((x + s * ln * t + (0 if s else 2 * k), base - 26 + dy * t + 6 * t * t * (1 if s else 0) + (dy * t if not s else 0)))
        for p0, p1 in zip(pts, pts[1:]):
            pygame.draw.line(c, C_LEAF_L, p0, p1, 3)
            pygame.draw.line(c, C_LEAF_D, (p0[0], p0[1] + 2), (p1[0], p1[1] + 2))
        pygame.draw.lines(c, hexc("#c5d27a"), False, pts)


def paint_house(c, x, base, w, h, roof, wall, rnd, door=True):
    wall_c = hexc(wall)
    c.fill(wall_c, (x, base - h, w, h))
    dk = lerpc(wall_c, (60, 50, 40), 0.3)
    lt = lerpc(wall_c, (255, 250, 230), 0.25)
    c.fill(dk, (x, base - 4, w, 4))
    for _ in range(6):  # tuong bong troc
        px, py = rnd.randint(x, x + w - 8), rnd.randint(base - h + 3, base - 10)
        ww = rnd.randint(4, 9)
        c.fill(rnd.choice((dk, lt)), (px, py, ww, rnd.randint(1, 3)))
    speckle(c, (x, base - h, w, h), [dk, lt], w * h // 18, rnd)
    rh = max(10, int(h * 0.62))
    cols = {"tile": ("#9c5a3c", "#7f4630", "#b87050"), "thatch": ("#b79a5a", "#8f7640", "#d2b873"),
            "tin": ("#8c8a82", "#6b6a64", "#a65f3e")}[roof]
    a, b, d = [hexc(k) for k in cols]
    pts = [(x - 6, base - h), (x + w + 5, base - h), (x + w - 5, base - h - rh), (x + 5, base - h - rh)]
    pygame.draw.polygon(c, a, pts)
    for y in range(base - h - rh + 2, base - h, 3):
        pygame.draw.line(c, b, (x - 5, y), (x + w + 4, y))
        for xx in range(x + (y % 5), x + w + 1, 5):
            c.set_at((xx, y + 1), b if roof != "tin" else d)
            if roof == "thatch" and rnd.random() < 0.6:
                c.set_at((xx + 2, y + 2), d)
    for _ in range(int(w * 0.5)):
        c.set_at((rnd.randint(x + 5, x + w - 6), rnd.randint(base - h - rh + 1, base - h - 1)), d)
    # mai che sat tuong (bong do)
    c.fill(lerpc(wall_c, (40, 34, 30), 0.45), (x, base - h, w, 3))
    wood = hexc("#6a4a30")
    wood_l = hexc("#86603e")
    if door:
        dx = x + w // 2 - 6
        c.fill(wood, (dx, base - 26, 13, 26))
        c.fill(wood_l, (dx + 1, base - 25, 5, 25))
        c.fill(hexc("#4b3424"), (dx + 6, base - 25, 1, 25))
        wx = [x + 5, x + w - 18] if w > 44 else []
    else:
        wx = [x + w // 2 - 7]
    for px in wx:
        c.fill(hexc("#2e2a30"), (px, base - 23, 13, 11))
        c.fill(wood_l, (px - 1, base - 24, 15, 1))
        c.fill(wood_l, (px - 1, base - 12, 15, 2))
        for k in range(1, 13, 3):
            c.fill(wood, (px + k, base - 23, 1, 11))


def paint_fence(c, x0, x1, base, rnd):
    col = hexc("#a08a58")
    dk = hexc("#7a6840")
    for x in range(x0, x1, 4):
        hh = rnd.randint(12, 15)
        c.fill(col, (x, base - hh, 2, hh))
        c.set_at((x + 1, base - hh), dk)
    for y in (base - 11, base - 5):
        pygame.draw.line(c, dk, (x0 - 1, y), (x1, y))


def paint_gate(c, cx, base, rnd):
    col = hexc("#c9bda4")
    dk = hexc("#9f937c")
    lt = hexc("#e0d6bf")
    moss = hexc("#6f8450")
    for px in (cx - 40, cx + 30):
        c.fill(col, (px, base - 64, 11, 64))
        c.fill(lt, (px, base - 64, 3, 64))
        c.fill(dk, (px + 9, base - 64, 2, 64))
        c.fill(dk, (px - 2, base - 68, 15, 4))
        c.fill(lt, (px - 2, base - 68, 15, 1))
        for _ in range(10):
            c.fill(rnd.choice((moss, dk)), (px + rnd.randint(0, 8), base - rnd.randint(1, 60), rnd.randint(1, 3), rnd.randint(1, 3)))
    c.fill(col, (cx - 30, base - 62, 60, 15))
    c.fill(lt, (cx - 30, base - 62, 60, 2))
    c.fill(dk, (cx - 30, base - 49, 60, 2))
    c.fill(hexc("#7e3a2f"), (cx - 21, base - 59, 42, 9))
    draw_text_px(c, "LANG TRE", cx - text_px_width("LANG TRE") // 2, base - 57, hexc("#efe2bc"))
    tile = hexc("#8a5038")
    pygame.draw.polygon(c, tile, [(cx - 48, base - 66), (cx + 48, base - 66), (cx + 38, base - 76), (cx - 38, base - 76)])
    for y in range(base - 75, base - 66, 2):
        pygame.draw.line(c, hexc("#6d3e2b"), (cx - 46, y), (cx + 46, y))
    speckle(c, (cx - 40, base - 76, 80, 10), [moss], 34, rnd)


def paint_marble_ring(c, cx, cy, rnd):
    pygame.draw.ellipse(c, C_DIRT_D, (cx - 24, cy - 8, 48, 16), 1)
    for col, dx, dy in (("#58a0d8", -9, 1), ("#d85a5a", 2, -2), ("#e0c04a", 8, 2), ("#62c07a", -2, 4)):
        c.fill(hexc(col), (cx + dx, cy + dy, 2, 2))


def make_tint(col):
    s = pygame.Surface((W, H))
    s.fill(col)
    dark = lerpc(col, (0, 0, 0), 0.34)
    # toi 4 goc cho cam giac anh cu
    for y in range(0, H, 2):
        for x in range(0, W, 2):
            nx, ny = (x - W / 2) / (W / 2), (y - H / 2) / (H / 2)
            d = nx * nx + ny * ny
            if d > 0.9:
                s.fill(lerpc(col, dark, min(1.0, (d - 0.9) / 1.0)), (x, y, 2, 2))
    return s


_place_cache = {}


def paint_place(name):
    """Tra ve (nen, lop truoc nhan vat, tint). Ve 1 lan roi giu lai."""
    if name in _place_cache:
        return _place_cache[name]
    c = pygame.Surface((W, H))
    rnd = random.Random(sum(map(ord, name)) * 7)
    fg = None
    if name == "gate":
        paint_sky(c, "#8fc0dc", "#f3e6c4", 100, rnd, 5)
        paint_far(c, 100, rnd)
        paint_rice(c, 104, 134, rnd)
        paint_bamboo(c, 66, 134, 96, rnd, 18)
        paint_bamboo(c, 260, 134, 104, rnd, 20)
        paint_banana(c, 22, 134, rnd)
        paint_road(c, 134, rnd)
        paint_gate(c, 160, 138, rnd)
    elif name == "road":
        paint_sky(c, "#8fc0dc", "#f3e6c4", 96, rnd, 4)
        paint_far(c, 96, rnd)
        paint_rice(c, 100, 134, rnd)
        paint_house(c, 14, 134, 62, 36, "thatch", "#c8b48c", rnd)
        paint_banana(c, 92, 134, rnd)
        paint_house(c, 110, 134, 70, 40, "tile", "#d6c8a4", rnd)
        paint_fence(c, 186, 244, 134, rnd)
        paint_tree(c, 280, 134, 62, 28, rnd)
        paint_road(c, 134, rnd)
        paint_marble_ring(c, 250, 150, rnd)
    elif name == "xom":
        paint_sky(c, "#92c2dc", "#f4e6c2", 96, rnd, 3)
        paint_far(c, 96, rnd)
        paint_rice(c, 100, 134, rnd)
        paint_house(c, 6, 134, 64, 38, "tin", "#b8c0a8", rnd)
        paint_tree(c, 92, 134, 54, 22, rnd)
        paint_house(c, 112, 134, 66, 36, "thatch", "#cdb891", rnd)
        # tiem tap hoa
        c.fill(hexc("#dcc99c"), (196, 92, 112, 42))
        speckle(c, (196, 92, 112, 42), [hexc("#c2ae82"), hexc("#ece0bd")], 260, rnd)
        c.fill(hexc("#3a3236"), (214, 106, 58, 28))
        for x, col in zip(range(218, 268, 7), ("#c8483c", "#e0c04a", "#5a9ad0", "#d0d0c0", "#62a860", "#d0763c", "#c04870", "#e8e0c8")):
            c.fill(hexc(col), (x, 110, 5, 9))
            c.fill(hexc(col), (x + 2, 122, 4, 8))
        pygame.draw.polygon(c, hexc("#a85a44"), [(190, 92), (314, 92), (304, 76), (200, 76)])
        for x in range(194, 312, 8):
            pygame.draw.line(c, hexc("#d9c9a0"), (x, 92), (x + 4 if x < 252 else x - 4, 76))
        c.fill(hexc("#7e3a2f"), (222, 66, 56, 11))
        draw_text_px(c, "TAP HOA", 250 - text_px_width("TAP HOA") // 2, 69, hexc("#f0e4c0"))
        # to lich tren tuong
        c.fill(hexc("#f0ece0"), (199, 100, 11, 15))
        c.fill(hexc("#c8483c"), (199, 100, 11, 4))
        c.fill(hexc("#555055"), (201, 106, 7, 6))
        paint_road(c, 134, rnd)
    elif name == "bamboo":
        paint_sky(c, "#a7cfae", "#f0ecc0", 90, rnd, 1)
        paint_far(c, 94, rnd, "#7c9c62", "#8fae6e")
        c.fill(hexc("#9aa95e"), (0, 94, W, 40))
        for x in range(-8, W + 10, 22):
            paint_bamboo(c, x + rnd.randint(-6, 6), 136, 118, rnd, 11)
        paint_fence(c, 8, 60, 134, rnd)
        paint_road(c, 134, rnd)
        # muong ben phai
        c.fill(hexc("#6f8d80"), (278, 170, 42, 10))
    elif name == "shop":
        # the gioi 240 rong; camera chi nhin y 76..166 va phong to 2 lan (xem Village)
        c.fill(hexc("#9a7a55"), (0, 0, W, 150))
        for x in range(0, W, 9):
            c.fill(hexc("#856845"), (x, 0, 1, 150))
        speckle(c, (0, 78, W, 72), [hexc("#8a6c4a"), hexc("#ab8a62")], 420, rnd)
        c.fill(hexc("#4c3522"), (0, 76, W, 4))
        c.fill(hexc("#6b4c30"), (0, 80, W, 1))
        c.fill(hexc("#fff6dc"), (0, 94, 17, 56))  # cua ra duong
        c.fill(hexc("#5f4630"), (17, 91, 3, 59))
        c.fill(hexc("#5f4630"), (0, 91, 20, 3))
        pygame.draw.line(c, hexc("#3c2c20"), (28, 83), (236, 83))
        for x in range(30, 232, 7):  # goi mi treo
            c.fill(hexc("#e0a83c"), (x, 84, 5, 7))
            c.fill(hexc("#c8483c"), (x + 1, 86, 3, 3))
        for sy in (104, 118):
            c.fill(hexc("#6b4c30"), (28, sy, 208, 2))
            c.fill(hexc("#4c3522"), (28, sy + 2, 208, 1))
            x = 30
            while x < 232:
                w = rnd.randint(3, 6)
                h = rnd.randint(5, 9)
                col = hexc(rnd.choice(("#c8483c", "#e0c04a", "#5a9ad0", "#e8e0c8", "#62a860", "#d0763c", "#c04870", "#8a6ab0")))
                c.fill(col, (x, sy - h, w, h))
                c.set_at((x, sy - h), lerpc(col, (255, 255, 255), 0.45))
                c.fill(lerpc(col, (0, 0, 0), 0.3), (x + w - 1, sy - h, 1, h))
                if rnd.random() < 0.35:
                    c.fill(hexc("#efe6d0"), (x + 1, sy - h + 2, max(1, w - 2), 2))
                x += w + rnd.randint(0, 2)
        c.fill(hexc("#7a7468"), (0, 150, W, 30))
        for y in (156, 162):
            pygame.draw.line(c, hexc("#67625a"), (0, y), (W, y))
        speckle(c, (0, 150, W, 30), [hexc("#67625a"), hexc("#8e887a")], 260, rnd)
        # tu kinh banh keo (thap hon vai nguoi lon)
        c.fill(hexc("#5f4630"), (56, 139, 46, 11))
        c.fill(hexc("#86603e"), (56, 139, 46, 1))
        c.fill(hexc("#c6dcd8"), (58, 126, 42, 13))
        c.fill(hexc("#eef6ee"), (60, 128, 9, 1))
        for _ in range(46):
            px, py = rnd.randint(60, 97), rnd.randint(131, 137)
            c.set_at((px, py), hexc(rnd.choice(("#d85a5a", "#e0c04a", "#58a0d8", "#62c07a", "#e080a8", "#f0e8d8"))))
        pygame.draw.rect(c, hexc("#4c3522"), (58, 126, 42, 13), 1)
        fg = pygame.Surface((W, H), pygame.SRCALPHA)
        fg.fill(hexc("#6b4c30"), (176, 136, 60, 14))
        fg.fill(hexc("#86603e"), (174, 134, 64, 3))
        for x in range(180, 234, 8):
            fg.fill(hexc("#5a3f28"), (x, 138, 1, 12))
        fg.fill(hexc("#d9e8e2"), (182, 127, 6, 7))
        fg.fill(hexc("#e0c04a"), (183, 130, 4, 3))
        fg.fill(hexc("#d9e8e2"), (222, 129, 6, 5))
        fg.fill(hexc("#d85a5a"), (223, 131, 4, 2))
    elif name == "cart":
        paint_sky(c, "#8dbfdc", "#f4e4bc", 94, rnd, 3)
        paint_far(c, 94, rnd)
        paint_rice(c, 98, 134, rnd)
        paint_house(c, 8, 134, 58, 34, "tile", "#c7b990", rnd, door=False)
        paint_fence(c, 72, 130, 134, rnd)
        paint_tree(c, 214, 134, 68, 34, rnd)
        paint_road(c, 134, rnd)
        # bong cay
        s = pygame.Surface((110, 16), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (60, 40, 40, 70), (0, 0, 110, 16))
        c.blit(s, (158, 140))
        # xe ha cao
        cx = 196
        for wx in (cx - 14, cx + 14):
            pygame.draw.circle(c, hexc("#3a3236"), (wx, 150), 6)
            pygame.draw.circle(c, hexc("#a09888"), (wx, 150), 3)
        c.fill(hexc("#84583a"), (cx - 24, 128, 48, 16))
        c.fill(hexc("#a4744c"), (cx - 24, 128, 48, 3))
        c.fill(hexc("#c8483c"), (cx - 18, 133, 36, 8))
        draw_text_px(c, "HA CAO", cx - text_px_width("HA CAO") // 2, 135, hexc("#f4e8c8"))
        c.fill(hexc("#b8b8b0"), (cx - 13, 112, 26, 16))
        c.fill(hexc("#dcdcd4"), (cx - 13, 112, 7, 16))
        c.fill(hexc("#8e8e88"), (cx + 9, 112, 4, 16))
        pygame.draw.ellipse(c, hexc("#c8c8c0"), (cx - 15, 107, 30, 8))
        c.fill(hexc("#6a6a66"), (cx - 2, 104, 4, 4))
        pygame.draw.line(c, hexc("#6e5238"), (cx + 24, 130), (cx + 40, 122), 2)
    elif name == "dinh":
        paint_sky(c, "#86bddc", "#f6e6ba", 100, rnd, 2)
        paint_far(c, 100, rnd)
        paint_rice(c, 104, 134, rnd)
        # dinh lang nhin tu phia sau
        c.fill(hexc("#d8c79a"), (46, 86, 160, 48))
        speckle(c, (46, 86, 160, 48), [hexc("#c0ae82"), hexc("#ecdfb8")], 460, rnd)
        for x in range(60, 200, 34):
            c.fill(hexc("#8f4a36"), (x, 86, 6, 48))
            c.fill(hexc("#a85a44"), (x, 86, 2, 48))
        pts = [(28, 90), (36, 82), (216, 82), (226, 90), (204, 58), (52, 58)]
        pygame.draw.polygon(c, hexc("#92553c"), pts)
        for y in range(60, 88, 3):
            pygame.draw.line(c, hexc("#74402c"), (38, y), (214, y))
        for x in range(46, 210, 5):
            pygame.draw.line(c, hexc("#a8684a"), (x, 60), (x - (x - 126) // 8, 84))
        c.fill(hexc("#a8684a"), (46, 56, 164, 3))
        pygame.draw.polygon(c, hexc("#a8684a"), [(46, 58), (38, 50), (50, 56)])
        pygame.draw.polygon(c, hexc("#a8684a"), [(210, 58), (218, 50), (206, 56)])
        paint_tree(c, 276, 134, 74, 40, rnd)
        paint_road(c, 134, rnd)
        s = pygame.Surface((180, 20), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (50, 40, 40, 80), (0, 0, 180, 20))
        c.blit(s, (160, 140))
    elif name == "tree":
        paint_sky(c, "#94c0d8", "#f6dfae", 114, rnd, 0)
        paint_far(c, 112, rnd)
        c.fill(hexc("#9fb060"), (0, 112, W, 24))
        paint_fence(c, 180, 310, 134, rnd)
        paint_road(c, 134, rnd)
        paint_trunk(c, 72, 152, 34, 24, rnd, lean=4)
        paint_branch(c, 76, 72, 160, 46, 6)
        paint_branch(c, 112, 60, 136, 32, 3)
        paint_branch(c, 70, 52, 28, 30, 4)
        clumps = paint_canopy(c, [(28, 12, 60, 30), (112, 12, 72, 32), (204, 10, 76, 34), (292, 14, 58, 32)], rnd)
        for _ in range(130):  # trai trung ca nho xiu, nam tren la
            x, y, r, _lift = rnd.choice(clumps)
            x += rnd.randint(-r, r)
            y += rnd.randint(-r, r)
            if 0 <= y < 46:
                ripe = rnd.random() < 0.82
                c.fill(hexc("#d0403c") if ripe else hexc("#a6c060"), (x, y, 2, 1))
                c.set_at((x, y + 1), hexc("#8e2c2e") if ripe else hexc("#7d9a48"))
                if ripe:
                    c.set_at((x, y), hexc("#f08a78"))
        c.fill(hexc("#6f8d80"), (250, 171, 70, 9))
        c.fill(hexc("#98b4a6"), (256, 173, 20, 1))
    elif name == "porch":
        paint_sky(c, "#6f7a8c", "#a8a8a8", 96, rnd, 0)
        for _ in range(26):
            pygame.draw.circle(c, hexc(rnd.choice(("#5a6274", "#646d80", "#747d8e"))), (rnd.randint(150, W), rnd.randint(40, 78)), rnd.randint(6, 15))
        paint_far(c, 96, rnd, "#5f7060", "#6d7e6a")
        paint_rice(c, 100, 134, rnd)
        paint_house(c, 200, 134, 66, 36, "tile", "#b8aa88", rnd)
        paint_tree(c, 292, 134, 58, 24, rnd)
        paint_road(c, 134, rnd)
        water = hexc("#a4adb4")
        for x in range(168, W):  # dong nuoc mua men theo rut duong
            y = 139 + (x - 168) * 0.06 + 2 * math.sin(x * 0.09)
            c.fill(water, (x, int(y), 1, 3))
            if x % 9 < 3:
                c.set_at((x, int(y) + 1), (226, 232, 236))
        for _ in range(7):
            x, y = rnd.randint(176, 310), rnd.randint(142, 150)
            pygame.draw.ellipse(c, hexc("#8e97a0"), (x, y, rnd.randint(12, 24), 3))
        wall = hexc("#cdbf9a")
        c.fill(wall, (0, 66, 150, 84))
        speckle(c, (0, 66, 150, 84), [hexc("#b4a680"), hexc("#ded2b0")], 520, rnd)
        c.fill(hexc("#6a4a30"), (24, 110, 18, 40))
        c.fill(hexc("#86603e"), (25, 111, 7, 39))
        c.fill(hexc("#2e2a30"), (88, 106, 24, 18))
        c.fill(hexc("#86603e"), (87, 105, 26, 1))
        for x in range(90, 112, 4):
            c.fill(hexc("#6a4a30"), (x, 106, 1, 18))
        c.fill(hexc("#8e8a80"), (0, 150, 158, 8))
        c.fill(hexc("#a9a598"), (0, 150, 158, 1))
        c.fill(hexc("#6a4a30"), (148, 60, 4, 90))
        c.fill(hexc("#86603e"), (148, 60, 1, 90))
        pygame.draw.polygon(c, hexc("#8c8a82"), [(0, 50), (166, 62), (166, 66), (0, 58)])
        for x in range(4, 164, 8):
            pygame.draw.line(c, hexc("#6b6a64"), (x, 51 + x * 12 // 166), (x, 57 + x * 8 // 166))
        speckle(c, (0, 52, 160, 8), [hexc("#a65f3e")], 90, rnd)
    elif name == "alley":
        paint_sky(c, "#6a7588", "#a2a4a6", 96, rnd, 0)
        paint_far(c, 96, rnd, "#5f7060", "#6d7e6a")
        paint_rice(c, 100, 134, rnd)
        paint_house(c, 8, 134, 66, 38, "tile", "#c8b98e", rnd)
        paint_house(c, 206, 134, 74, 40, "tile", "#d0c29a", rnd)
        clumps = paint_canopy(c, [(140, 124, 58, 11)], rnd, (3, 5))
        for _ in range(46):  # hoa dam but
            x, y, r, _l = rnd.choice(clumps)
            c.fill(hexc("#d8403c"), (x + rnd.randint(-r, r), y + rnd.randint(-r, r), 2, 2))
        c.fill(hexc("#54504c"), (298, 96, 3, 38))
        for y in range(100, 134, 5):
            pygame.draw.line(c, hexc("#54504c"), (288, y), (300, y))
        paint_road(c, 134, rnd)
        for _ in range(14):
            x, y = rnd.randint(0, 300), rnd.randint(140, 150)
            pygame.draw.ellipse(c, hexc("#8e97a0"), (x, y, rnd.randint(10, 26), 3))
    elif name == "home_out":
        paint_sky(c, "#667184", "#9ea0a4", 92, rnd, 0)
        paint_far(c, 92, rnd, "#5f7060", "#6d7e6a")
        paint_tree(c, 300, 134, 60, 22, rnd)
        c.fill(hexc("#7f9060"), (0, 96, W, 38))
        # nha ba gian
        paint_house(c, 118, 134, 158, 46, "tile", "#dacba4", rnd)
        c.fill(hexc("#5b4632"), (122, 88, 150, 2))
        for x in (126, 176, 216, 266):
            c.fill(hexc("#7a5a3c"), (x, 90, 4, 44))
        for x, w in ((136, 26), (232, 26)):
            c.fill(hexc("#f0c878"), (x, 104, w, 16))
            c.fill(hexc("#5f4630"), (x + w // 2, 104, 1, 16))
            pygame.draw.rect(c, hexc("#5f4630"), (x, 104, w, 16), 1)
        c.fill(hexc("#f0c878"), (189, 108, 14, 26))
        paint_road(c, 134, rnd)
        c.fill(hexc("#a39b8a"), (104, 134, 216, 18))
        speckle(c, (104, 134, 216, 18), [hexc("#8e8878"), hexc("#b8b0a0")], 420, rnd)
        # hang rao, cong sat cu
        clumps = paint_canopy(c, [(38, 122, 44, 11)], rnd, (3, 5))
        for _ in range(26):
            x, y, r, _l = rnd.choice(clumps)
            c.fill(hexc("#d8403c"), (x + rnd.randint(-r, r), y + rnd.randint(-r, r), 2, 2))
        for x in (84, 110):
            c.fill(hexc("#b2a890"), (x, 98, 6, 52))
            c.fill(hexc("#c9c0a8"), (x, 98, 2, 52))
            c.fill(hexc("#8e866f"), (x - 1, 96, 8, 3))
        for x in range(92, 104, 3):
            c.fill(hexc("#5a4a40"), (x, 112, 1, 38))
        for y in (112, 130, 148):
            c.fill(hexc("#5a4a40"), (92, y, 18, 1))
        speckle(c, (92, 112, 18, 38), [hexc("#a65f3e")], 30, rnd)
        for x in (132, 150, 168, 228, 248):  # chau cay doc hien
            c.fill(hexc("#a85f42"), (x, 142, 9, 8))
            c.fill(hexc("#7f4630"), (x + 6, 142, 3, 8))
            paint_canopy(c, [(x + 4, 136, 6, 6)], rnd, (2, 3))
    elif name == "school":
        paint_sky(c, "#10163a", "#3a4674", 96, rnd, 0)
        speckle(c, (0, 0, W, 80), [(210, 214, 240), (150, 160, 200)], 90, rnd)
        pygame.draw.circle(c, hexc("#f4efd6"), (262, 44), 11)
        pygame.draw.circle(c, hexc("#10163a"), (267, 41), 9)
        paint_far(c, 96, rnd, "#2c3a48", "#364654")
        paint_rice(c, 100, 134, rnd)
        paint_house(c, 28, 134, 206, 38, "tile", "#c8bd9a", rnd, door=False)
        for x in range(40, 226, 46):
            c.fill(hexc("#6a4a30"), (x, 108, 12, 26))
            c.fill(hexc("#86603e"), (x + 1, 109, 5, 25))
            c.fill(hexc("#2e2a30"), (x + 18, 110, 16, 12))
            for k in range(x + 20, x + 34, 4):
                c.fill(hexc("#6a4a30"), (k, 110, 1, 12))
        speckle(c, (28, 96, 206, 38), [hexc("#8e8468")], 240, rnd)
        c.fill(hexc("#7e3a2f"), (88, 68, 86, 11))
        draw_text_px(c, "TRUONG TIEU HOC", 131 - text_px_width("TRUONG TIEU HOC") // 2, 71, hexc("#f0e4c0"))
        pygame.draw.line(c, hexc("#a8a8a0"), (258, 134), (258, 66))
        c.fill(hexc("#c8483c"), (259, 67, 16, 10))
        c.fill(hexc("#e0c04a"), (266, 71, 2, 2))
        pygame.draw.circle(c, hexc("#6a4a30"), (34, 118), 6)  # cai trong
        pygame.draw.circle(c, hexc("#c49a58"), (34, 118), 4)
        paint_road(c, 134, rnd)
        for _ in range(12):
            x, y = rnd.randint(0, 300), rnd.randint(140, 150)
            pygame.draw.ellipse(c, hexc("#9aa4c0"), (x, y, rnd.randint(10, 26), 3))
    elif name == "field":
        paint_sky(c, "#10163a", "#3a4674", 100, rnd, 0)
        speckle(c, (0, 0, W, 86), [(210, 214, 240), (150, 160, 200)], 90, rnd)
        pygame.draw.circle(c, hexc("#f4efd6"), (70, 40), 11)
        pygame.draw.circle(c, hexc("#10163a"), (75, 37), 9)
        paint_far(c, 100, rnd, "#2c3a48", "#364654")
        for x in (24, 292):
            paint_bamboo(c, x, 124, 74, rnd, 14)
        c.fill(C_GRASS_D, (0, 104, W, 76))
        speckle(c, (0, 104, W, 76), [C_GRASS, C_LEAF_D, C_GRASS_L], 1800, rnd)
        c.fill(hexc("#b8a060"), (222, 104, 2, 30))
        c.fill(hexc("#b8a060"), (290, 104, 2, 30))
        c.fill(hexc("#b8a060"), (222, 104, 70, 2))
        c.fill(hexc("#54504c"), (150, 58, 2, 76))
        c.fill(hexc("#54504c"), (150, 58, 12, 2))
        add_glow(c, make_glow(46, (150, 130, 80)), 160, 66, 0.9)
        pygame.draw.circle(c, hexc("#fff0c0"), (160, 62), 2)
    elif name == "now":
        paint_sky(c, "#8fc5e0", "#f4efd0", 96, rnd, 4)
        paint_far(c, 96, rnd)
        paint_rice(c, 100, 134, rnd)
        paint_gate(c, 64, 138, rnd)
        for bx, col in ((128, "#e8e0d0"), (246, "#d8dfe2")):  # nha be tong moi
            c.fill(hexc(col), (bx, 84, 58, 50))
            c.fill(hexc("#a85a44"), (bx - 3, 80, 64, 5))
            for wx, wy in ((bx + 6, 90), (bx + 36, 90), (bx + 6, 112)):
                c.fill(hexc("#7fa6c0"), (wx, wy, 16, 14))
                pygame.draw.rect(c, hexc("#54606a"), (wx, wy, 16, 14), 1)
            c.fill(hexc("#54606a"), (bx + 36, 112, 14, 22))
        c.fill(hexc("#54504c"), (214, 60, 2, 74))
        for y in (64, 68):
            pygame.draw.line(c, hexc("#3a3a3e"), (0, y + 8), (W, y - 4))
        paint_road(c, 134, rnd)
        c.fill(hexc("#55575c"), (0, 139, W, 33))
        speckle(c, (0, 139, W, 33), [hexc("#47494e"), hexc("#696b70")], 900, rnd)
        for x in range(0, W, 26):
            c.fill(hexc("#e8e4d6"), (x, 154, 14, 2))
    elif name == "now_lane":
        paint_sky(c, "#8fc5e0", "#f4efd0", 96, rnd, 4)
        paint_far(c, 96, rnd)
        paint_rice(c, 100, 134, rnd)
        c.fill(hexc("#a89a80"), (58, 122, 76, 12))  # bai dat, tuong truong con sot lai
        speckle(c, (58, 122, 76, 12), [hexc("#8e8268"), hexc("#c4b89e"), C_GRASS], 220, rnd)
        c.fill(hexc("#c8bd9a"), (70, 104, 26, 18))
        speckle(c, (70, 104, 26, 18), [hexc("#a89e80")], 60, rnd)
        pygame.draw.line(c, hexc("#8a8a84"), (120, 134), (120, 98), 2)
        c.fill(hexc("#e8e4d6"), (112, 92, 18, 8))
        for bx, col in ((176, "#dcc99c"),):  # tiem ba Nga da dong cua
            c.fill(hexc(col), (bx, 92, 86, 42))
            speckle(c, (bx, 92, 86, 42), [hexc("#b8a678"), hexc("#ece0bd")], 240, rnd)
            c.fill(hexc("#7c8088"), (bx + 12, 104, 62, 30))
            for y in range(106, 134, 3):
                c.fill(hexc("#5f636a"), (bx + 12, y, 62, 1))
            pygame.draw.polygon(c, hexc("#8a6a58"), [(bx - 6, 92), (bx + 92, 92), (bx + 84, 78), (bx + 2, 78)])
        c.fill(hexc("#54504c"), (278, 60, 2, 74))
        paint_road(c, 134, rnd)
        c.fill(hexc("#55575c"), (0, 139, W, 33))
        speckle(c, (0, 139, W, 33), [hexc("#47494e"), hexc("#696b70")], 900, rnd)
        for x in range(0, W, 26):
            c.fill(hexc("#e8e4d6"), (x, 154, 14, 2))
    elif name == "home_now":
        paint_sky(c, "#8fc5e0", "#f4efd0", 92, rnd, 3)
        paint_far(c, 92, rnd)
        c.fill(hexc("#9fb060"), (0, 96, W, 38))
        paint_house(c, 118, 134, 158, 46, "tile", "#efe6cf", rnd)
        c.fill(hexc("#7a5a3c"), (122, 88, 150, 2))
        for x in (126, 176, 216, 266):
            c.fill(hexc("#9a9488"), (x, 90, 4, 44))
        paint_road(c, 134, rnd)
        c.fill(hexc("#a8a49a"), (104, 134, 216, 18))
        speckle(c, (104, 134, 216, 18), [hexc("#94908a"), hexc("#c0bcb0")], 300, rnd)
        for x in (84, 110):
            c.fill(hexc("#dcd8cc"), (x, 98, 6, 52))
        for x in range(92, 104, 2):
            c.fill(hexc("#46484e"), (x, 112, 1, 38))
        c.fill(hexc("#46484e"), (92, 112, 18, 2))
        for x in (132, 228, 248):
            c.fill(hexc("#a85f42"), (x, 142, 9, 8))
            paint_canopy(c, [(x + 4, 136, 6, 6)], rnd, (2, 3))
    elif name == "home":
        c.fill(hexc("#d8c79c"), (0, 0, W, 150))
        speckle(c, (0, 78, W, 72), [hexc("#c4b288"), hexc("#e8dab4")], 620, rnd)
        c.fill(hexc("#4c3522"), (0, 76, W, 4))
        c.fill(hexc("#6b4c30"), (0, 80, W, 1))
        c.fill(hexc("#7a6246"), (0, 144, W, 6))
        # gach bong
        c.fill(hexc("#b8a584"), (0, 150, W, 30))
        for y in range(150, 180, 6):
            for x in range(0, W, 6):
                if (x // 6 + y // 6) % 2 == 0:
                    c.fill(hexc("#9a4f3e"), (x, y, 6, 6))
                c.set_at((x + 3, y + 3), hexc("#e4d8bc"))
        # cua ra san
        c.fill(hexc("#3e4a68"), (0, 94, 18, 56))
        c.fill(hexc("#5f4630"), (18, 91, 3, 59))
        c.fill(hexc("#5f4630"), (0, 91, 21, 3))
        # cua so nhin ra mua
        c.fill(hexc("#3e4a68"), (40, 98, 30, 24))
        pygame.draw.rect(c, hexc("#5f4630"), (39, 97, 32, 26), 2)
        for x in range(46, 68, 6):
            c.fill(hexc("#5f4630"), (x, 98, 1, 24))
        # ban tho
        c.fill(hexc("#5a3a26"), (100, 118, 44, 32))
        c.fill(hexc("#7a5236"), (98, 116, 48, 3))
        for x in (104, 122):
            pygame.draw.rect(c, hexc("#3e2818"), (x, 122, 16, 22), 1)
        c.fill(hexc("#c0a040"), (118, 108, 8, 8))
        c.fill(hexc("#e0d0a0"), (120, 100, 1, 8))
        c.fill(hexc("#e0d0a0"), (123, 102, 1, 6))
        c.fill(hexc("#d85a5a"), (120, 99, 1, 1))
        c.fill(hexc("#2e2a30"), (106, 104, 8, 11))
        c.fill(hexc("#c8c0a8"), (107, 105, 6, 9))
        c.fill(hexc("#2e2a30"), (130, 104, 8, 11))
        c.fill(hexc("#c8c0a8"), (131, 105, 6, 9))
        pygame.draw.rect(c, hexc("#7a5236"), (112, 84, 22, 10), 1)
        # to lich, dong ho
        c.fill(hexc("#f0ece0"), (82, 96, 10, 14))
        c.fill(hexc("#c8483c"), (82, 96, 10, 4))
        pygame.draw.circle(c, hexc("#6b4c30"), (158, 96), 6)
        pygame.draw.circle(c, hexc("#f4efe0"), (158, 96), 5)
        c.fill(hexc("#2e2a30"), (158, 92, 1, 4))
        c.fill(hexc("#2e2a30"), (158, 96, 3, 1))
        # tu + TV doi cu
        c.fill(hexc("#6b4c30"), (166, 128, 36, 22))
        c.fill(hexc("#86603e"), (166, 128, 36, 2))
        c.fill(hexc("#3a3236"), (172, 110, 24, 18))
        c.fill(hexc("#6c7a78"), (174, 112, 16, 14))
        c.fill(hexc("#a8a090"), (192, 113, 2, 2))
        # cua xuong bep
        c.fill(hexc("#2e2420"), (214, 94, 22, 56))
        c.fill(hexc("#5f4630"), (211, 91, 3, 59))
        c.fill(hexc("#5f4630"), (211, 91, 28, 3))
    else:  # meal
        c.fill(hexc("#cdbb90"), (0, 0, W, 150))
        speckle(c, (0, 78, W, 72), [hexc("#b8a67c"), hexc("#ddceaa")], 560, rnd)
        c.fill(hexc("#4c3522"), (0, 76, W, 4))
        c.fill(hexc("#7a6246"), (0, 146, W, 4))
        c.fill(hexc("#8e8878"), (0, 150, W, 30))
        speckle(c, (0, 150, W, 30), [hexc("#7c7668"), hexc("#a09a8a")], 300, rnd)
        c.fill(hexc("#3e4a68"), (20, 94, 28, 24))
        pygame.draw.rect(c, hexc("#5f4630"), (19, 93, 30, 26), 2)
        c.fill(hexc("#5f4630"), (33, 94, 1, 24))
        c.fill(hexc("#6b4c30"), (136, 100, 40, 2))  # ke chen bat
        for x in range(140, 174, 7):
            pygame.draw.ellipse(c, hexc("#e8e0cc"), (x, 96, 6, 4))
        c.fill(hexc("#3c2c20"), (100, 80, 1, 8))
        pygame.draw.ellipse(c, hexc("#fff0c0"), (97, 88, 7, 7))
        fg = pygame.Surface((W, H), pygame.SRCALPHA)
        fg.fill(hexc("#7a5236"), (26, 141, 150, 4))
        fg.fill(hexc("#96683f"), (26, 141, 150, 1))
        fg.fill(hexc("#5a3a26"), (30, 145, 3, 8))
        fg.fill(hexc("#5a3a26"), (169, 145, 3, 8))
        # noi canh, dia suon, ca kho, noi com
        fg.fill(hexc("#b8b8b0"), (50, 137, 14, 4))
        fg.fill(hexc("#dcdcd4"), (50, 137, 4, 4))
        fg.fill(hexc("#8e8e88"), (48, 138, 2, 2))
        fg.fill(hexc("#8e8e88"), (64, 138, 2, 2))
        pygame.draw.ellipse(fg, hexc("#efe6d0"), (70, 137, 20, 4))
        fg.fill(hexc("#a0602c"), (74, 137, 12, 2))
        fg.fill(hexc("#c98a48"), (76, 137, 3, 1))
        pygame.draw.ellipse(fg, hexc("#efe6d0"), (110, 137, 16, 4))
        fg.fill(hexc("#c49a58"), (113, 138, 10, 1))
        fg.fill(hexc("#d8d0bc"), (96, 136, 12, 5))
        fg.fill(hexc("#f0ead8"), (96, 136, 3, 5))
        fg.fill(hexc("#a89c84"), (95, 135, 14, 1))
        for x in (48, 78, 106, 130, 156):
            pygame.draw.ellipse(fg, hexc("#e8e0cc"), (x, 138, 6, 3))
    tint = make_tint(PLACE_TINT[name])
    _place_cache[name] = (c, fg, tint)
    return _place_cache[name]


class Village:
    """Mot dia diem trong lang. actors: [(nhan vat, san rieng)]."""

    def __init__(self, game, place):
        self.g = game
        self.place = place
        self.bg, self.fg, self.tint = paint_place(place)
        self.floor = PLACE_FLOOR[place]
        self.time = 0.0
        self.me = Actor(26, me_pal(True, True))
        self.me_floor = self.floor
        self.actors = []
        self.followers = []  # (nhan vat, khoang cach sau lung minh)
        rnd = random.Random(5)
        self.leaves = [[rnd.uniform(0, W), rnd.uniform(0, 140), rnd.uniform(6, 13), rnd.random() * 6]
                       for _ in range(10 if place in ("bamboo", "tree", "dinh") else 0)]
        self.steam = []
        self.spots = [(rnd.randint(30, 300), rnd.randint(138, 168), rnd.random() * 6) for _ in range(9)]
        self.dapple = make_glow(11, (70, 66, 34))
        # khung hinh gan cho canh trong nha
        self.zoom = 2 if place in INDOOR else 1
        self.wide_view = place not in INDOOR and place != "tree"  # tan cay nam cao, can khung rong
        self.cam_top = 76 if place in INDOOR else self.floor - 99
        self.world_w = {"shop": 240, "home": 240, "meal": 200}.get(place, W)
        self.cam = 110.0 if place in INDOOR else None
        self.cam_focus = None
        self.rain = place in ("porch", "alley", "home_out")
        self.door_open = False
        self.rain_x0 = 154 if place == "porch" else -10
        self.drops = [[rnd.uniform(0, W), rnd.uniform(40, 170), rnd.uniform(190, 250)] for _ in range(170)]
        self.props = []  # (nhan vat, hinh, dx, dy): do cam tay
        self.outside = False
        self.bus_x = None
        self.door_open = False
        self.ball = None
        self.steam_at = {"cart": [(196, 105)], "meal": [(57, 135), (102, 133)]}.get(place, [])
        self.lamp = make_glow(58, (120, 92, 46)) if place == "meal" else None
        self.win_drops = [(rnd.random(), rnd.random(), rnd.uniform(2.2, 4.6), rnd.randint(2, 4)) for _ in range(13)]
        self.glass = [(rnd.uniform(80, 239), rnd.random(), rnd.uniform(0.03, 0.16), rnd.randint(2, 5)) for _ in range(46)]
        self.tint_hi = pygame.transform.scale(self.tint, (WIN_W, WIN_H)) if self.wide_view else None

    def add(self, actor, floor=None):
        self.actors.append((actor, floor if floor is not None else self.floor))
        return actor

    def storm(self):
        """Troi sap mua: to mau toi."""
        self.tint_hi = pygame.transform.scale(make_tint((166, 172, 200)), (WIN_W, WIN_H))

    def draw_outside(self, c, view):
        """Nhin vao bua com tu ngoai cua so uot mua."""
        if not hasattr(self, "wall_out"):
            self.wall_out = outside_wall()
            self.tint_out = make_tint((176, 180, 206))
        tinted = view.copy()
        tinted.fill((255, 226, 176), special_flags=pygame.BLEND_MULT)
        c.blit(self.wall_out, (0, 0))
        c.blit(self.tint_out, (0, 0), special_flags=pygame.BLEND_MULT)
        c.blit(tinted, (80, 40))
        for x, fy, sp, ln in self.glass:  # giot nuoc chay tren kinh
            c.fill((212, 220, 236), (int(x), 40 + int(((fy + self.time * sp) % 1.0) * 88), 1, ln))
        pygame.draw.rect(c, hexc("#4c3522"), (77, 37, 166, 96), 3)
        c.fill(hexc("#4c3522"), (159, 40, 2, 90))
        c.fill(hexc("#4c3522"), (80, 84, 160, 2))
        for d in self.drops:
            pygame.draw.line(c, (190, 200, 226), (int(d[0]), int(d[1])), (int(d[0]) + 1, int(d[1]) - 5))

    def update(self, dt):
        self.time += dt
        self.me.update(dt)
        for a, _ in self.actors:
            a.update(dt)
        target = self.cam_focus if self.cam_focus is not None else self.me.x + 30
        self.cam = target if self.cam is None else self.cam + (target - self.cam) * min(1.0, dt * 2.5)
        for a, off in self.followers:
            tx = self.me.x + off
            if abs(tx - a.x) > 5:
                a.state = "walk"
                a.facing = 1 if tx > a.x else -1
                a.x += a.facing * 56 * dt
            elif a.state == "walk":
                a.state = "idle"
                a.facing = self.me.facing
        for lf in self.leaves:
            lf[1] += lf[2] * dt
            lf[0] += math.sin(self.time * 1.4 + lf[3]) * 14 * dt
            if lf[1] > 150:
                lf[1] = -4
                lf[0] = random.uniform(0, W)
        if self.rain:
            for d in self.drops:
                d[0] -= d[2] * 0.16 * dt
                d[1] += d[2] * dt
                if d[1] > 172:
                    d[1] = random.uniform(30, 60)
                    d[0] = random.uniform(0, W + 30)
        if self.steam_at:
            for sx, sy in self.steam_at:
                if random.random() < dt * 6:
                    self.steam.append([sx + random.uniform(-5, 5), float(sy), random.uniform(1.2, 2.2), 0.0])
            for s in self.steam:
                s[1] -= 15 * dt
                s[0] += math.sin(s[3] * 3 + s[2] * 5) * 8 * dt
                s[3] += dt
            self.steam = [s for s in self.steam if s[3] < s[2]]

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        p = self.place
        if p in ("gate", "road", "xom", "cart", "tree"):
            draw_birds(c, self.time)
        if p in ("bamboo", "dinh", "tree"):
            for x, y, ph in self.spots:
                add_glow(c, self.dapple, x + math.sin(self.time * 0.8 + ph) * 3, y,
                         0.45 + 0.3 * math.sin(self.time * 1.3 + ph))
        win = {"home": (41, 99, 28, 22), "meal": (21, 95, 26, 22)}.get(p)
        if win:  # mua ngoai cua so
            c.set_clip(pygame.Rect(win))
            for fx, fy, sp, ln in self.win_drops:
                x = win[0] + fx * win[2]
                y = win[1] + ((fy + self.time * sp) % 1.0) * (win[3] + 4) - 4
                c.fill((170, 182, 214), (int(x), int(y), 1, ln))
            c.set_clip(None)
        if self.bus_x is not None:
            Street.draw_bus(self, c)
        items = [(self.me_floor, self.me)] + [(fl, a) for a, fl in self.actors]
        for fl, a in sorted(items, key=lambda it: it[0]):
            nod = 1 if p == "meal" and a.state == "sit" and math.sin(self.time * 1.7 + a.x) > 0.8 else 0
            a.draw(c, fl + nod)
        for a, img, dx, dy in self.props:
            if a.visible:
                pic = pygame.transform.flip(img, True, False) if a.facing < 0 else img
                x = int(a.x) + (dx if a.facing > 0 else -dx - pic.get_width())
                c.blit(pic, (x, self.floor + dy))
        if self.fg:
            c.blit(self.fg, (0, 0))
        for s in self.steam:
            k = 1 - s[3] / s[2]
            c.fill(lerpc((190, 180, 160), (246, 240, 228), k), (int(s[0]), int(s[1]), 2 + int(k * 2), 2))
        for lf in self.leaves:
            c.fill(C_LEAF_L, (int(lf[0]), int(lf[1]), 2, 1))
            c.set_at((int(lf[0]), int(lf[1]) + 1), C_LEAF_D)
        if self.ball:
            pygame.draw.circle(c, (40, 36, 44), (int(self.ball[0]), int(self.ball[1])), 4)
            pygame.draw.circle(c, (240, 236, 224), (int(self.ball[0]), int(self.ball[1])), 3)
            c.set_at((int(self.ball[0]), int(self.ball[1])), (40, 36, 44))
        if self.lamp:
            add_glow(c, self.lamp, 100, 96, 0.9 + 0.08 * math.sin(self.time * 3))
        if self.rain:
            for x, y, v in self.drops:
                if x > self.rain_x0:
                    pygame.draw.line(c, (196, 208, 232), (int(x), int(y)), (int(x) + 1, int(y) - 5))
            for i in range(10):
                x = (i * 37 + int(self.time * 53) * 17) % W
                if x > self.rain_x0:
                    c.fill((214, 222, 236), (x, 136 + (i * 5) % 14, 2, 1))
        if self.zoom > 1:
            vw, vh = W // self.zoom, H // self.zoom
            left = int(clamp(self.cam - vw / 2, 0, self.world_w - vw))
            view = c.subsurface((left, self.cam_top, vw, vh)).copy()
            if self.outside:
                self.draw_outside(c, view)
                return
            pygame.transform.scale(view, (W, H), c)
        if not self.wide_view:  # khung gan thi Game to mau sau khi phong to
            c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)


def outside_wall():
    rnd = random.Random(77)
    c = pygame.Surface((W, H))
    c.fill(hexc("#5a5a68"))
    speckle(c, (0, 0, W, H), [hexc("#4c4c5a"), hexc("#66667a")], 1800, rnd)
    return c


def make_portrait(pal, female=False, head=None, expr="smile"):
    """Khung anh can mat, dung khi gap lai nguoi than."""
    rows = apply_expr(head or (HEAD_F if female else HEAD_M), expr) + (BODY_F if female else BODY_M)[:5]
    spr = make_sprite(rows, pal)
    big = pygame.transform.scale(spr, (spr.get_width() * 4, spr.get_height() * 4))
    s = pygame.Surface((96, 100), pygame.SRCALPHA)
    s.fill((238, 230, 208))
    s.fill((206, 178, 138), (5, 5, 86, 90))
    s.blit(big, (48 - big.get_width() // 2, 95 - big.get_height()), (0, 0, big.get_width(), big.get_height()))
    s.fill((238, 230, 208), (0, 95, 96, 5))
    return s


def make_dish(kind):
    s = pygame.Surface((96, 56), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (120, 100, 80), (2, 14, 92, 40))
    pygame.draw.ellipse(s, (240, 232, 214), (2, 11, 92, 40))
    pygame.draw.ellipse(s, (214, 206, 186), (12, 17, 72, 28))
    rnd = random.Random(sum(map(ord, kind)))
    if kind == "canh":
        pygame.draw.ellipse(s, (206, 190, 130), (12, 17, 72, 28))
        for _ in range(16):
            x, y = rnd.randint(22, 70), rnd.randint(22, 38)
            s.fill((150, 186, 96), (x, y, rnd.randint(4, 9), 3))
            s.fill((196, 220, 136), (x + 1, y, 2, 1))
        for _ in range(3):
            x, y = rnd.randint(26, 62), rnd.randint(24, 36)
            s.fill((236, 226, 200), (x, y, 11, 4))
    elif kind == "suon":
        for _ in range(9):
            x, y = rnd.randint(18, 64), rnd.randint(20, 36)
            s.fill((116, 62, 32), (x, y, 15, 7))
            s.fill((176, 104, 50), (x + 1, y, 12, 3))
            s.fill((226, 214, 186), (x + 13, y + 2, 4, 3))
        for _ in range(28):
            s.fill((206, 216, 110), (rnd.randint(18, 78), rnd.randint(20, 42), 2, 1))
    else:
        for _ in range(7):
            x, y = rnd.randint(20, 62), rnd.randint(21, 38)
            pygame.draw.polygon(s, (186, 140, 76), [(x, y + 3), (x + 14, y), (x + 20, y + 3), (x + 14, y + 6)])
            pygame.draw.polygon(s, (130, 90, 50), [(x + 20, y + 3), (x + 25, y), (x + 25, y + 6)])
            s.fill((226, 186, 120), (x + 5, y + 2, 7, 1))
    return pygame.transform.scale(s, (192, 112))


def make_rod():
    s = pygame.Surface((16, 18), pygame.SRCALPHA)
    pygame.draw.line(s, (130, 104, 60), (0, 17), (15, 0))
    return s


def make_ladle():
    s = pygame.Surface((10, 13), pygame.SRCALPHA)
    pygame.draw.line(s, (160, 160, 150), (0, 12), (7, 3))
    pygame.draw.ellipse(s, (200, 200, 190), (5, 0, 5, 4))
    return s


def make_towel():
    s = pygame.Surface((8, 9), pygame.SRCALPHA)
    s.fill((214, 208, 190), (0, 0, 7, 9))
    s.fill((180, 172, 150), (5, 0, 2, 9))
    return s


def make_big_marble():
    s = pygame.Surface((48, 48), pygame.SRCALPHA)
    pygame.draw.circle(s, (40, 60, 96), (24, 24), 22)
    pygame.draw.circle(s, (70, 150, 210), (24, 24), 20)
    pygame.draw.circle(s, (118, 196, 236), (20, 20), 14)
    pygame.draw.circle(s, (70, 150, 210), (26, 27), 12)
    for t in range(0, 26):  # soi xoan ben trong
        a = t * 0.42
        r = 2 + t * 0.48
        s.fill((226, 244, 250), (24 + int(math.cos(a) * r), 25 + int(math.sin(a) * r), 2, 2))
    s.fill((255, 255, 250), (13, 12, 7, 3))
    s.fill((255, 255, 250), (11, 15, 3, 4))
    return pygame.transform.scale(s, (96, 96))


def make_phone_now():
    s = pygame.Surface((64, 112), pygame.SRCALPHA)
    pygame.draw.rect(s, (36, 34, 44), (0, 0, 64, 112), border_radius=6)
    s.fill((20, 26, 44), (4, 8, 56, 96))
    tmp = pygame.Surface((19, 5), pygame.SRCALPHA)
    draw_text_px(tmp, "09:12", 0, 0, (236, 236, 246))
    s.blit(pygame.transform.scale(tmp, (38, 10)), (13, 16))
    for i, (t, col) in enumerate((("SERVER ALERT", (240, 120, 110)), ("12 MESSAGES", (236, 220, 170)), ("3 MISSED CALLS", (236, 220, 170)))):
        s.fill((44, 50, 74), (7, 38 + i * 20, 50, 15))
        draw_text_px(s, t[:12], 9, 43 + i * 20, col)
    return s


def make_calendar():
    s = pygame.Surface((96, 112), pygame.SRCALPHA)
    pygame.draw.rect(s, (120, 100, 80), (0, 0, 96, 112), border_radius=2)
    s.fill((240, 236, 222), (2, 2, 92, 108))
    s.fill((196, 66, 58), (2, 2, 92, 22))
    draw_text_px(s, "LICH", 48 - text_px_width("LICH") // 2, 6, (248, 236, 210))
    for x in range(8, 92, 8):
        s.fill((70, 60, 60), (x, 0, 2, 4))
    tmp = pygame.Surface((15, 5), pygame.SRCALPHA)
    draw_text_px(tmp, "2008", 0, 0, (46, 40, 52))
    big = pygame.transform.scale(tmp, (75, 25))
    s.blit(big, (11, 32))
    tmp = pygame.Surface((31, 5), pygame.SRCALPHA)
    draw_text_px(tmp, "THU BAY", 0, 0, (196, 66, 58))
    s.blit(pygame.transform.scale(tmp, (62, 10)), (17, 66))
    for y in range(86, 104, 4):
        s.fill((190, 184, 170), (12, y, 72, 1))
    return s


def make_phone_dead():
    s = pygame.Surface((64, 112), pygame.SRCALPHA)
    pygame.draw.rect(s, (36, 34, 44), (0, 0, 64, 112), border_radius=6)
    s.fill((20, 26, 44), (4, 8, 56, 96))
    tmp = pygame.Surface((19, 5), pygame.SRCALPHA)
    draw_text_px(tmp, "07:00", 0, 0, (236, 236, 246))
    s.blit(pygame.transform.scale(tmp, (38, 10)), (13, 42))
    draw_text_px(s, "NO SIGNAL", 32 - text_px_width("NO SIGNAL") // 2, 60, (220, 110, 100))
    return s


def make_candy():
    s = pygame.Surface((70, 36), pygame.SRCALPHA)
    for i, col in enumerate(((216, 90, 90), (224, 192, 74), (88, 160, 216), (98, 192, 122))):
        x = 6 + i * 15
        pygame.draw.polygon(s, col, [(x - 4, 12), (x + 1, 16), (x - 4, 22)])
        pygame.draw.polygon(s, col, [(x + 13, 12), (x + 8, 16), (x + 13, 22)])
        pygame.draw.circle(s, col, (x + 4, 17), 6)
        s.fill((255, 245, 230), (x + 1, 14, 2, 2))
    return pygame.transform.scale(s, (140, 72))


def make_tiny_boat(col=(244, 240, 226), shade=(198, 192, 176)):
    s = pygame.Surface((17, 12), pygame.SRCALPHA)
    pygame.draw.polygon(s, col, [(0, 6), (5, 8), (8, 0), (11, 8), (16, 6), (12, 11), (4, 11)])
    pygame.draw.polygon(s, shade, [(8, 0), (11, 8), (8, 8)])
    pygame.draw.line(s, shade, (2, 8), (14, 8))
    return s


# ---- khung chung cho minigame chuong 2
class Sling:
    """Ngam bang keo chuot, hoac phim mui ten + giu Space. update() tra ve (goc, luc) khi ban."""

    def __init__(self, g, angle, amin=None, amax=None, max_drag=56.0, invert=True):
        self.g = g
        self.angle = angle
        self.amin = amin
        self.amax = amax
        self.max_drag = max_drag
        self.invert = invert
        self.power = 0.0
        self.drag_from = None
        self.charging = False
        self.t = 0.0

    def limit(self):
        if self.amin is not None:
            self.angle = clamp(self.angle, self.amin, self.amax)

    def update(self, dt):
        g = self.g
        if g.mouse_pressed:
            self.drag_from = g.mouse
        if self.drag_from:
            dx = g.mouse[0] - self.drag_from[0]
            dy = g.mouse[1] - self.drag_from[1]
            if self.invert:
                dx, dy = -dx, -dy
            d = math.hypot(dx, dy)
            if d > 2:
                self.angle = math.atan2(dy, dx)
                self.limit()
                self.power = min(1.0, d / self.max_drag)
            if g.mouse_released:
                self.drag_from = None
                return self.fire()
            return None
        k = g.keys
        if k is None:
            return None
        turn = int(k[pygame.K_RIGHT] or k[pygame.K_d] or k[pygame.K_DOWN]) - int(k[pygame.K_LEFT] or k[pygame.K_a] or k[pygame.K_UP])
        if turn:
            self.angle += turn * 1.6 * dt
            self.limit()
        if k[pygame.K_SPACE]:
            self.charging = True
            self.t += dt
            self.power = 0.5 - 0.5 * math.cos(self.t * 2.8)
        elif self.charging:
            self.charging = False
            self.t = 0.0
            return self.fire()
        return None

    def fire(self):
        p = self.power
        self.power = 0.0
        return (self.angle, p) if p > 0.08 else None


class ChMini:
    """Minigame la 1 'scene': ve pixel o draw(), chu o draw_hud()."""
    title = ""
    tip = ""

    def __init__(self, g):
        self.g = g
        self.done = False
        self.time = 0.0
        self.msg = ""
        self.msg_t = 0.0
        self.end_t = None
        self.me_tint = None

    def say(self, text, t=2.4):
        self.msg = text
        self.msg_t = t
        if "Ha ha" in text or random.random() < 0.4:
            self.g.audio.play("laugh", 0.45)

    def finish(self, delay=2.2):
        if self.end_t is None:
            self.end_t = delay

    def update(self, dt):
        self.time += dt
        self.msg_t = max(0.0, self.msg_t - dt)
        if self.end_t is not None:
            self.end_t -= dt
            if self.end_t <= 0:
                self.done = True

    def status(self):
        return ""

    def draw_hud(self, scr, f):
        g = self.g
        t = f.name.render(self.title, True, (36, 30, 40))
        pygame.draw.rect(scr, (233, 200, 130), (18, 14, t.get_width() + 28, 40))
        pygame.draw.rect(scr, (120, 90, 60), (18, 14, t.get_width() + 28, 40), 3)
        scr.blit(t, (32, 34 - t.get_height() // 2))
        st = self.status()
        if st:
            s = f.hint.render(st, True, (250, 244, 228))
            w = s.get_width() + 28
            box = pygame.Surface((w, 40), pygame.SRCALPHA)
            box.fill((22, 20, 36, 200))
            scr.blit(box, (WIN_W - w - 18, 14))
            scr.blit(s, (WIN_W - w - 4, 34 - s.get_height() // 2))
        if self.msg_t > 0:
            s = f.text.render(self.msg, True, (36, 30, 40))
            w = s.get_width() + 44
            x = WIN_W // 2 - w // 2
            pygame.draw.rect(scr, (250, 242, 220), (x, 70, w, 52), border_radius=8)
            pygame.draw.rect(scr, (120, 90, 60), (x, 70, w, 52), 3, border_radius=8)
            scr.blit(s, (x + 22, 96 - s.get_height() // 2))
        if self.tip and self.end_t is None:
            g.shadow_text(scr, f.small, self.tip, (250, 244, 228), WIN_W // 2, 686, off=2)


MARBLE_COLS = [(88, 160, 216), (216, 90, 90), (224, 192, 74), (98, 192, 122), (190, 120, 216), (236, 150, 80), (120, 214, 214)]


def make_marble(col):
    s = pygame.Surface((9, 9), pygame.SRCALPHA)
    pygame.draw.circle(s, (46, 40, 52), (4, 4), 4)
    pygame.draw.circle(s, col, (4, 4), 3)
    s.fill(lerpc(col, (0, 0, 0), 0.3), (4, 5, 3, 2))
    s.fill((255, 255, 250), (2, 2, 2, 1))
    s.set_at((2, 3), lerpc(col, (255, 255, 255), 0.6))
    return s


class MarbleGame(ChMini):
    title = "Bắn bi"
    tip = "Kéo chuột ngược hướng rồi thả  ·  hoặc ← → ngắm, giữ rồi thả Space"
    CX, CY, R = 160, 100, 54
    START = (160.0, 164.0)
    GOAL = 3

    def __init__(self, g):
        ChMini.__init__(self, g)
        self.sling = Sling(g, -math.pi / 2, invert=True, max_drag=60.0)
        rnd = random.Random(21)
        self.bg = self.paint(rnd)
        self.tint = paint_place("road")[2]
        self.me = {"x": self.START[0], "y": self.START[1], "vx": 0.0, "vy": 0.0, "spr": make_marble(MARBLE_COLS[0])}
        self.balls = []
        while len(self.balls) < 7:
            a, d = rnd.uniform(0, 6.28), rnd.uniform(0, self.R - 20)
            x, y = self.CX + math.cos(a) * d, self.CY + math.sin(a) * d
            if all(math.hypot(x - b["x"], y - b["y"]) > 14 for b in self.balls):
                col = MARBLE_COLS[1 + len(self.balls) % 6]
                self.balls.append({"x": x, "y": y, "vx": 0.0, "vy": 0.0, "spr": make_marble(col), "col": col})
        self.tray = []
        self.moving = False
        self.hit = False
        self.got = 0
        self.kids = [(Kid(0, p, female=False), x, y, fc) for p, x, y, fc in (
            (PAL_KID_ME, 112, 40, 1), (PAL_KID_TEO, 148, 36, 1), (PAL_KID_NA, 182, 36, -1), (PAL_KID_HUNG, 216, 40, -1))]
        for k, _, _, fc in self.kids:
            k.state = "sit"
            k.facing = fc
        self.hit_lines = ["Ê! Anh này bắn hay ghê!", "Ăn gian! Chắc anh tập trước rồi!", "Thua thì nói thua đi!"]
        self.n_line = 0

    def paint(self, rnd):
        c = pygame.Surface((W, H))
        c.fill(C_DIRT)
        speckle(c, (0, 0, W, H), [C_DIRT_D, C_DIRT_L], 2600, rnd)
        for _ in range(60):
            x, y = rnd.randint(0, W), rnd.randint(0, H)
            c.fill(hexc("#d9c4a0"), (x, y, 2, 1))
            c.set_at((x, y + 1), hexc("#8a6a48"))
        paint_tufts(c, 4, 30, rnd)
        c.fill(C_GRASS, (0, 0, W, 8))
        speckle(c, (0, 0, W, 8), [C_GRASS_D, C_GRASS_L], 200, rnd)
        for a in range(0, 720):  # vong tron ve bang canh cay, nguech ngoac
            t = a / 720 * 6.283
            r = self.R + 1.2 * math.sin(t * 7) + 0.8 * math.sin(t * 13)
            x, y = int(self.CX + math.cos(t) * r), int(self.CY + math.sin(t) * r)
            c.fill(hexc("#7c5a3c"), (x, y, 1 + (a % 11 > 3), 1))
        return c

    def ready(self):
        return not self.moving and self.end_t is None

    def all(self):
        return [self.me] + self.balls

    def update(self, dt):
        ChMini.update(self, dt)
        for k, _, _, _ in self.kids:
            k.update(dt)
        if self.ready():
            shot = self.sling.update(dt)
            if shot:
                a, p = shot
                sp = 70 + 210 * p
                self.me["vx"] = math.cos(a) * sp
                self.me["vy"] = math.sin(a) * sp
                self.moving = True
                self.hit = False
                self.got = 0
                self.g.audio.play("click", 0.5)
            return
        if not self.moving:
            return
        sub = 4
        h = dt / sub
        for _ in range(sub):
            for b in self.all():
                b["x"] += b["vx"] * h
                b["y"] += b["vy"] * h
                f = max(0.0, 1 - 1.15 * h) if math.hypot(b["vx"], b["vy"]) > 14 else max(0.0, 1 - 6 * h)
                b["vx"] *= f
                b["vy"] *= f
                if b["x"] < 6 or b["x"] > W - 6:
                    b["x"] = clamp(b["x"], 6, W - 6)
                    b["vx"] *= -0.5
                if b["y"] < 44 or b["y"] > H - 8:
                    b["y"] = clamp(b["y"], 44, H - 8)
                    b["vy"] *= -0.5
            items = self.all()
            for i in range(len(items)):
                for j in range(i + 1, len(items)):
                    self.collide(items[i], items[j])
        for b in list(self.balls):
            if math.hypot(b["x"] - self.CX, b["y"] - self.CY) > self.R + 4:
                self.balls.remove(b)
                self.tray.append(b["col"])
                self.got += 1
                self.g.audio.play("ok", 0.35)
        if all(math.hypot(b["vx"], b["vy"]) < 3 for b in self.all()):
            for b in self.all():
                b["vx"] = b["vy"] = 0.0
            self.moving = False
            self.after_shot()

    def collide(self, a, b):
        dx, dy = b["x"] - a["x"], b["y"] - a["y"]
        d = math.hypot(dx, dy)
        if d >= 7 or d == 0:
            return
        nx, ny = dx / d, dy / d
        over = (7 - d) / 2
        a["x"] -= nx * over
        a["y"] -= ny * over
        b["x"] += nx * over
        b["y"] += ny * over
        rel = (a["vx"] - b["vx"]) * nx + (a["vy"] - b["vy"]) * ny
        if rel <= 0:
            return
        k = rel * 0.92
        a["vx"] -= k * nx
        a["vy"] -= k * ny
        b["vx"] += k * nx
        b["vy"] += k * ny
        self.hit = True
        self.g.audio.play("marble", clamp(rel / 150.0, 0.25, 1.0))

    def after_shot(self):
        if math.hypot(self.me["x"] - self.CX, self.me["y"] - self.CY) > self.R + 30:
            self.me["x"], self.me["y"] = self.START
        if len(self.tray) >= self.GOAL or not self.balls:
            self.say("Anh này bắn được đó nha!", 3.0)
            self.finish(2.6)
        elif self.got:
            self.say(self.hit_lines[self.n_line % 3])
            self.n_line += 1
        elif self.hit:
            self.say("Trúng rồi mà chưa văng ra!")
        else:
            self.say("Hụt rồi anh ơi! Ha ha!")

    def status(self):
        return ""

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        for k, x, y, _ in self.kids:
            k.x = x
            k.draw(c, y)
        for b in self.balls:
            c.blit(b["spr"], (int(b["x"]) - 4, int(b["y"]) - 4))
        m = self.me
        s = self.sling
        if self.ready() and s.power > 0:
            ln = 12 + 86 * s.power
            for i in range(2, int(ln), 6):
                px = m["x"] + math.cos(s.angle) * i
                py = m["y"] + math.sin(s.angle) * i
                c.fill((252, 244, 214), (int(px), int(py), 2, 2))
            bx = m["x"] - math.cos(s.angle) * (4 + 12 * s.power)
            by = m["y"] - math.sin(s.angle) * (4 + 12 * s.power)
            pygame.draw.line(c, (70, 52, 46), (int(m["x"]), int(m["y"])), (int(bx), int(by)))
        elif self.ready() and int(self.time * 2.4) % 2 == 0:
            pygame.draw.circle(c, (252, 244, 214), (int(m["x"]), int(m["y"])), 7, 1)
        c.blit(m["spr"], (int(m["x"]) - 4, int(m["y"]) - 4))
        for i, col in enumerate(self.tray):
            c.blit(make_marble(col), (W - 14 - i * 10, 18))
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)


def make_slipper():
    s = pygame.Surface((11, 5), pygame.SRCALPHA)
    s.fill((60, 110, 170), (0, 2, 11, 3))
    s.fill((96, 150, 206), (1, 2, 9, 1))
    pygame.draw.line(s, (216, 90, 70), (3, 2), (5, 0))
    pygame.draw.line(s, (216, 90, 70), (7, 2), (5, 0))
    return s


def make_can():
    s = pygame.Surface((9, 12), pygame.SRCALPHA)
    s.fill((176, 172, 160), (0, 1, 9, 10))
    s.fill((222, 218, 206), (1, 1, 2, 10))
    s.fill((118, 114, 106), (7, 1, 2, 10))
    s.fill((196, 66, 58), (0, 4, 9, 4))
    s.fill((238, 226, 196), (3, 5, 3, 2))
    s.fill((118, 114, 106), (0, 0, 9, 1))
    s.fill((118, 114, 106), (1, 11, 7, 1))
    return s


class CanGame(ChMini):
    title = "Tạt lon"
    tip = "Kéo chuột chéo lên để chọn lực và góc  ·  hoặc ← → chỉnh góc, giữ rồi thả Space"
    GRAV = 330.0
    MAX_V = 262.0
    GOAL = 2

    def __init__(self, g, kid_pal_):
        ChMini.__init__(self, g)
        self.bg, _, self.tint = paint_place("bamboo")
        self.sling = Sling(g, -0.8, amin=-1.35, amax=-0.1, max_drag=60.0, invert=False)
        self.me = Actor(52, me_pal(True, True), expr="smile")
        self.kid = Kid(150, kid_pal_, facing=1)
        self.others = [Kid(112, PAL_KID_TEO, facing=1), Kid(132, PAL_KID_HUNG, facing=1)]
        self.wide_view, self.cam, self.cam_top, self.world_w = True, 146.0, 51, W
        self.can_img = make_can()
        self.slip_img = make_slipper()
        self.floor = 150
        self.slip = None
        self.rounds = 0
        self.throws = 0
        self.cans = []
        self.state = "aim"
        self.restack_t = 0.0
        self.build()

    def build(self):
        self.cans = []
        base = 232
        for lvl, n in enumerate((3, 2, 1)):
            for i in range(n):
                x = base + (i - (n - 1) / 2) * 12
                self.cans.append({"hx": x, "hy": self.floor - 6 - lvl * 12, "x": x, "y": self.floor - 6 - lvl * 12,
                                  "vx": 0.0, "vy": 0.0, "rot": 0.0, "spin": 0.0, "up": True, "lvl": lvl})

    def ready(self):
        return self.state == "aim" and self.slip is None and self.end_t is None

    def supported(self, c):
        if c["lvl"] == 0:
            return True
        for o in self.cans:
            if o["up"] and o["lvl"] == c["lvl"] - 1 and abs(o["hx"] - c["hx"]) < 8:
                return True
        return False

    def knock(self, c, vx, vy):
        c["up"] = False
        c["vx"] = vx
        c["vy"] = vy
        c["spin"] = random.uniform(-500, 500)
        self.g.audio.play("can", 0.8)

    def update(self, dt):
        ChMini.update(self, dt)
        self.me.update(dt)
        self.kid.update(dt)
        for k in self.others:
            k.update(dt)
        if self.ready():
            shot = self.sling.update(dt)
            if shot:
                a, p = shot
                sp = self.MAX_V * (0.25 + 0.75 * p)
                self.throws += 1
                if random.random() < 0.14:
                    a += random.choice((-0.28, 0.28))
                    self.say("Dép bay lệch kìa! Ha ha!")
                elif self.throws % 4 == 0:
                    self.say(random.choice(("Chân anh qua vạch rồi! Không tính!", "Tính chứ! Vạch đâu mà qua!")))
                self.slip = {"x": 60.0, "y": 124.0, "vx": math.cos(a) * sp, "vy": math.sin(a) * sp, "rot": 0.0, "rest": 0.0, "hit": False}
                self.g.audio.play("slap", 0.7)
        s = self.slip
        if s:
            if s["rest"] > 0:
                s["rest"] -= dt
                if s["rest"] <= 0:
                    self.slip = None
                    self.after_throw(s)
            else:
                s["vy"] += self.GRAV * dt
                s["x"] += s["vx"] * dt
                s["y"] += s["vy"] * dt
                s["rot"] += 720 * dt
                for c in self.cans:
                    if c["up"] and abs(s["x"] - c["x"]) < 7 and abs(s["y"] - c["y"]) < 9:
                        self.knock(c, s["vx"] * 0.55, -70 + s["vy"] * 0.2)
                        s["vx"] *= 0.35
                        s["vy"] *= -0.2
                        s["hit"] = True
                        for o in self.cans:
                            d = abs(o["x"] - c["x"]) + abs(o["y"] - c["y"])
                            if o["up"] and d < 20:
                                self.knock(o, s["vx"] + random.uniform(10, 60), random.uniform(-90, -40))
                        break
                if s["x"] > W + 8:
                    self.say("Bay xuống mương rồi! Về bị mẹ mắng nha!")
                    s["rest"] = 0.8
                elif s["y"] >= self.floor:
                    s["y"] = self.floor
                    s["rest"] = 0.8
                    self.g.audio.play("thud", 0.5)
        for c in self.cans:
            if c["up"]:
                if not self.supported(c):
                    self.knock(c, random.uniform(-30, 30), -20)
                continue
            c["vy"] += self.GRAV * dt
            c["x"] += c["vx"] * dt
            c["y"] += c["vy"] * dt
            c["rot"] += c["spin"] * dt
            if c["y"] > self.floor - 4:
                c["y"] = self.floor - 4
                if abs(c["vy"]) > 40:
                    self.g.audio.play("can", 0.35)
                c["vy"] *= -0.4
                c["vx"] *= 0.6
                c["spin"] *= 0.5
                if abs(c["vy"]) < 12:
                    c["vy"] = 0.0
                    c["vx"] = 0.0
                    c["spin"] = 0.0
        if self.state == "restack":
            self.restack_t += dt
            n = len(self.cans)
            tgt = self.cans[min(n - 1, int(self.restack_t / 0.32))]
            self.kid.state = "walk"
            self.kid.facing = 1 if tgt["hx"] > self.kid.x else -1
            self.kid.x = lerp(self.kid.x, tgt["hx"], min(1.0, dt * 9))
            for i, c in enumerate(self.cans):
                if self.restack_t > (i + 1) * 0.32 and not c["up"]:
                    c.update(x=c["hx"], y=c["hy"], rot=0.0, vx=0.0, vy=0.0, spin=0.0, up=True)
                    self.g.audio.play("can", 0.25)
            if self.restack_t > n * 0.32 + 0.4:
                self.state = "back"
        elif self.state == "back":
            self.kid.state = "walk"
            self.kid.facing = -1
            self.kid.x -= 70 * dt
            if self.kid.x <= 150:
                self.kid.x = 150
                self.kid.state = "idle"
                self.kid.facing = 1
                self.state = "aim"

    def after_throw(self, s):
        if all(not c["up"] for c in self.cans):
            self.rounds += 1
            if self.rounds >= self.GOAL:
                self.say("Xạo mà trúng thiệt luôn!", 3.0)
                self.finish(2.6)
            else:
                self.say("Đổ hết rồi! Để em xếp lại cho!", 2.6)
                self.state = "restack"
                self.restack_t = 0.0
        elif s["hit"]:
            self.say(random.choice(("Còn mấy lon kìa anh!", "Trúng rồi! Tạt nữa đi!")))
        elif self.msg_t <= 0:
            self.say(random.choice(("Trật lất! Ai thua nhặt dép nha!", "Cao thủ gì kỳ vậy anh?")))

    def status(self):
        return ""

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        pygame.draw.line(c, (232, 220, 188), (72, 148), (70, 170))
        for k in self.others:
            k.draw(c, 146)
        self.me.draw(c, self.floor)
        self.kid.draw(c, 154)
        for cn in self.cans:
            img = self.can_img
            if cn["rot"]:
                img = pygame.transform.rotate(img, round(cn["rot"] / 45.0) * 45)
            c.blit(img, (int(cn["x"]) - img.get_width() // 2, int(cn["y"]) - img.get_height() // 2))
        s = self.slip
        if s:
            img = pygame.transform.rotate(self.slip_img, round(s["rot"] / 90.0) * 90)
            c.blit(img, (int(s["x"]) - img.get_width() // 2, int(s["y"]) - img.get_height() // 2))
        elif self.ready():
            sl = self.sling
            if sl.power > 0:
                sp = self.MAX_V * (0.25 + 0.75 * sl.power)
                vx, vy = math.cos(sl.angle) * sp, math.sin(sl.angle) * sp
                for i in range(1, 15):
                    t = i * 0.075
                    c.fill((252, 244, 214), (int(60 + vx * t), int(124 + vy * t + 0.5 * self.GRAV * t * t), 2, 2))
            c.blit(self.slip_img, (56, 120))
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)


ROPE_RHYME = ["Dây thun xanh đỏ", "Nhảy qua nhảy lại", "Mắt cá đầu gối", "Cao nữa cao thêm",
              "Trưa nắng xóm mình", "Tiếng cười giòn tan", "Ai mà vấp ngã", "Đứng dậy nhảy tiếp"]


class JumpGame(ChMini):
    title = "Nhảy dây"
    tip = "Nhấn Space (hoặc bấm chuột) để nhảy khi dây sắp chạm chân"
    LEVELS = [("Mắt cá chân", 3, 1.30), ("Đầu gối", 8, 1.18), ("Thắt lưng", 12, 1.08)]
    PER = 5
    JUMP_T = 0.56
    JUMP_H = 24.0

    def __init__(self, g):
        ChMini.__init__(self, g)
        self.bg, _, self.tint = paint_place("dinh")
        self.me = Actor(160, me_pal(True, False), expr="smile")
        self.g1 = Kid(102, PAL_GIRL_THAM, female=True, facing=1)
        self.g2 = Kid(218, PAL_GIRL_NA, female=True, facing=-1)
        self.others = [Kid(74, PAL_KID_ME, facing=1), Kid(90, PAL_KID_TEO, facing=1), Kid(246, PAL_KID_NA, facing=-1)]
        self.wide_view, self.cam, self.cam_top, self.world_w = True, 160.0, 51, W
        self.floor = 150
        self.phase = math.pi
        self.level = 0
        self.count = 0
        self.total = 0
        self.streak = 0
        self.best = 0
        self.jump = None
        self.fall = 0.0
        self.beat = 0
        self.tease = ["Anh lớn vậy mà nhảy dở hơn tụi em!", "Tại lâu rồi anh không chơi thôi!", "Thua rồi nha! Phải chịu phạt!"]
        self.n_tease = 0

    def period(self):
        return self.LEVELS[min(self.level, 2)][2]

    def time_to_bottom(self):
        rest = (2 * math.pi - (self.phase % (2 * math.pi))) % (2 * math.pi)
        return rest / (2 * math.pi) * self.period()

    def height(self):
        if self.jump is None:
            return 0.0
        return self.JUMP_H * math.sin(math.pi * clamp(self.jump / self.JUMP_T, 0, 1))

    def update(self, dt):
        ChMini.update(self, dt)
        g = self.g
        self.me.update(dt)
        for k in self.others:
            k.update(dt)
        before = self.phase
        self.phase += dt * 2 * math.pi / self.period()
        if self.fall > 0:
            self.fall -= dt
            if self.fall <= 0:
                self.me.state = "idle"
                self.me.set_expr("smile")
        elif self.jump is None and self.end_t is None and (g.space_pressed or g.mouse_pressed):
            self.jump = 0.0
            g.audio.play("click", 0.3)
        if self.jump is not None:
            self.jump += dt
            if self.jump >= self.JUMP_T:
                self.jump = None
                g.audio.play("thud", 0.3)
        # day cham dat moi vong quay
        if int(before / (2 * math.pi)) != int(self.phase / (2 * math.pi)):
            g.audio.play("tick", 0.6)
            self.beat += 1
            if self.end_t is None and self.fall <= 0:
                clear = self.LEVELS[self.level][1]
                if self.height() > clear:
                    self.count += 1
                    self.total += 1
                    self.streak += 1
                    self.best = max(self.best, self.streak)
                    if self.count >= self.PER:
                        self.count = 0
                        self.level += 1
                        if self.level >= len(self.LEVELS):
                            self.level = 2
                            self.say("Trời, anh nhảy được tới thắt lưng luôn!", 3.0)
                            self.finish(2.6)
                        else:
                            self.say("Nâng dây lên %s nha!" % self.LEVELS[self.level][0].lower(), 2.0)
                else:
                    self.streak = 0
                    self.jump = None
                    self.fall = 1.1
                    self.me.state = "sit"
                    self.me.set_expr("surprise")
                    self.say(self.tease[self.n_tease % 3])
                    self.n_tease += 1
                    g.audio.play("thud", 0.7)

    def status(self):
        return "Độ cao: %s" % self.LEVELS[self.level][0]

    def rope_points(self):
        clear = self.LEVELS[self.level][1]
        hy = 128
        mid_low = self.floor - clear + 1
        mid_high = 84
        k = 0.5 + 0.5 * math.cos(self.phase)
        my = lerp(mid_high, mid_low, k)
        pts = []
        for i in range(21):
            t = i / 20
            x = 110 + 100 * t
            y = hy + (my - hy) * 4 * t * (1 - t)
            pts.append((x, y))
        return pts, k

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        for k in self.others:
            k.draw(c, 146)
        self.g1.draw(c, self.floor)
        self.g2.draw(c, self.floor)
        pts, k = self.rope_points()
        cols = [(216, 90, 90), (224, 192, 74), (88, 160, 216), (98, 192, 122)]
        behind = math.sin(self.phase) < 0

        def rope():
            for i in range(20):
                pygame.draw.line(c, cols[i // 2 % 4], pts[i], pts[i + 1])
        if behind:
            rope()
        # bong tren dat bao hieu day sap toi
        sw = 8 + int(k * 26)
        shade = pygame.Surface((sw, 3), pygame.SRCALPHA)
        shade.fill((60, 40, 40, 120))
        c.blit(shade, (160 - sw // 2, self.floor + 2))
        self.me.draw(c, self.floor - int(self.height()))
        if not behind:
            rope()
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)

    def draw_hud(self, scr, f):
        line = ROPE_RHYME[self.beat % len(ROPE_RHYME)]
        s = f.cap_sub.render(line, True, (255, 246, 222))
        s.set_alpha(150)
        scr.blit(s, (WIN_W // 2 - s.get_width() // 2, 140))
        ChMini.draw_hud(self, scr, f)


class FruitGame(ChMini):
    title = "Hứng trứng cá"
    tip = "← → (hoặc rê chuột) để di chuyển nón  ·  Tránh cành khô, hứng trái đỏ"
    GOAL = 15
    LIMIT = 55.0

    def __init__(self, g):
        ChMini.__init__(self, g)
        self.bg, _, self.tint = paint_place("tree")
        self.me = Actor(170, me_pal(True, False), expr="smile")
        self.kid = Kid(120, PAL_KID_ME, facing=1, state="sit")
        self.floor = 150
        self.items = []
        self.spawn = 0.4
        self.got = 0
        self.green = 0
        self.stun = 0.0
        self.spark = []
        self.ground = []
        self.mouse_on = False
        self.last_mouse = g.mouse
        self.rnd = random.Random(9)
        self.bursting = False

    def update(self, dt):
        ChMini.update(self, dt)
        g = self.g
        self.me.update(dt)
        speed = 150 * (0.35 if self.stun > 0 else 1.0)
        self.stun = max(0.0, self.stun - dt)
        k = g.keys
        dx = 0
        if k is not None:
            dx = int(k[pygame.K_RIGHT] or k[pygame.K_d]) - int(k[pygame.K_LEFT] or k[pygame.K_a])
        if g.mouse != self.last_mouse:
            self.mouse_on = True
            self.last_mouse = g.mouse
        if dx:
            self.mouse_on = False
        if self.end_t is None:
            if self.mouse_on:
                d = g.mouse[0] - self.me.x
                if abs(d) > 2:
                    self.me.x += clamp(d, -speed * dt, speed * dt)
                    self.me.facing = 1 if d > 0 else -1
                    self.me.state = "walk"
                else:
                    self.me.state = "idle"
            elif dx:
                self.me.x += dx * speed * dt
                self.me.facing = dx
                self.me.state = "walk"
            else:
                self.me.state = "idle"
            self.me.x = clamp(self.me.x, 14, W - 14)
            self.spawn -= dt
            if self.spawn <= 0:
                burst = self.time % 9.0 < 1.7
                self.spawn = 0.11 if burst else self.rnd.uniform(0.34, 0.62)
                if burst and not self.bursting:
                    self.say("Rung mạnh nè anh!", 1.6)
                self.bursting = burst
                r = 0.0 if burst else self.rnd.random()
                kind = "red" if r < 0.68 else "green" if r < 0.82 else "leaf" if r < 0.93 else "twig"
                self.items.append({"x": self.rnd.uniform(16, W - 16), "y": 40.0, "kind": kind,
                                   "vy": self.rnd.uniform(14, 22) if kind == "leaf" else self.rnd.uniform(58, 92),
                                   "ph": self.rnd.random() * 6})
            if self.got >= self.GOAL or self.time > self.LIMIT:
                self.me.state = "idle"
                self.say("Nhiều quá trời! Đem chia cả đám!", 3.0)
                self.finish(2.6)
        hy = self.floor - 34
        for it in list(self.items):
            it["y"] += it["vy"] * dt
            sway = math.sin(self.time * 2 + it["ph"]) * 16 * dt if it["kind"] == "leaf" else 0
            it["x"] += sway
            if it["kind"] != "leaf" and abs(it["y"] - hy) < 5 and abs(it["x"] - self.me.x) < 13:
                self.items.remove(it)
                self.catch(it)
            elif it["y"] > self.floor + 6:
                self.items.remove(it)
                if it["kind"] == "red":
                    self.ground.append([it["x"], 2.2])
        self.ground = [[x, t - dt] for x, t in self.ground if t > dt]
        for s in self.spark:
            s[0] += s[2] * dt
            s[1] += s[3] * dt
            s[3] += 90 * dt
            s[4] -= dt
        self.spark = [s for s in self.spark if s[4] > 0]

    def catch(self, it):
        a = self.g.audio
        if it["kind"] == "red":
            self.got += 1
            a.play("catch", 0.8)
            for _ in range(7):
                self.spark.append([it["x"], it["y"], random.uniform(-40, 40), random.uniform(-60, -10), 0.4])
        elif it["kind"] == "green":
            self.green += 1
            a.play("catch", 0.3)
            self.say(random.choice(("Trái xanh chua lè anh ơi!", "Chưa chín mà hứng làm chi!")))
        else:
            self.got = max(0, self.got - 1)
            self.stun = 0.6
            a.play("thud", 0.7)
            self.say("Úi! Cành khô rớt trúng nón!")

    def status(self):
        return ""

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        self.kid.x = 120
        shake = int(math.sin(self.time * 18) * 1)
        self.kid.draw(c, 58 + shake)
        for x, _ in self.ground:
            c.fill((176, 56, 52), (int(x), self.floor + 5, 2, 1))
        self.me.draw(c, self.floor)
        hx = int(self.me.x)
        hy = self.floor - 32
        pygame.draw.polygon(c, (216, 196, 140), [(hx - 13, hy - 2), (hx + 13, hy - 2), (hx, hy + 8)])
        pygame.draw.polygon(c, (178, 156, 104), [(hx, hy - 2), (hx + 13, hy - 2), (hx, hy + 8)])
        pygame.draw.line(c, (120, 96, 60), (hx - 13, hy - 2), (hx + 13, hy - 2))
        if self.got:
            for i in range(min(self.got, 9)):
                c.fill((208, 64, 60), (hx - 8 + i * 2, hy - 3 - (i % 3 == 0), 2, 2))
        for it in self.items:
            x, y = int(it["x"]), int(it["y"])
            if it["kind"] in ("red", "green"):  # trai nho, tron
                col = (212, 60, 56) if it["kind"] == "red" else (150, 186, 86)
                c.fill((46, 34, 40), (x - 1, y - 2, 3, 5))
                c.fill((46, 34, 40), (x - 2, y - 1, 5, 3))
                c.fill(col, (x - 1, y - 1, 3, 3))
                c.set_at((x - 1, y - 1), (252, 190, 170) if it["kind"] == "red" else (200, 224, 130))
            elif it["kind"] == "leaf":
                c.fill((206, 168, 74), (x, y, 3, 2))
                c.set_at((x + 1, y), (232, 200, 110))
            else:
                pygame.draw.line(c, (92, 66, 44), (x - 6, y - 2), (x + 6, y + 2), 2)
                pygame.draw.line(c, (92, 66, 44), (x + 1, y), (x + 4, y - 4))
        for s in self.spark:
            c.fill((255, 226, 150), (int(s[0]), int(s[1]), 1, 1))
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)


# 8 diem moi hinh, de noi suy khi gap: mui trai, day buom trai, dinh, day buom phai, mui phai, 3 diem day
FOLD_SHAPES = [
    [(-50, -35), (-25, -35), (0, -35), (25, -35), (50, -35), (50, 35), (0, 35), (-50, 35)],
    [(-50, -30), (-25, -30), (0, -30), (25, -30), (50, -30), (50, 20), (0, 20), (-50, 20)],
    [(-50, -4), (-25, -17), (0, -30), (25, -30), (50, -30), (50, 20), (0, 20), (-50, 20)],
    [(-50, -4), (-25, -17), (0, -30), (25, -17), (50, -4), (50, 20), (0, 20), (-50, 20)],
    [(-46, 2), (-23, -14), (0, -30), (23, -14), (46, 2), (46, 14), (0, 14), (-46, 14)],
    [(-64, -8), (-14, 6), (0, -34), (14, 6), (64, -8), (34, 26), (0, 26), (-34, 26)],
]
FOLD_STEPS = [
    ((0, 1), "Gấp đôi tờ giấy", False),
    ((1, 1), "Bẻ góc trái xuống", False),
    ((-1, 1), "Bẻ góc phải xuống", False),
    ((0, -1), "Gập mép dưới lên", False),
    ((1, 0), "Mở ra rồi kéo hai bên", True),
]
FOLD_CREASE = [
    [],
    [((-50, 12), (50, 12))],
    [((-50, 12), (50, 12)), ((-50, -4), (0, -30)), ((-50, -4), (0, 8))],
    [((-50, -4), (0, 8)), ((50, -4), (0, 8)), ((-50, 12), (50, 12))],
    [((-46, 6), (46, 6)), ((0, -30), (0, 6))],
    [((0, -34), (0, 6)), ((-44, 6), (44, 6))],
]


def draw_arrow(scr, cx, cy, dx, dy, col, both=False):
    """Ve mui ten (font khong co san ky tu mui ten cheo)."""
    n = math.hypot(dx, dy)
    ux, uy = dx / n, dy / n
    px, py = -uy, ux
    a = (cx - ux * 18, cy - uy * 18)
    b = (cx + ux * 18, cy + uy * 18)
    pygame.draw.line(scr, col, a, b, 5)

    def head(tip, sx, sy):
        pygame.draw.polygon(scr, col, [tip, (tip[0] - sx * 14 + px * 10, tip[1] - sy * 14 + py * 10),
                                       (tip[0] - sx * 14 - px * 10, tip[1] - sy * 14 - py * 10)])
    head((b[0] + ux * 4, b[1] + uy * 4), ux, uy)
    if both:
        head((a[0] - ux * 4, a[1] - uy * 4), -ux, -uy)


class FoldGame(ChMini):
    title = "Gấp thuyền giấy"
    tip = "Kéo chuột theo mũi tên  ·  hoặc nhấn phím mũi tên đúng hướng"

    def __init__(self, g):
        ChMini.__init__(self, g)
        self.step = 0
        self.anim = None
        self.drag = None
        self.bg, _, self.tint = paint_place("porch")
        self.dim = pygame.Surface((W, H))
        self.dim.fill((110, 96, 90))

    def ready(self):
        return self.anim is None and self.end_t is None and self.step < len(FOLD_STEPS)

    def do_step(self):
        self.anim = 0.0
        self.g.audio.play("paper", 0.8)

    def update(self, dt):
        ChMini.update(self, dt)
        g = self.g
        if self.anim is not None:
            self.anim += dt / 0.5
            if self.anim >= 1:
                self.anim = None
                self.step += 1
                if self.step >= len(FOLD_STEPS):
                    self.say("Oa! Hay vậy!", 3.0)
                    self.finish(2.8)
            return
        if not self.ready():
            return
        if g.nav:
            d = FOLD_STEPS[self.step][0]
            want = 1 if d[0] > 0 or (d[0] == 0 and d[1] > 0) else -1
            if g.nav == want:
                self.do_step()
            else:
                self.say("Ngược rồi anh ơi!", 1.2)
            return
        if g.mouse_pressed:
            self.drag = g.mouse
        if self.drag:
            dx, dy = g.mouse[0] - self.drag[0], g.mouse[1] - self.drag[1]
            d = math.hypot(dx, dy)
            wx, wy = FOLD_STEPS[self.step][0]
            wl = math.hypot(wx, wy)
            ok = d > 18 and ((dx * wx + dy * wy) / (d * wl) > 0.5 or (wx, wy) == (1, 0) and abs(dx) > abs(dy))
            if ok:
                self.drag = None
                self.do_step()
            elif g.mouse_released:
                self.drag = None

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)
        c.blit(self.dim, (0, 0), special_flags=pygame.BLEND_MULT)
        cx, cy = 160, 84
        c.fill((122, 96, 70), (64, 34, 192, 104))
        c.fill((140, 112, 82), (66, 36, 188, 100))
        k = 0.0 if self.anim is None else self.anim
        k = k * k * (3 - 2 * k)
        a = FOLD_SHAPES[self.step]
        b = FOLD_SHAPES[min(self.step + 1, len(FOLD_SHAPES) - 1)]
        pts = [(int(cx + lerp(p[0], q[0], k)), int(cy + lerp(p[1], q[1], k))) for p, q in zip(a, b)]
        shadow = [(x + 2, y + 2) for x, y in pts]
        pygame.draw.polygon(c, (84, 66, 52), shadow)
        pygame.draw.polygon(c, (244, 240, 226), pts)
        pygame.draw.polygon(c, (168, 160, 144), pts, 1)
        # ke o tap
        idx = self.step
        if idx == 0 and self.anim is None:
            for y in range(-27, 34, 7):
                pygame.draw.line(c, (178, 200, 226), (cx - 49, cy + y), (cx + 49, cy + y))
            pygame.draw.line(c, (226, 150, 150), (cx - 40, cy - 34), (cx - 40, cy + 34))
        for p, q in (FOLD_CREASE[idx] if self.anim is None else ()):
            pygame.draw.line(c, (186, 178, 160), (cx + p[0], cy + p[1]), (cx + q[0], cy + q[1]))

    def draw_hud(self, scr, f):
        ChMini.draw_hud(self, scr, f)
        if self.ready():
            d, text, both = FOLD_STEPS[self.step]
            g = self.g
            line = "Bước %d/%d: %s" % (self.step + 1, len(FOLD_STEPS), text)
            g.shadow_text(scr, f.cap_sub, line, (255, 236, 190), WIN_W // 2 - 30, 590, off=2)
            ax = WIN_W // 2 - 30 + f.cap_sub.size(line)[0] // 2 + 44
            draw_arrow(scr, ax + 2, 612, d[0], d[1], (20, 16, 30), both)
            draw_arrow(scr, ax, 610, d[0], d[1], (255, 236, 190), both)


class BoatGame(ChMini):
    title = "Đua thuyền trong mưa"
    tip = "Giữ chuột trên mặt nước để lái dòng chảy  ·  hoặc ↑ ↓"
    LENGTH = 860.0
    X = 92
    TOP, BOT = 34, 146

    def __init__(self, g):
        ChMini.__init__(self, g)
        rnd = random.Random(33)
        self.tint = paint_place("porch")[2]
        self.strip = self.paint(rnd)
        self.state = "place"
        self.count = 0.0
        self.dist = 0.0
        self.y = 90.0
        self.vy = 0.0
        self.slow = 0.0
        self.img = make_tiny_boat()
        self.rip = []
        self.obs = []
        self.drops = [[rnd.uniform(0, W), rnd.uniform(0, H), rnd.uniform(200, 260)] for _ in range(90)]
        x = 240.0
        while x < self.LENGTH - 80:
            self.obs.append({"x": x, "y": rnd.uniform(self.TOP + 12, self.BOT - 12),
                             "kind": rnd.choice(("rock", "branch", "weed")), "hit": False})
            x += rnd.uniform(70, 125)
        self.rivals = [{"d": -14.0, "y": 62.0, "v": 37.0, "sunk": 1e9, "col": (246, 226, 196)},
                       {"d": 18.0, "y": 118.0, "v": 34.0, "sunk": 1e9, "col": (222, 236, 246)},
                       {"d": 6.0, "y": 44.0, "v": 35.0, "sunk": 360.0, "col": (246, 214, 214)}]
        for r in self.rivals:
            r["img"] = make_tiny_boat(r["col"], lerpc(r["col"], (90, 80, 80), 0.3))
            r["sink"] = 0.0
        self.said = {}
        self.tip_place = "↑ ↓ hoặc rê chuột: chọn chỗ thả  ·  Enter hoặc bấm chuột: thả"
        self.say("Ai tới cục đá kia trước là thắng!", 3.0)

    def paint(self, rnd):
        c = pygame.Surface((W * 2, H))
        c.fill(C_DIRT)
        speckle(c, (0, 0, W * 2, H), [C_DIRT_D, C_DIRT_L, hexc("#8e6f4c")], 5200, rnd)
        vgrad(c, (0, self.TOP, W * 2, self.BOT - self.TOP), hexc("#8e8064"), hexc("#a6946e"), 12)
        for x in range(0, W * 2, 3):
            for y0, s in ((self.TOP, -1), (self.BOT, 1)):
                c.fill(C_DIRT_D, (x, y0 + rnd.randint(-1, 1), 3, 1))
                if rnd.random() < 0.3:
                    h = rnd.randint(2, 6)
                    pygame.draw.line(c, rnd.choice((C_GRASS_D, C_GRASS)), (x, y0), (x + rnd.randint(-1, 1), y0 + s * h))
        return c

    def update(self, dt):
        ChMini.update(self, dt)
        g = self.g
        for d in self.drops:
            d[0] -= d[2] * 0.16 * dt
            d[1] += d[2] * dt
            if d[1] > H:
                d[1] = random.uniform(-14, 0)
                d[0] = random.uniform(0, W + 30)
                if random.random() < 0.05:
                    self.rip.append([d[0], random.uniform(self.TOP + 4, self.BOT - 4), 0.7])
        k = g.keys
        keyv = 0
        if k is not None:
            keyv = int(k[pygame.K_DOWN] or k[pygame.K_s]) - int(k[pygame.K_UP] or k[pygame.K_w])
        if self.state == "place":
            self.y = clamp(self.y + keyv * 90 * dt, self.TOP + 7, self.BOT - 7)
            if self.TOP < g.mouse[1] < self.BOT and g.mouse != getattr(self, "last_m", g.mouse):
                self.y = clamp(float(g.mouse[1]), self.TOP + 7, self.BOT - 7)
            self.last_m = g.mouse
            if g.confirm or g.mouse_pressed:
                self.state = "count"
                self.count = 0.0
                g.audio.play("paper", 0.6)
                self.say("Một... hai... ba! Thả!", 1.2)
            return
        if self.state == "count":
            self.count += dt
            if self.count > 1.2:
                self.state = "race"
                self.rip.append([self.X, self.y, 2.0])
            return
        ax = keyv * 170.0
        if g.mouse_held:
            ax += clamp((g.mouse[1] - self.y) * 7.0, -190, 190)
            if random.random() < dt * 18:
                self.rip.append([g.mouse[0], g.mouse[1], 1.0])
        if g.mouse_pressed:
            self.rip.append([g.mouse[0], g.mouse[1], 2.0])
            g.audio.play("catch", 0.15)
        self.vy += ax * dt
        self.vy *= max(0.0, 1 - 2.6 * dt)
        self.y = clamp(self.y + self.vy * dt, self.TOP + 7, self.BOT - 7)
        self.slow = max(0.0, self.slow - dt)
        v = 38.0 * (0.4 if self.slow > 0 else 1.0)
        if self.end_t is None:
            self.dist += v * dt
        for o in self.obs:
            sx = self.X + o["x"] - self.dist
            if not o["hit"] and abs(sx - self.X) < 11 and abs(o["y"] - self.y) < 10:
                o["hit"] = True
                self.slow = 0.7
                self.vy += 46 if self.y >= o["y"] else -46
                self.rip.append([self.X, self.y, 2.0])
                g.audio.play("thud", 0.4)
        for r in self.rivals:
            if r["d"] > r["sunk"]:
                r["sink"] = min(1.0, r["sink"] + dt / 1.6)
                if "sunk" not in self.said:
                    self.said["sunk"] = True
                    self.say("Trời ơi! Thuyền tao chìm rồi!", 2.6)
            else:
                r["d"] += r["v"] * dt
        for mark, key, line in ((160, "a", "Ê! Thuyền tao dẫn đầu rồi!"), (300, "b", "Không tính! Thuyền mày đụng thuyền tao!"),
                                (470, "c", "Ha ha ha! Ai biểu gấp ẩu!"), (720, "d", "Sắp tới cục đá rồi!")):
            if self.dist > mark and key not in self.said:
                self.said[key] = True
                self.say(line, 3.0 if key == "d" else 2.4)
        if self.dist >= self.LENGTH and self.end_t is None:
            self.finish(1.8)
        for rp in self.rip:
            rp[2] -= dt
        self.rip = [rp for rp in self.rip if rp[2] > 0]

    def draw(self, c):
        off = int(self.dist) % W
        c.blit(self.strip, (-off, 0))
        for i in range(40):
            y = self.TOP + 4 + (i * 13) % (self.BOT - self.TOP - 8)
            x = (i * 47 - int(self.dist * (1.3 + (i % 3) * 0.2)) - int(self.time * 16)) % W
            c.fill((188, 176, 146), (x, y, 5 + i % 6, 1))
        # cuc da dich
        bx = int(self.X + self.LENGTH - self.dist) + 14
        if bx < W + 40:
            yc = (self.TOP + self.BOT) // 2
            pygame.draw.ellipse(c, (84, 80, 76), (bx, yc - 34, 36, 70))
            pygame.draw.ellipse(c, (128, 124, 116), (bx + 2, yc - 36, 32, 66))
            c.fill((168, 164, 154), (bx + 8, yc - 28, 8, 4))
        for o in self.obs:
            x = int(self.X + o["x"] - self.dist)
            if x < -20 or x > W + 20:
                continue
            y = int(o["y"])
            if o["kind"] == "rock":
                pygame.draw.circle(c, (86, 84, 80), (x, y + 1), 7)
                pygame.draw.circle(c, (132, 128, 120), (x, y), 6)
                c.fill((170, 166, 156), (x - 3, y - 3, 3, 2))
            elif o["kind"] == "branch":
                pygame.draw.line(c, (90, 66, 44), (x - 10, y + 4), (x + 10, y - 4), 3)
                pygame.draw.line(c, (116, 88, 58), (x - 2, y), (x + 4, y + 7), 2)
                c.fill(C_LEAF_L, (x + 3, y + 6, 3, 2))
            else:
                for dx, col in ((-5, (150, 120, 60)), (2, (178, 150, 76)), (6, (132, 112, 58))):
                    c.fill(col, (x + dx, y + dx // 2, 6, 3))
        for r in self.rivals:
            x = int(self.X + r["d"] - self.dist)
            y = int(r["y"] + math.sin(self.time * 2.4 + r["d"] * 0.02) * 1.5)
            if r["sink"] < 1:
                img = r["img"]
                h = int(img.get_height() * (1 - r["sink"]))
                if h > 0:
                    c.blit(img, (x - 8, y - 6 + img.get_height() - h), (0, 0, img.get_width(), h))
        y = int(self.y + math.sin(self.time * 3) * 1.5)
        if self.state == "place":
            pygame.draw.line(c, (250, 244, 220), (self.X - 14, y), (self.X - 10, y))
            pygame.draw.line(c, (250, 244, 220), (self.X + 10, y), (self.X + 14, y))
        c.fill((90, 86, 80), (self.X - 8, y + 5, 17, 1))
        c.blit(self.img, (self.X - 8, y - 6))
        for x, yy, t in self.rip:
            r = int((2.0 - t) * 10) + 2
            pygame.draw.ellipse(c, (206, 206, 196), (int(x) - r, int(yy) - r // 2, r * 2, max(2, r)), 1)
        for d in self.drops:
            pygame.draw.line(c, (206, 214, 232), (int(d[0]), int(d[1])), (int(d[0]) + 1, int(d[1]) - 5))
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)

    def draw_hud(self, scr, f):
        self.tip = self.tip_place if self.state == "place" else BoatGame.tip
        ChMini.draw_hud(self, scr, f)


class PenaltyGame(ChMini):
    title = "Đá penalty"
    tip = "Kéo chuột lên để chọn hướng và lực  ·  hoặc ← → chỉnh hướng, giữ rồi thả Space"
    SHOTS = 5

    def __init__(self, g):
        ChMini.__init__(self, g)
        rnd = random.Random(55)
        self.tint = paint_place("field")[2]
        self.bg = self.paint(rnd)
        self.sling = Sling(g, -math.pi / 2, amin=-2.6, amax=-0.54, max_drag=60.0, invert=False)
        self.keepers = [Kid(160, PAL_KID_TEO, facing=1), Kid(160, PAL_KID_HUNG, facing=1)]
        self.watch = [Kid(36, PAL_KID_ME, facing=1), Kid(284, PAL_KID_NA, facing=-1)]
        self.shot = 0
        self.scored = 0
        self.fly = None
        self.kx = 160.0
        self.ktx = 160.0
        self.rest = 0.0
        self.lines_in = ["Vô!!! Ha ha ha!", "Thủ môn gì kỳ vậy!", "Sút hay ghê anh ơi!"]
        self.lines_out = ["Bắt được rồi nha!", "Dễ ợt!", "Chắn hết khung thành rồi còn đâu!"]

    def paint(self, rnd):
        c = pygame.Surface((W, H))
        vgrad(c, (0, 0, W, 66), hexc("#10163a"), hexc("#3a4674"), 16)
        speckle(c, (0, 0, W, 50), [(210, 214, 240), (150, 160, 200)], 60, rnd)
        paint_far(c, 66, rnd, "#2c3a48", "#364654")
        c.fill(C_GRASS_D, (0, 70, W, 110))
        speckle(c, (0, 70, W, 110), [C_GRASS, C_LEAF_D, C_GRASS_L], 2400, rnd)
        for x in range(96, 228, 8):
            pygame.draw.line(c, (150, 156, 170), (x, 60), (x, 118))
        for y in range(60, 118, 8):
            pygame.draw.line(c, (150, 156, 170), (92, y), (228, y))
        c.fill(hexc("#b8a060"), (90, 58, 4, 62))
        c.fill(hexc("#b8a060"), (226, 58, 4, 62))
        c.fill(hexc("#b8a060"), (90, 58, 140, 4))
        pygame.draw.line(c, (220, 216, 200), (60, 120), (260, 120))
        c.fill((230, 226, 210), (158, 160, 5, 2))
        return c

    def keeper(self):
        return self.keepers[0 if self.shot < 3 else 1]

    def ready(self):
        return self.fly is None and self.rest <= 0 and self.end_t is None

    def update(self, dt):
        ChMini.update(self, dt)
        if self.rest > 0:
            self.rest -= dt
        if self.ready():
            sh = self.sling.update(dt)
            if sh:
                a, p = sh
                tx = 160 + math.cos(a) / max(0.2, -math.sin(a)) * 74
                ty = 112 - p * 62
                self.fly = {"t": 0.0, "tx": tx, "ty": ty, "p": p}
                near = random.random() < 0.38
                self.ktx = clamp(tx + random.uniform(-6, 6), 104, 216) if near else random.uniform(112, 208)
                self.g.audio.play("thud", 0.8)
        f = self.fly
        if f:
            f["t"] += dt / 0.55
            self.kx += clamp(self.ktx - self.kx, -130 * dt, 130 * dt)
            if f["t"] >= 1:
                self.judge(f)
                self.fly = None
                self.shot += 1
                self.rest = 1.1
                if self.shot >= self.SHOTS:
                    self.shot = self.SHOTS - 1
                    self.say("Thôi nghỉ! Ai cũng giỏi hết trơn!", 3.0)
                    self.finish(2.4)
        elif self.rest <= 0:
            self.kx = lerp(self.kx, 160.0, min(1.0, dt * 4))

    def judge(self, f):
        half = 22 if self.shot >= 3 else 12
        a = self.g.audio
        if abs(f["tx"] - 160) > 64 or f["ty"] < 60:
            self.say(random.choice(("Bay lên trời luôn!", "Trật lất! Đi nhặt banh đi anh!")))
            a.play("click", 0.5)
        elif abs(f["tx"] - self.kx) < half and f["ty"] > 76:
            self.say(random.choice(self.lines_out))
            a.play("thud", 0.6)
        else:
            self.scored += 1
            self.say(random.choice(self.lines_in))
            a.play("ok", 0.4)

    def status(self):
        return ""

    def draw(self, c):
        c.blit(self.bg, (0, 0))
        for k in self.watch:
            k.draw(c, 132)
        kp = self.keeper()
        kp.x = self.kx
        kp.draw(c, 118)
        f = self.fly
        if f:
            t = min(1.0, f["t"])
            bx, by, r = lerp(160, f["tx"], t), lerp(160, f["ty"], t) - math.sin(t * 3.14) * 12, int(lerp(6, 2, t))
        else:
            bx, by, r = 160, 156, 6
        pygame.draw.circle(c, (40, 36, 44), (int(bx), int(by)), r + 1)
        pygame.draw.circle(c, (240, 236, 224), (int(bx), int(by)), r)
        c.set_at((int(bx), int(by)), (40, 36, 44))
        sl = self.sling
        if self.ready() and sl.power > 0:
            tx = 160 + math.cos(sl.angle) / max(0.2, -math.sin(sl.angle)) * 74
            ty = 112 - sl.power * 62
            for i in range(1, 12):
                k = i / 12
                c.fill((252, 244, 214), (int(lerp(160, tx, k)), int(lerp(156, ty, k)), 2, 2))
        c.blit(self.tint, (0, 0), special_flags=pygame.BLEND_MULT)


# ---------------------------------------------------------------- chuong / canh
# Toan game 5 chuong. Moi chuong gom nhieu canh; moi canh la 1 ham trong class Game.
# (ten ham, ten hien thi, mo ta ngan)
CH1_SCENES = [
    ("canh0_lap_lai", "Cảnh 1 · Những ngày giống nhau", "Thứ Ba, thứ Tư, thứ Năm"),
    ("canh1_van_phong", "Cảnh 2 · Văn phòng", "Chiều thứ Sáu, 17:30"),
    ("canh2_tram_dem", "Cảnh 3 · Trạm xe 11:11", "Đêm thứ Sáu, 23:04"),
    ("canh3_bus_dem", "Cảnh 4 · Chuyến bus đêm", "Ông lão và tấm vé"),
    ("canh4_phong_tro", "Cảnh 5 · Phòng trọ", "Những tấm ảnh cũ"),
    ("canh5_bao_thuc", "Cảnh 6 · Báo thức", "Sáng thứ Bảy, 06:30"),
    ("canh6_tram_sang", "Cảnh 7 · Trạm xe buổi sáng", "Quên bóp, tấm vé nhàu"),
    ("canh7_chuyen_di", "Cảnh 8 · Chuyến đi", "Ổ bánh mì, “Tới nơi rồi”"),
]
CH2_SCENES = [
    ("c2_canh1_cong_lang", "Cảnh 1 · Cổng làng", "Có gì đó sai sai"),
    ("c2_canh2_ban_bi", "Cảnh 2 · Bắn bi", "Minigame"),
    ("c2_canh3_to_lich", "Cảnh 3 · Tờ lịch", "Đồng hồ đứng im"),
    ("c2_canh4_bui_tre", "Cảnh 4 · Bụi tre đầu làng", "Minigame tạt lon"),
    ("c2_canh5_tiem_ba_nga", "Cảnh 5 · Tiệm bà Nga", "Mùi kẹo ngày xưa"),
    ("c2_canh6_xe_ha_cao", "Cảnh 6 · Xe há cảo", "Tiếng rao"),
    ("c2_canh7_san_dinh", "Cảnh 7 · Sân sau đình", "Minigame nhảy dây"),
    ("c2_canh8_cay_trung_ca", "Cảnh 8 · Cây trứng cá", "Minigame hứng trái"),
    ("c2_canh9_con_mua", "Cảnh 9 · Cơn mưa chiều", "Gấp và đua thuyền"),
]
CH3_SCENES = [
    ("c3_canh1_loi_moi", "Cảnh 1 · Lời mời", "Chạy về trong mưa"),
    ("c3_canh2_ong_ba", "Cảnh 2 · Ông bà", "Ngôi nhà 18 năm trước"),
    ("c3_canh3_ba_me", "Cảnh 3 · Ba mẹ", "Hai tiếng cảm ơn cô"),
    ("c3_canh4_bua_com", "Cảnh 4 · Bữa cơm", "Chiều mưa năm 2008"),
]
CH4_SCENES = [
    ("c4_canh1_truong_lang", "Cảnh 1 · Ngôi trường", "Em ước gì?"),
    ("c4_canh2_tran_banh", "Cảnh 2 · Trận banh", "Minigame penalty"),
]
CH5_SCENES = [
    ("c5_canh1_tinh_day", "Cảnh 1 · Tỉnh dậy", "Mơ thôi sao"),
    ("c5_canh2_van_kip", "Cảnh 2 · Vẫn kịp", "Trời chưa tối mà"),
    ("c5_canh3_ve_nha", "Cảnh 3 · Về nhà", "Ăn cơm chưa con?"),
    ("c5_canh4_bua_com_hai", "Cảnh 4 · Bữa cơm thứ hai", "Một tiếng mẹ"),
    ("c5_canh5_mot_buoi_sang", "Cảnh 5 · Một buổi sáng", "Và những năm về sau"),
]
# (ten chuong, mo ta, danh sach canh; None = chua viet)
CHAPTERS = [
    ("Chương 1 · Tấm vé", "Đêm thứ Sáu → sáng thứ Bảy", CH1_SCENES),
    ("Chương 2 · Về làng", "Một ngày ở làng cũ", CH2_SCENES),
    ("Chương 3 · Bữa cơm", "Chiều mưa năm 2008", CH3_SCENES),
    ("Chương 4 · Trận banh tối", "Sau bữa cơm", CH4_SCENES),
    ("Chương 5 · Chuyến về", "Trời chưa tối mà", CH5_SCENES),
]
SCENES = CH1_SCENES


def last_chapter():
    return max(i for i, c in enumerate(CHAPTERS) if c[2])


def save_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "THE_TICKET", "save.txt")


def settings_path():
    return os.path.join(os.path.dirname(save_path()), "settings.txt")


def read_text(path):
    if WEB:
        import platform
        value = platform.window.localStorage.getItem("the-ticket:" + os.path.basename(path))
        if value is None:
            raise FileNotFoundError(path)
        return str(value)
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def write_text(path, text):
    if WEB:
        import platform
        platform.window.localStorage.setItem("the-ticket:" + os.path.basename(path), text)
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def open_feedback():
    if WEB:
        import platform
        platform.window.parent.eval("window.Feedback.open(window.SITE.games.list.find(function (g) { return g.id === 'the-ticket'; }))")
    else:
        webbrowser.open(FEEDBACK_URL)


def load_volume():
    """Tra ve (am luong, tat tieng); chua luu thi la mac dinh."""
    try:
        a, b = read_text(settings_path()).split()
        return clamp(float(a), 0.0, 1.0), b == "1"
    except Exception:
        return 1.0, False


def save_volume(master, muted):
    try:
        write_text(settings_path(), "%.2f %d" % (master, 1 if muted else 0))
    except Exception:
        pass


def load_progress():
    """Tra ve (chuong, canh) hoac None. File cu chi co 1 so = canh cua chuong 1."""
    try:
        parts = [int(x) for x in read_text(save_path()).split()]
        ch, sc = (0, parts[0]) if len(parts) == 1 else (parts[0], parts[1])
        ch = clamp(ch, 0, last_chapter())
        sc = clamp(sc, 0, len(CHAPTERS[ch][2]) - 1)
        return (ch, sc) if (ch, sc) != (0, 0) else None
    except Exception:
        return None


def save_progress(ch, i):
    i = "%d %d" % (ch, i)
    try:
        write_text(save_path(), str(i))
    except Exception:
        pass


# ---------------------------------------------------------------- game
class Game:
    def __init__(self):
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
        pygame.mixer.pre_init(SR, -16, 2, 512)
        pygame.init()
        pygame.display.set_icon(pygame.transform.scale(make_app_icon(), (64, 64)))
        self.screen = pygame.display.set_mode((WIN_W, WIN_H), 0 if WEB else pygame.SCALED)
        pygame.display.set_caption("THE TICKET")
        self.canvas = pygame.Surface((W, H))
        self.clock = pygame.time.Clock()
        self.fonts = Fonts()
        self.screen.fill((0, 0, 0))
        msg = self.fonts.hint.render("Đang tải...", True, (180, 180, 190))
        self.screen.blit(msg, (WIN_W // 2 - msg.get_width() // 2, WIN_H // 2))
        pygame.display.flip()
        pygame.event.pump()
        self.audio = Audio()
        self.audio.apply(*load_volume())
        self.vol_t = 0.0
        self.vol_drag = False
        self.mouse_win = (0, 0)
        self.auto_talk = False
        self.grey = 0.0
        self.stamp = ""
        self.memories = []
        self.toast = None
        self.dt = 0.0
        self.confirm = False
        self.space_pressed = False
        self.nav = 0
        self.back = False
        self.keys = None
        self.menu = None
        self.scene_no = None
        self.chapter_no = 0
        self.end_chapter = 0
        self.keep_v = None
        self.pace = 1.0  # < 1 = nhanh hon (chuong 1)
        self.wide = pygame.Surface((OUT_VW * OUT_ZOOM, OUT_VH * OUT_ZOOM))
        self.mouse = (W // 2, H // 2)
        self.mouse_held = False
        self.mouse_pressed = False
        self.mouse_released = False
        self.reset()
        # vao thang 1 canh: THE_TICKET.exe --chuong 2 --canh 4
        if "--canh" in sys.argv:
            try:
                n = int(sys.argv[sys.argv.index("--canh") + 1])
                ch = 0
                if "--chuong" in sys.argv:
                    ch = clamp(int(sys.argv[sys.argv.index("--chuong") + 1]) - 1, 0, last_chapter())
                self.start_scene(clamp(n - 1, 0, len(CHAPTERS[ch][2]) - 1), ch)
            except (ValueError, IndexError):
                pass

    def reset(self):
        self.pace = 1.0
        self.auto_talk = False
        self.grey = 0.0
        self.stamp = ""
        self.state = "title"
        self.scene = Title(self)
        self.dialog = None
        self.hint = ""
        self.caption = None
        self.minigame = None
        self.choice = None
        self.choice_result = 0
        self.fade_a = 1.0
        self.fade_col = (0, 0, 0)
        self.closeup = None
        self.menu = None
        self.scene_no = None
        self.audio.stop(CH_PHONE, 100)
        self.audio.stop(CH_ENGINE, 100)
        self.script = self.title_script()
        self.audio.loop(CH_AMB, "rain", 0.35, 1500)
        self.audio.loop(CH_MUSIC, "music", 0.55, 2000)

    # ---- tien ich cho kich ban (generator)
    def wait(self, t):
        t *= self.pace
        while t > 0:
            t -= self.dt
            yield

    def fade(self, to, dur):
        dur *= self.pace
        start = self.fade_a
        e = 0.0
        while e < dur:
            e += self.dt
            self.fade_a = lerp(start, to, min(1.0, e / dur))
            yield
        self.fade_a = to

    def say(self, name, text, thought=False):
        if "Ha ha" in text:
            self.audio.play("laugh", 0.45)
        self.dialog = Dialog(name, text, thought, self.audio, 42.0 / self.pace, self.auto_talk)
        while not self.dialog.done:
            yield
        self.dialog = None
        yield

    def choose(self, prompt, options):
        self.choice = {"prompt": prompt, "opts": options, "idx": 0, "age": 0.0}
        while True:
            ch = self.choice
            ch["age"] += self.dt
            if self.nav:
                ch["idx"] = (ch["idx"] + self.nav) % len(options)
                self.audio.play("blip")
            if self.confirm and ch["age"] > 0.25:
                break
            yield
        self.audio.play("ok", 0.4)
        self.choice_result = self.choice["idx"]
        self.choice = None
        yield

    def show_closeup(self, img, dur=0.7):
        e = 0.0
        while e < dur:
            e += self.dt
            self.closeup = (img, min(1.0, e / dur))
            yield
        self.closeup = (img, 1.0)

    def hide_closeup(self, dur=0.5):
        if not self.closeup:
            return
        img = self.closeup[0]
        e = 0.0
        while e < dur:
            e += self.dt
            self.closeup = (img, max(0.0, 1 - e / dur))
            yield
        self.closeup = None

    def give(self, name):
        """Nho lai mot ky niem: hien thong bao, luu de ket game liet ke."""
        if name not in self.memories:
            self.memories.append(name)
            self.toast = [name, 3.0]
            self.audio.play("ok", 0.3)

    def think(self, text):
        return self.say("", text, thought=True)

    def walk(self, actor, x, speed=34):
        speed /= self.pace
        actor.state = "walk"
        actor.facing = 1 if x > actor.x else -1
        while abs(actor.x - x) > 0.5:
            step = speed * self.dt
            if abs(x - actor.x) <= step:
                actor.x = x
            else:
                actor.x += step * actor.facing
            yield
        actor.state = "idle"

    def control(self, actor, xmin, xmax, until, speed=40):
        speed /= self.pace
        while True:
            k = self.keys
            dx = 0
            if k is not None:
                dx = int(k[pygame.K_RIGHT] or k[pygame.K_d]) - int(k[pygame.K_LEFT] or k[pygame.K_a])
            if dx:
                actor.state = "walk"
                actor.facing = dx
                actor.x = clamp(actor.x + dx * speed * self.dt, xmin, xmax)
            else:
                actor.state = "idle"
            if until():
                actor.state = "idle"
                return
            yield

    def show_caption(self, text, sub, dur):
        self.caption = [text, sub, 0.0]
        e = 0.0
        while e < dur:
            e += self.dt
            self.caption[2] = min(1.0, e / 0.6, (dur - e) / 0.6)
            yield
        self.caption = None

    # ---- kich ban
    def title_script(self):
        yield from self.fade(0, 1.5)
        main_idx = 0
        while True:
            saved = load_progress()
            items = [("start", "Bắt đầu")]
            if saved:
                items.append(("continue", "Tiếp tục · Chương %d · %s" % (saved[0] + 1, CHAPTERS[saved[0]][2][saved[1]][1])))
            items.append(("chapters", "Chọn chương"))
            items.append(("donate", "Ủng hộ tôi"))
            self.menu = {"kind": "main", "items": items, "idx": main_idx}
            act = yield from self.run_menu()
            if act == "donate":
                main_idx = len(items) - 1  # quay lai van dung o muc Ung ho
                self.menu = {"kind": "donate", "items": [("back", "")], "idx": 0}
                yield from self.run_menu()
                continue
            main_idx = 0
            if act == "start":
                start = (0, 0)
            elif act == "continue":
                start = saved
            else:
                start = None
                while start is None:
                    ch_items = [(i if c[2] else None, c[0], c[1]) for i, c in enumerate(CHAPTERS)]
                    self.menu = {"kind": "chapters", "items": ch_items, "idx": 0,
                                 "title": "Chọn chương"}
                    ci = yield from self.run_menu()
                    if ci is None:
                        break
                    sc_items = [((ci, i), c[1], c[2]) for i, c in enumerate(CHAPTERS[ci][2])]
                    self.menu = {"kind": "scenes", "items": sc_items, "idx": 0,
                                 "title": CHAPTERS[ci][0]}
                    start = yield from self.run_menu()
                if start is None:
                    continue
            break
        self.menu = None
        self.audio.play("blip")
        self.state = "play"
        self.audio.stop(CH_MUSIC, 1500)
        self.audio.stop(CH_AMB, 1500)
        yield from self.fade(1, 1.2)
        self.script = self.play_from(*start)
        yield

    def run_menu(self):
        """Tra ve muc duoc chon, hoac None neu bam Esc."""
        self.back = False
        yield  # bo qua phim cua khung hinh truoc
        while True:
            m = self.menu
            if self.nav:
                m["idx"] = (m["idx"] + self.nav) % len(m["items"])
                self.audio.play("blip", 0.5)
            if self.back:
                self.back = False
                return None
            if self.confirm:
                val = m["items"][m["idx"]][0]
                if val is None:  # chuong chua viet
                    self.audio.play("click", 0.6)
                else:
                    self.audio.play("ok", 0.4)
                    return val
            yield

    def start_scene(self, i, ch=0):
        self.state = "play"
        self.menu = None
        self.fade_a = 1.0
        self.audio.stop_all(300)
        self.script = self.play_from(ch, i)

    def play_from(self, ch, start):
        """Choi lan luot tu (chuong, canh) toi het cac chuong da viet, roi man hinh ket."""
        if ch == 0 and start == 0:
            self.memories = []
        for c in range(ch, last_chapter() + 1):
            name, _, scenes = CHAPTERS[c]
            first = start if c == ch else 0
            self.chapter_no = c
            self.pace = 0.6 if c == 0 else 1.0
            if first == 0:
                head, sub = name.split(" · ")
                if c == 1:  # chuong 2 noi tiep anh sang loa trang
                    self.fade_col = (255, 250, 236)
                    self.fade_a = 1.0
                yield from self.wait(0.6)
                yield from self.show_caption(head, sub, 3.0)
            for i in range(first, len(scenes)):
                self.scene_no = i
                save_progress(c, i)
                if not (c == 1 and i == 0):
                    self.fade_a = 1.0
                yield from getattr(self, scenes[i][0])()
        self.scene_no = None
        self.end_chapter = last_chapter()
        save_progress(0, 0)
        yield from self.ending()

    def canh1_van_phong(self):
        """Chuong 1, canh 1 - Van phong: dong nghiep ve, server sap, OT toi 23:00."""
        o = Office(self)
        self.scene = o
        yield from self.wait(0.5)
        yield from self.show_caption("Chiều thứ Sáu, trước kỳ nghỉ lễ", "17:30", 2.0)
        self.audio.loop(CH_MUSIC, "music", 0.45, 2500)
        yield from self.fade(0, 1.6)
        yield from self.wait(1.2)
        # --- dong nghiep ra ve
        o.lan.state = "idle"
        o.lan.facing = 1
        yield from self.wait(0.5)
        yield from self.say("Chị Lan", "Chị về trước nha. Có hộp bánh trên bàn em đó. Lễ vui vẻ nha!")
        o.mon_on[0] = False
        yield from self.walk(o.lan, 17, 32)
        o.door_t = 0.7
        self.audio.play("door", 0.6)
        o.lan.visible = False
        yield from self.wait(0.9)
        o.tuan.state = "idle"
        o.tuan.facing = 1
        yield from self.wait(0.4)
        yield from self.say("Tuấn", "Về quê ăn cho đã nha. Tui đi đây!")
        o.mon_on[1] = False
        yield from self.walk(o.tuan, 17, 38)
        o.door_t = 0.7
        self.audio.play("door", 0.6)
        o.tuan.visible = False
        yield from self.wait(1.4)
        yield from self.think("Văn phòng im hẳn. Xe chạy lúc sáu giờ rưỡi. Vẫn kịp.")
        yield from self.think("Lâu lắm rồi mới được về...")
        yield from self.wait(1.0)
        # --- su co
        o.clock_run = False
        o.alarm = True
        self.audio.stop(CH_MUSIC, 300)
        self.audio.play("alarm", 0.8)
        o.me.state = "sit"
        yield from self.wait(1.6)
        self.audio.play("buzz", 0.8)
        yield from self.wait(0.9)
        o.me.set_expr("surprise")
        yield from self.say("Sếp (tin nhắn)", "Em ơi, server bên khách sập rồi. Em ở lại xử lý gấp giúp anh nha. Khách đang gọi liên tục.")
        o.me.set_expr("sad")
        yield from self.think("Sáu giờ rưỡi...")
        yield from self.say("Tôi", "Dạ. Em xem liền.")
        # --- mini game
        o.me.state = "type"
        self.minigame = Minigame(self, o)
        self.hint = "Nhấn SPACE liên tục để sửa server"
        called = False
        while not self.minigame.done:
            self.minigame.update(self.dt)
            if not called and self.minigame.p > 0.45:
                called = True
                keep = self.hint
                self.hint = ""
                self.audio.loop(CH_PHONE, "ringtone", 0.55, 10)
                yield from self.say("Điện thoại", "Mẹ đang gọi...")
                yield from self.think("Để lát gọi lại.")
                self.audio.stop(CH_PHONE, 80)
                self.hint = keep
            yield
        self.hint = ""
        o.alarm = False
        o.fixed = True
        self.audio.play("ok", 0.8)
        o.me.state = "sit"
        yield from self.wait(1.6)
        self.minigame = None
        yield from self.wait(0.6)
        yield from self.think("Mười một giờ đêm. Chuyến xe về nhà đã chạy từ lâu.")
        self.audio.loop(CH_MUSIC, "music", 0.4, 3000)
        o.fixed = False
        o.mon_on[2] = False
        o.me.state = "idle"
        o.me.facing = -1
        o.me.x -= 6
        yield from self.wait(0.5)
        self.hint = "← →  Di chuyển      Đi ra cửa"
        yield from self.control(o.me, 14, 250, lambda: o.me.x <= 18)
        self.hint = ""
        o.door_t = 2.0
        self.audio.play("door", 0.6)
        o.me.visible = False
        self.audio.stop(CH_MUSIC, 1500)
        yield from self.fade(1, 1.4)
        yield

    def canh2_tram_dem(self):
        """Chuong 1, canh 2 - Tram xe 11:11: di toi tram, chuyen bus cuoi toi."""
        s = Street(self)
        self.scene = s
        self.audio.loop(CH_AMB, "rain", 0.4, 1500)
        yield from self.wait(0.4)
        yield from self.fade(0, 1.5)
        self.hint = "← →  Di chuyển      Đi tới trạm xe buýt"
        yield from self.control(s.me, -8, 250, lambda: s.me.x >= 222)
        self.hint = ""
        s.me.facing = 1
        yield from self.wait(0.6)
        s.me.set_expr("sad")
        yield from self.think("Trạm vắng. Chuyến cuối.")
        s.clock_rate = 1 / 0.45
        while s.minutes < 23 * 60 + 11:
            yield
        yield from self.wait(0.8)
        # xe den
        self.audio.loop(CH_ENGINE, "engine", 0.0, 10)
        s.bus_x = 360.0
        start, end = 360.0, 200.0
        e, dur = 0.0, 2.6
        while e < dur:
            e += self.dt
            k = min(1.0, e / dur)
            s.bus_x = lerp(start, end, 1 - (1 - k) ** 2.4)
            self.audio.volume(CH_ENGINE, 0.2 + 0.5 * k)
            yield
        self.audio.play("hiss", 0.6)
        self.audio.volume(CH_ENGINE, 0.4)
        yield from self.wait(0.8)
        s.door_open = True
        self.audio.play("door", 0.5)
        yield from self.wait(0.6)
        yield from self.walk(s.me, s.bus_x + 20, 30)
        s.me.visible = False
        yield from self.wait(0.8)
        s.door_open = False
        self.audio.play("hiss", 0.5)
        yield from self.wait(0.8)
        start = s.bus_x
        e = 0.0
        while e < 2.2:
            e += self.dt
            s.bus_x = start - 260 * (e / 2.2) ** 2
            self.audio.volume(CH_ENGINE, 0.7 * max(0.0, 1 - e / 2.2))
            yield
        self.audio.stop(CH_ENGINE, 500)
        yield from self.wait(0.8)
        yield from self.fade(1, 1.4)
        yield

    def canh3_bus_dem(self):
        """Chuong 1, canh 3 - Chuyen bus dem: ngu gat, nhuong ghe, ong lao dua ve."""
        b = BusInterior(self)
        self.scene = b
        b.add_passenger(3, 0, state="sleep")
        b.add_passenger(7, 1)
        b.door_open = True
        b.me.x = BUS_DOOR
        self.audio.ensure(CH_AMB, "rain", 0.18)
        self.audio.loop(CH_ENGINE, "engine", 0.22, 800)
        yield from self.wait(0.4)
        yield from self.fade(0, 1.2)
        yield from self.walk(b.me, BUS_DOOR + 10, 26)
        b.door_open = False
        self.audio.play("hiss", 0.45)
        yield from self.wait(0.5)
        b.target_speed = 75
        self.hint = "← →  Di chuyển      Enter: Ngồi xuống"
        b.show_seat_hint = True
        yield from self.control(b.me, BUS_DOOR, BUS_SEATS[-1] + 4,
                                lambda: self.confirm and b.near_seat() is not None)
        seat = b.near_seat()
        b.show_seat_hint = False
        self.hint = ""
        b.me_seat = seat
        b.me.x = BUS_SEATS[seat]
        b.me.facing = -1
        b.me.state = "sit"
        self.audio.loop(CH_MUSIC, "music", 0.32, 3000)
        yield from self.wait(0.8)
        yield from self.think("Chợp mắt một chút thôi...")
        b.me.state = "sleep"
        e = 0.0
        while e < 1.6:
            e += self.dt
            b.sleep = min(1.0, e / 1.6)
            yield
        # --- vai tram sau: xe kin cho
        yield from self.show_caption("Vài trạm sau...", "", 1.6)
        k = 2
        for i in range(len(BUS_SEATS)):
            if i not in b.seated and i != seat:
                b.add_passenger(i, k, state="sleep" if k % 3 == 0 else "sit")
                k += 1
        b.phone_idx = seat + 1 if seat + 1 < len(BUS_SEATS) else seat - 1
        b.seated[b.phone_idx].state = "sit"
        old = Actor(BUS_SEATS[seat] - 12, PAL_OLD, facing=1, head=HEAD_OLD)
        other = Actor(BUS_SEATS[seat] + (34 if seat < 5 else -40), PASSENGERS[4][0], facing=-1)
        b.standing = [old, other]
        self.audio.loop(CH_PHONE, "phone", 0.0, 10)
        e = 0.0
        while e < 1.0:
            e += self.dt
            self.audio.volume(CH_PHONE, 0.75 * e / 1.0)
            yield
        b.me.state = "sit"
        e = 0.0
        while e < 0.5:
            e += self.dt
            b.sleep = max(0.0, 1 - e / 0.5)
            yield
        b.sleep = 0.0
        b.me.set_expr("surprise")
        yield from self.think("...! Ai mở video to vậy trời...")
        yield from self.think("Xe kín chỗ từ lúc nào rồi. Ông cụ kia... đứng nãy giờ sao?")
        yield from self.choose("Mình mệt rã rời. Nhưng ông cụ đứng không vững...",
                               ["Nhường ghế", "Nhắm mắt ngủ tiếp"])
        if self.choice_result == 1:
            b.me.state = "sleep"
            e = 0.0
            while e < 1.2:
                e += self.dt
                b.sleep = min(0.55, e / 1.2 * 0.55)
                yield
            yield from self.think("Không ngủ được.")
            e = 0.0
            while e < 0.5:
                e += self.dt
                b.sleep = max(0.0, 0.55 - e)
                yield
            b.sleep = 0.0
            b.me.state = "sit"
        b.me.set_expr("sad")
        yield from self.think("Dù gì cũng còn vài trạm là tới nhà mình rồi.")
        # nhuong ghe
        b.me.state = "idle"
        b.me_seat = None
        b.me.facing = 1
        yield from self.walk(b.me, BUS_SEATS[seat] + 10, 24)
        b.me.facing = -1
        b.standing.append(b.me)
        yield from self.say("Tôi", "Ông ơi, ông ngồi đi ạ.")
        old.set_expr("smile")
        yield from self.say("Ông lão", "Cảm ơn cháu.")
        b.standing.remove(old)
        yield from self.walk(old, BUS_SEATS[seat], 14)
        old.facing = -1
        old.state = "sit"
        b.seated[seat] = old
        yield from self.wait(0.6)
        e = 0.0
        while e < 1.0:
            e += self.dt
            self.audio.volume(CH_PHONE, 0.75 * max(0.0, 1 - e / 1.0))
            yield
        self.audio.stop(CH_PHONE, 200)
        b.phone_idx = None
        yield from self.say("Ông lão", "Đi làm về khuya vậy cháu?")
        yield from self.say("Tôi", "Dạ. Server công ty bị lỗi, cháu ở lại sửa tới giờ.")
        yield from self.say("Ông lão", "Vậy là lễ này không về quê được rồi.")
        b.me.set_expr("surprise")
        yield from self.think("Sao ông biết mình định về quê?")
        yield from self.wait(1.2)
        # --- toi tram
        self.audio.play("ding", 0.7)
        yield from self.wait(0.6)
        yield from self.say("Loa xe buýt", "Trạm kế tiếp: Hẻm 42.")
        b.target_speed = 0
        while b.speed > 1:
            self.audio.volume(CH_ENGINE, 0.12 + 0.1 * b.speed / 75)
            yield
        self.audio.play("hiss", 0.5)
        b.standing.remove(b.me)
        yield from self.walk(b.me, BUS_SEATS[seat] - 9, 24)
        yield from self.say("Ông lão", "Khoan đã, cháu.")
        b.me.facing = 1
        yield from self.wait(0.4)
        self.audio.play("ok", 0.35)
        e = 0.0
        while e < 0.8:
            e += self.dt
            b.closeup = min(1.0, e / 0.8)
            yield
        yield from self.say("Ông lão", "Sáng mai cháu đi sớm, cứ dùng tấm vé này.")
        yield from self.think("Sao ông biết? Mà vé xe buýt chỉ dùng được trong ngày thôi mà...")
        e = 0.0
        while e < 0.6:
            e += self.dt
            b.closeup = max(0.0, 1 - e / 0.6)
            yield
        b.closeup = 0.0
        b.me.set_expr("sad")
        yield from self.think("Mệt quá. Không nghĩ nổi nữa.")
        b.door_open = True
        self.audio.play("door", 0.5)
        yield from self.walk(b.me, BUS_DOOR, 28)
        b.me.visible = False
        yield from self.wait(0.8)
        b.door_open = False
        self.audio.play("hiss", 0.45)
        yield from self.wait(0.6)
        b.target_speed = 75
        self.audio.volume(CH_ENGINE, 0.25)
        yield from self.wait(2.5)
        self.audio.stop(CH_ENGINE, 2000)
        self.audio.stop(CH_AMB, 2500)
        self.audio.stop(CH_MUSIC, 2500)
        yield from self.fade(1, 2.0)
        yield

    def canh4_phong_tro(self):
        """Chuong 1, canh 4 - Phong tro: treo ao, luot anh cu, ngu quen bao thuc."""
        r = Room(self)
        self.scene = r
        yield from self.wait(0.5)
        yield from self.show_caption("Phòng trọ", "23:52", 1.6)
        self.audio.loop(CH_AMB, "rain", 0.22, 1500)
        yield from self.fade(0, 1.4)
        yield from self.wait(0.6)
        r.door_t = 1.2
        self.audio.play("door", 0.6)
        r.me.visible = True
        r.me.x = 54
        yield from self.walk(r.me, 64, 22)
        self.audio.play("click", 0.8)
        r.lights = True
        yield from self.wait(0.5)
        yield from self.walk(r.me, 73, 22)
        r.me.facing = -1
        r.jacket = True
        self.audio.play("blip", 0.6)
        yield from self.think("Tấm vé ông cụ đưa... vẫn nằm trong túi áo.")
        r.me.facing = 1
        self.audio.loop(CH_MUSIC, "music", 0.3, 3000)
        self.hint = "← →  Di chuyển      Enter: Xem / Nằm xuống"
        while True:
            k = self.keys
            dx = 0
            if k is not None:
                dx = int(k[pygame.K_RIGHT] or k[pygame.K_d]) - int(k[pygame.K_LEFT] or k[pygame.K_a])
            if dx:
                r.me.state = "walk"
                r.me.facing = dx
                r.me.x = clamp(r.me.x + dx * 62 * self.dt, 52, 250)
            else:
                r.me.state = "idle"
            it = r.near_item()
            r.marker = it[0] if it else None
            if it and self.confirm:
                r.me.state = "idle"
                if it[1] == "bed":
                    break
                self.hint = ""
                for line in it[2]:
                    yield from self.think(line)
                self.hint = "← →  Di chuyển      Enter: Xem / Nằm xuống"
            yield
        self.hint = ""
        r.marker = None
        r.me.visible = False
        r.lying = True
        self.audio.play("door", 0.25)
        yield from self.wait(0.8)
        self.audio.play("click", 0.8)
        r.lights = False
        yield from self.wait(1.0)
        e = 0.0
        while e < 0.7:
            e += self.dt
            r.phone_t = min(1.0, e / 0.7)
            yield
        r.phone_t = 1.0
        yield from self.think("Ơ... ảnh cũ.")
        lines = [
            ["Mâm cơm nhà mình. Tóc ba còn đen."],
            ["Thằng Tèo, thằng Hùng, con Na... giờ tụi nó ở đâu rồi ta."],
            ["Cái khăn quàng đỏ lúc nào cũng thắt lệch."],
            ["Haha... đêm đó kể chuyện ma, hai đứa trùm mền tới sáng."],
        ]
        for i, ls in enumerate(lines):
            for ln in ls:
                yield from self.think(ln)
            if i + 1 < len(lines):
                self.hint = "→  Lướt ảnh tiếp"
                while not (self.nav > 0 or self.confirm):
                    yield
                self.hint = ""
                self.audio.play("blip", 0.6)
                e = 0.0
                while e < 0.35:
                    e += self.dt
                    r.swipe = min(1.0, e / 0.35)
                    yield
                r.photo += 1
                r.swipe = 0.0
                yield from self.wait(0.4)
        yield from self.wait(0.6)
        yield from self.think("Lúc nhỏ mình chỉ sợ ma.")
        yield from self.think("Còn giờ... tiền điện. Tiền nước. Tiền nhà. Thuế... Haha.")
        yield from self.wait(1.0)
        r.screen = "alarm"
        self.audio.play("blip", 0.6)
        yield from self.wait(0.6)
        yield from self.think("Phải đổi báo thức qua năm giờ... Lát nữa...")
        e = 0.0
        while e < 2.0:
            e += self.dt
            k = min(1.0, e / 2.0)
            r.sleep = k
            r.phone_t = max(0.0, 1 - k * 1.6)
            yield
        r.phone_t = 0.0
        yield from self.wait(1.5)
        self.audio.stop(CH_AMB, 2500)
        self.audio.stop(CH_MUSIC, 2500)
        yield from self.fade(1, 2.0)
        yield

    def canh5_bao_thuc(self):
        """Chuong 1, canh 5 - Bao thuc 06:30: hot hoang gom do, bo quen cai bop."""
        rm = Room(self)
        rm.morning = True
        rm.lying = True
        rm.jacket = True
        self.scene = rm
        yield from self.wait(1.0)
        self.audio.loop(CH_PHONE, "ringtone", 0.7, 10)
        yield from self.show_caption("Sáng thứ Bảy", "06:30", 1.6)
        self.audio.loop(CH_AMB, "birds", 0.5, 1500)
        yield from self.fade(0, 0.8)
        self.hint = "Nhấn Enter để tắt báo thức"
        while not self.confirm:
            yield
        self.hint = ""
        self.audio.stop(CH_PHONE, 80)
        yield from self.wait(0.6)
        rm.screen = "alarm"
        e = 0.0
        while e < 0.5:
            e += self.dt
            rm.phone_t = min(1.0, e / 0.5)
            yield
        yield from self.wait(0.8)
        yield from self.say("Tôi", "SÁU GIỜ RƯỠI?!")
        yield from self.think("Quên đổi báo thức!")
        e = 0.0
        while e < 0.4:
            e += self.dt
            rm.phone_t = max(0.0, 1 - e / 0.4)
            yield
        rm.phone_t = 0.0
        rm.lying = False
        rm.me.visible = True
        rm.me.set_expr("surprise")
        rm.me.x = 238
        rm.me.facing = -1
        set_outfit(rm.me, False, False)
        # --- gom do
        rm.rush = {"jacket": False, "keys": False, "bag": False}
        rm.rush_items = [("jacket", "Áo khoác"), ("keys", "Chìa khoá"), ("bag", "Balo")]
        rm.clock = 6 * 60 + 31
        spots = {"jacket": 73, "keys": 88, "bag": 201}
        self.audio.loop(CH_MUSIC, "music", 0.25, 1000)
        self.hint = "← →  Chạy      Enter: Lấy đồ      Gom đủ rồi ra cửa!"
        warned = False
        while True:
            rm.clock += self.dt / 2.0
            k = self.keys
            dx = 0
            if k is not None:
                dx = int(k[pygame.K_RIGHT] or k[pygame.K_d]) - int(k[pygame.K_LEFT] or k[pygame.K_a])
            all_done = all(rm.rush.values())
            if dx:
                rm.me.state = "walk"
                rm.me.facing = dx
                rm.me.x = clamp(rm.me.x + dx * 84 * self.dt, 50 if all_done else 60, 250)
            else:
                rm.me.state = "idle"
            near = None
            for key, x in spots.items():
                if not rm.rush[key] and abs(rm.me.x - x) < 8:
                    near = key
            rm.marker = spots[near] if near else None
            if near and self.confirm:
                rm.rush[near] = True
                self.audio.play("ok", 0.4)
                if near == "jacket":
                    rm.jacket = False
                elif near == "keys":
                    rm.has_keys = True
                elif near == "bag":
                    rm.has_bag = True
                set_outfit(rm.me, rm.rush["jacket"], rm.rush["bag"])
            if not all_done and rm.me.x <= 61 and dx < 0 and not warned:
                warned = True
                self.hint = ""
                yield from self.think("Khoan, còn thiếu đồ!")
                self.hint = "← →  Chạy      Enter: Lấy đồ      Gom đủ rồi ra cửa!"
            if all_done and rm.me.x <= 52:
                break
            yield
        self.hint = ""
        rm.marker = None
        rm.me.state = "idle"
        rm.door_t = 1.5
        self.audio.play("door", 0.7)
        rm.me.visible = False
        yield from self.wait(0.6)
        self.audio.stop(CH_MUSIC, 800)
        yield from self.fade(1, 1.0)
        rm.rush = None
        yield

    def canh6_tram_sang(self):
        """Chuong 1, canh 6 - Tram xe buoi sang: quen tien, tam ve nhau, banh mi."""
        s = Street(self)
        s.morning = True
        s.minutes = 6 * 60 + 41
        s.clock_cap = 6 * 60 + 46
        s.clock_rate = 1 / 2.0
        set_outfit(s.me, True, True)
        self.scene = s
        self.audio.ensure(CH_AMB, "birds", 0.5)
        yield from self.wait(0.3)
        yield from self.fade(0, 1.0)
        self.hint = "← →  Chạy tới trạm xe buýt"
        yield from self.control(s.me, -8, 250, lambda: s.me.x >= 222, speed=54)
        self.hint = ""
        s.me.facing = 1
        yield from self.think("Đường vắng hoe.")
        s.clock_rate = 1 / 0.3
        while s.minutes < 6 * 60 + 46:
            yield
        yield from self.wait(0.5)
        self.audio.loop(CH_ENGINE, "engine", 0.0, 10)
        s.bus_x = 360.0
        e, dur = 0.0, 2.4
        while e < dur:
            e += self.dt
            k = min(1.0, e / dur)
            s.bus_x = lerp(360.0, 200.0, 1 - (1 - k) ** 2.4)
            self.audio.volume(CH_ENGINE, 0.2 + 0.4 * k)
            yield
        self.audio.play("hiss", 0.5)
        self.audio.volume(CH_ENGINE, 0.3)
        yield from self.wait(0.6)
        s.door_open = True
        self.audio.play("door", 0.5)
        yield from self.walk(s.me, s.bus_x + 24, 34)
        s.me.facing = -1
        s.me.set_expr("surprise")
        yield from self.think("Cái bóp đâu rồi?!")
        yield from self.say("Tài xế", "Quên mang tiền hả cháu? Thử lục túi áo khoác coi.")
        self.audio.play("blip", 0.6)
        yield from self.show_closeup(make_crumpled_ticket())
        yield from self.think("Một tờ giấy nhăn nhúm. Tấm vé.")
        s.me.set_expr("neutral")
        yield from self.say("Tài xế", "Đó, có vé rồi còn gì. Đưa đây chú giữ cho.")
        yield from self.hide_closeup()
        yield from self.say("Tài xế", "Mà chưa ăn sáng phải không?")
        yield from self.think("Đúng thật. Mà cả tuần nay cũng vậy.")
        yield from self.show_closeup(make_banhmi())
        s.me.set_expr("smile")
        yield from self.say("Tài xế", "Nè, ổ bánh mì. Ăn đi rồi mình bắt đầu “Chuyến đi”.")
        yield from self.hide_closeup()
        s.me.visible = False
        yield from self.wait(0.6)
        s.door_open = False
        self.audio.play("hiss", 0.45)
        yield from self.wait(0.6)
        e = 0.0
        start = s.bus_x
        while e < 1.8:
            e += self.dt
            s.bus_x = start - 260 * (e / 1.8) ** 2
            yield
        yield from self.fade(1, 1.2)
        yield

    def canh7_chuyen_di(self):
        """Chuong 1, canh 7 - Chuyen di: xe trong, an banh mi, 'Toi noi roi', loa trang."""
        b = BusInterior(self)
        b.morning = True
        b.driver = Actor(BUS_X0 + 17, PAL_DRIVER_OLD, facing=-1, state="sit", expr="smile")
        set_outfit(b.me, True, True)
        b.me.x = BUS_DOOR + 10
        b.allowed = [len(BUS_SEATS) - 2]
        self.scene = b
        b.target_speed = 70
        b.speed = 20
        self.audio.ensure(CH_AMB, "birds", 0.5)
        self.audio.ensure(CH_ENGINE, "engine", 0.2)
        yield from self.wait(0.3)
        yield from self.fade(0, 1.2)
        yield from self.think("Xe trống trơn.")
        self.hint = "← →  Di chuyển      Enter: Ngồi chỗ quen"
        b.show_seat_hint = True
        yield from self.control(b.me, BUS_DOOR, BUS_SEATS[-1] + 4,
                                lambda: self.confirm and b.near_seat() is not None)
        seat = b.near_seat()
        b.show_seat_hint = False
        self.hint = ""
        b.me_seat = seat
        b.me.x = BUS_SEATS[seat]
        b.me.facing = -1
        b.me.state = "sit"
        b.me.set_expr("smile")
        yield from self.think("Ghế cạnh cửa sổ, hàng thứ hai từ dưới lên, dãy phải. Chỗ quen.")
        self.audio.loop(CH_MUSIC, "music", 0.35, 3000)
        # --- an banh mi
        bm = make_banhmi()
        bites = 3
        yield from self.show_closeup(bm, 0.5)
        self.hint = "Nhấn Enter để ăn bánh mì"
        lines = {2: "Giòn.", 1: "Lâu lắm rồi mới ăn sáng đàng hoàng."}
        while bites > 0:
            if self.confirm:
                bites -= 1
                self.audio.play("bite", 0.8)
                w = int(bm.get_width() * bites / 3)
                cut = pygame.Surface(bm.get_size(), pygame.SRCALPHA)
                cut.blit(bm, (0, 0), (0, 0, w, bm.get_height()))
                self.closeup = (cut, 1.0)
                if bites in lines:
                    self.hint = ""
                    yield from self.think(lines[bites])
                    self.hint = "Nhấn Enter để ăn bánh mì"
            yield
        self.hint = ""
        yield from self.hide_closeup(0.4)
        yield from self.wait(0.8)
        yield from self.think("Ấm quá...")
        b.me.state = "sleep"
        e = 0.0
        while e < 1.6:
            e += self.dt
            b.sleep = min(1.0, e / 1.6)
            yield
        yield from self.wait(1.5)
        # tai xe di xuong lay day
        b.target_speed = 0
        b.speed = 0
        self.audio.volume(CH_ENGINE, 0.08)
        drv = b.driver
        drv.state = "idle"
        drv.facing = 1
        drv.x = BUS_SEATS[seat] - 12
        e = 0.0
        while e < 1.0:
            e += self.dt
            b.sleep = max(0.45, 1 - e)
            yield
        yield from self.say("Tài xế", "Cháu ơi... Tới nơi rồi.")
        e = 0.0
        while e < 0.6:
            e += self.dt
            b.sleep = max(0.0, 0.45 - e)
            yield
        b.sleep = 0.0
        b.me.state = "idle"
        b.me_seat = None
        b.me.facing = -1
        b.door_open = True
        self.audio.play("door", 0.5)
        drv.x = BUS_SEATS[seat] - 22
        yield from self.wait(0.4)
        self.fade_col = (255, 250, 236)
        start_x = b.me.x
        e = 0.0
        b.me.state = "walk"
        while b.me.x > BUS_DOOR:
            b.me.x -= 22 * self.dt
            e += self.dt
            k = 1 - (b.me.x - BUS_DOOR) / max(1.0, start_x - BUS_DOOR)
            self.fade_a = clamp(k ** 2 * 0.85, 0, 1)
            yield
        b.me.visible = False
        self.audio.stop(CH_ENGINE, 1500)
        self.audio.stop(CH_AMB, 2500)
        yield from self.fade(1, 1.2)
        yield from self.think("Chói quá.")
        yield from self.wait(1.0)
        self.audio.stop(CH_MUSIC, 2000)
        yield

    # ---- chuong 2: ve lang
    def play_mini(self, mg, back):
        """Chay 1 minigame roi tra lai dia diem 'back'."""
        yield from self.fade(1, 0.6)
        self.scene = mg
        yield from self.fade(0, 0.6)
        while not mg.done:
            yield
        yield from self.fade(1, 0.7)
        self.scene = back
        yield from self.fade(0, 0.7)

    def explore(self, v, exit_x, spots=(), xmin=12, speed=44):
        """Di bo tu do; spots = [(x, nhan, ham kich ban)]. Sang phai toi exit_x la xong."""
        seen = set()
        me = v.me
        while True:
            near = None
            for i, s in enumerate(spots):
                if i not in seen and abs(me.x - s[0]) < 15:
                    near = i
            self.hint = "← →  Đi"
            if near is not None:
                self.hint += "      Enter: Xem " + spots[near][1]
            k = self.keys
            dx = 0
            if k is not None:
                dx = int(k[pygame.K_RIGHT] or k[pygame.K_d]) - int(k[pygame.K_LEFT] or k[pygame.K_a])
            if dx:
                me.state = "walk"
                me.facing = dx
                me.x = clamp(me.x + dx * speed * self.dt, xmin, exit_x)
            else:
                me.state = "idle"
            if near is not None and self.confirm:
                me.state = "idle"
                self.hint = ""
                seen.add(near)
                yield from spots[near][2]()
                yield
                continue
            if me.x >= exit_x:
                me.state = "idle"
                self.hint = ""
                return
            yield

    def village_audio(self, amb="birds", vol=0.5):
        self.audio.ensure(CH_AMB, amb, vol)
        self.audio.ensure(CH_MUSIC, "village", 0.42)

    def kids_at(self, v, xs, floor=150):
        """Dat dam nho vao dia diem. Tra ve (thang nhoc, cac dua khac)."""
        pals = (PAL_KID_ME, PAL_KID_TEO, PAL_KID_NA, PAL_KID_HUNG)
        out = []
        for i, x in enumerate(xs):
            out.append(v.add(Kid(x, pals[i % 4], facing=-1 if x > v.me.x else 1), floor - (i % 2) * 4))
        return out[0], out[1:]

    def c2_canh1_cong_lang(self):
        """Chuong 2, canh 1 - Cong lang, duong dat: co gi do sai sai."""
        v = Village(self, "gate")
        self.scene = v
        v.me.x = 22
        self.fade_col = (255, 250, 236)
        self.fade_a = 1.0
        self.village_audio()
        yield from self.fade(0, 2.6)
        self.fade_col = (0, 0, 0)
        v.me.set_expr("smile")
        yield from self.think("Cổng làng. Đúng là quê mình.")

        def look_gate():
            v.me.set_expr("neutral")
            yield from self.think("Nhưng có gì đó sai sai.")
        yield from self.explore(v, 306, [(160, "cổng làng", look_gate)])
        yield from self.fade(1, 0.7)
        r = Village(self, "road")
        r.me.x = 14
        self.scene = r
        kid, others = self.kids_at(r, (232, 262, 240, 270))
        for k in [kid] + others:
            k.state = "sit"
        yield from self.fade(0, 0.8)
        r.me.set_expr("surprise")
        yield from self.think("Đường làng gần chục năm trước đã đổ nhựa rồi mà. Sao giờ lại là đường đất?")

        def look_house():
            yield from self.think("Nhà cửa xung quanh cũng cũ hơn nữa.")
        yield from self.explore(r, 208, [(145, "căn nhà cũ", look_house)])
        self.keep_v = r
        yield from self.fade(1, 0.7)

    def road_with_kids(self):
        v = getattr(self, "keep_v", None)
        if v is None:
            v = Village(self, "road")
            kid, others = self.kids_at(v, (232, 262, 240, 270))
            for k in [kid] + others:
                k.state = "sit"
        self.keep_v = None
        v.cam = None
        v.me.x = 208
        v.me.state = "idle"
        v.me.facing = 1
        return v

    def c2_canh2_ban_bi(self):
        """Chuong 2, canh 2 - Dam tre choi ban bi, minigame 1."""
        v = self.road_with_kids()
        self.scene = v
        self.village_audio()
        yield from self.fade(0, 0.7)
        yield from self.think("Một đám nhóc áo ba lỗ, chân tay lấm bùn, tụm quanh vòng tròn vẽ bằng cành cây.")
        yield from self.say("Tôi", "Mấy đứa, đây... là Làng Tre phải không?")
        yield from self.say("Thằng nhóc", "Làng mình chứ làng gì nữa anh?")
        yield from self.say("Tụi nhỏ", "Ha ha ha ha!")
        yield from self.say("Thằng nhóc", "Nè anh, em cho anh mượn. Viên này bắn đã lắm!")
        yield from self.think("Chừng bảy tuổi. Áo thun bạc màu. Đôi dép lê không cùng màu.")
        yield from self.think("Sao thấy quen đến lạ.")
        yield from self.say("Thằng nhóc", "Anh búng sai rồi! Để ngón cái sau viên bi nè.")
        yield from self.say("Tôi", "...Ừ há. Quên mất.")
        mg = MarbleGame(self)
        yield from self.play_mini(mg, v)
        v.me.set_expr("smile")
        yield from self.think("Một nụ cười thật sự. Lâu lắm rồi.")
        yield from self.say("Thằng nhóc", "Anh ở đâu tới vậy? Em chưa thấy anh bao giờ.")
        yield from self.say("Tôi", "Anh ở thành phố về.")
        yield from self.say("Tôi", "Nè, trả em viên bi.")
        yield from self.show_closeup(make_big_marble(), 0.5)
        yield from self.say("Thằng nhóc", "Anh giữ đi. Viên này em quý nhất đó, thằng Hùng đòi đổi nguyên bịch em cũng không đổi.")
        yield from self.hide_closeup(0.4)
        self.give("Viên bi xanh")
        yield from self.say("Hùng", "Thôi nghỉ đi, qua bụi tre chơi!")
        yield from self.say("Thằng nhóc", "Chơi nữa đi! Trời chưa tối mà!")
        yield from self.fade(1, 0.8)

    def c2_canh3_to_lich(self):
        """Chuong 2, canh 3 - Dong ho dung o 7:00, ten cua thang nhoc, to lich 2008."""
        v = Village(self, "xom")
        self.scene = v
        v.me.x = 40
        kid = v.add(Kid(62, PAL_KID_ME, facing=1), 150)
        a = v.add(Kid(150, PAL_KID_TEO, facing=-1), 146)
        b = v.add(Kid(170, PAL_KID_NA, facing=-1), 149)
        self.village_audio()
        yield from self.fade(0, 0.8)
        phone = make_phone_dead()
        yield from self.show_closeup(phone, 0.5)
        v.me.set_expr("surprise")
        yield from self.think("Đồng hồ đứng im ở 7 giờ sáng. Không có sóng.")
        yield from self.hide_closeup(0.4)
        v.followers.append((kid, 22))
        self.hint = ""
        yield from self.walk(v.me, 92, 34)
        yield from self.think("Tèo, Na, Hùng... những cái tên đã bị bỏ quên nhiều năm.")
        v.followers = []
        kid.state = "walk"
        kid.facing = 1
        while kid.x < 118:
            kid.x += 28 * self.dt
            yield
        kid.state = "idle"
        yield from self.think("Thằng nhóc vừa đi vừa đá sỏi.")
        v.me.set_expr("smile")
        yield from self.say("Tôi", "Mà nhóc tên gì ấy nhỉ?")
        kid.facing = -1
        self.audio.play("hiss", 0.35)
        yield from self.say("Thằng nhóc", "Em hả? Em tên...")
        yield from self.wait(0.6)
        v.me.set_expr("surprise")
        yield from self.think("Đó chính là tên mình.")
        yield from self.think("Vết sẹo trên đầu gối. Đôi mắt. Khuôn mặt trong những bức ảnh cũ.")
        yield from self.walk(v.me, 204, 72)
        v.me.facing = 1
        self.audio.stop(CH_MUSIC, 900)
        yield from self.wait(0.4)
        cal = make_calendar()
        yield from self.show_closeup(cal, 0.6)
        yield from self.wait(0.8)
        yield from self.think("Năm 2008.")
        yield from self.wait(0.8)
        yield from self.think("18 năm trước.")
        yield from self.hide_closeup(0.5)
        v.me.facing = -1
        v.cam_focus = 165  # thay ca minh va thang nhoc
        yield from self.say("Thằng nhóc", "Anh ơi! Đi lẹ lên! Anh làm gì mà đứng đó hoài vậy?")
        yield from self.think("Tại sao mình ở đây? Chuyến xe đó là gì? Ông lão kia là ai?")
        v.me.set_expr("wet")
        yield from self.think("Dù sao thì... đã 18 năm rồi mình mới được nhìn thấy lại những người bạn này.")
        self.audio.ensure(CH_MUSIC, "village", 0.42)
        yield from self.fade(1, 0.9)

    def c2_canh4_bui_tre(self):
        """Chuong 2, canh 4 - Bui tre dau lang, minigame tat lon."""
        v = Village(self, "bamboo")
        self.scene = v
        v.me.x = 60
        kid, others = self.kids_at(v, (170, 200, 222, 244))
        self.audio.ensure(CH_AMB, "wind", 0.5)
        self.audio.ensure(CH_MUSIC, "village", 0.42)
        yield from self.fade(0, 0.8)
        v.me.set_expr("smile")
        yield from self.think("\"Căn cứ bí mật\" ngày xưa. Mấy lon sữa bò móp méo.")

        def look_base():
            yield from self.think("Mái lá chuối của căn cứ. Vẫn còn đây.")
            self.give("Căn cứ bí mật")
        yield from self.explore(v, 142, [(92, "gốc tre", look_base)], xmin=30)
        v.me.facing = 1
        yield from self.think("Hồi nhỏ mình làm bay chiếc dép xuống mương ở chính chỗ này. Về bị mẹ mắng.")
        yield from self.say("Thằng nhóc", "Anh tạt thử coi! Ai thua phải đi nhặt dép nha!")
        mg = CanGame(self, PAL_KID_ME)
        yield from self.play_mini(mg, v)
        self.give("Chiếc dép đứt quai")
        yield from self.say("Thằng nhóc", "Sao anh cười mà mắt không cười?")
        yield from self.wait(1.2)
        yield from self.say("Tôi", "...Anh có cười mà.")
        yield from self.say("Thằng nhóc", "Xạo!")
        yield from self.fade(1, 0.8)

    def c2_canh5_tiem_ba_nga(self):
        """Chuong 2, canh 5 - Tiem tap hoa ba Nga."""
        v = Village(self, "shop")
        self.scene = v
        v.me.x = 30
        v.cam = 110.0
        v.add(Actor(204, PAL_BA_NGA, female=True, facing=-1, expr="smile"), 146)
        v.add(Kid(156, PAL_KID_ME, facing=1), 150)
        v.add(Kid(138, PAL_KID_TEO, facing=1), 151)
        v.add(Kid(120, PAL_KID_NA, facing=1), 149)
        self.audio.ensure(CH_MUSIC, "village", 0.34)
        self.audio.stop(CH_AMB, 800)
        yield from self.fade(0, 0.8)
        v.me.set_expr("smile")
        yield from self.think("Mùi bánh kẹo, xà phòng, nhang muỗi. Có 2.000 đồng là đứng lựa cả buổi.")

        def look_case():
            yield from self.think("Kẹo kéo, kẹo me, bánh ống, đồ chơi nhựa rẻ tiền.")
            self.give("Tủ kính đồ chơi")
        yield from self.explore(v, 100, [(78, "tủ kính", look_case)], xmin=26)
        v.cam_focus = 148  # dua khung hinh sang quay ba Nga
        v.me.set_expr("wet")
        yield from self.think("Bà Nga. Tóc mới lấm tấm bạc.")
        yield from self.say("Bà Nga", "Ủa, cậu này ở đâu tới vậy?")
        yield from self.say("Tôi", "Dạ... con ở xa mới về.")
        yield from self.say("Bà Nga", "Về quê chơi thì cứ thoải mái nghen.")
        yield from self.say("Bà Nga", "Nhiêu đây được ba cục thôi.")
        yield from self.say("Thằng nhóc", "Bốn cục đi bà! Bữa trước bà cho con bốn cục mà!")
        yield from self.show_closeup(make_candy(), 0.5)
        self.give("Viên kẹo của bà Nga")
        yield from self.think("Câu đó, chính mình đã từng nói.")
        yield from self.hide_closeup(0.4)
        yield from self.fade(1, 0.8)

    def c2_canh6_xe_ha_cao(self):
        """Chuong 2, canh 6 - Xe ha cao cua ong gia."""
        v = Village(self, "cart")
        self.scene = v
        v.me.x = 24
        old = v.add(Actor(168, PAL_HA_CAO, facing=1, expr="smile"), 150)
        self.audio.ensure(CH_AMB, "birds", 0.45)
        self.audio.ensure(CH_MUSIC, "village", 0.34)
        yield from self.fade(0, 0.8)
        kid = v.add(Kid(44, PAL_KID_ME, facing=1), 150)
        a = v.add(Kid(10, PAL_KID_HUNG, facing=1), 148)
        yield from self.say("Tiếng rao", "Há cảo nóng đây... Há cảo nóng đây...")
        v.followers.append((kid, 18))
        v.followers.append((a, -14))

        def look_fence():
            yield from self.think("Hàng rào này... mình từng trèo qua để trốn ngủ trưa.")
            self.give("Những buổi trốn ngủ trưa")
        yield from self.explore(v, 132, [(96, "hàng rào", look_fence)])
        v.followers = []
        kid.state = a.state = "idle"
        kid.facing = 1
        old.facing = -1
        yield from self.say("Tụi nhỏ", "Tụi con hết tiền rồi ông ơi!")
        yield from self.say("Ông già", "Hết tiền thì đứng đây ngửi cho thơm thôi nghen!")
        yield from self.think("Cái bóp bỏ quên ở nhà trọ rồi.")
        yield from self.say("Thằng nhóc", "Thôi anh ơi. Chiều em về xin mẹ, mai tụi mình ăn!")
        v.me.set_expr("sad")
        yield from self.think("Hồi đó mình chưa từng nghĩ có ngày sẽ không còn được nghe tiếng rao này nữa.")
        yield from self.fade(1, 0.8)

    def c2_canh7_san_dinh(self):
        """Chuong 2, canh 7 - San dat sau dinh, minigame nhay day."""
        v = Village(self, "dinh")
        self.scene = v
        v.me.x = 76
        v.cam_focus = 160
        v.add(Kid(190, PAL_GIRL_THAM, female=True, facing=1), 150)
        v.add(Kid(244, PAL_GIRL_NA, female=True, facing=-1), 150)
        kid = v.add(Kid(100, PAL_KID_ME, facing=1), 150)
        v.add(Kid(122, PAL_KID_TEO, facing=1), 147)
        self.audio.ensure(CH_AMB, "cicada", 0.4)
        self.audio.ensure(CH_MUSIC, "village", 0.42)
        yield from self.fade(0, 0.8)
        
        yield from self.think("Sợi dây thun đủ màu.")

        def look_wall():
            yield from self.think("Phấn vẽ ô lò cò trên tường đình, nguệch ngoạc.")
            self.give("Ô lò cò trên tường")
        yield from self.explore(v, 150, [(66, "bức tường", look_wall)], xmin=56)
        yield from self.say("Thắm", "Anh biết nhảy dây không? Nhảy thử đi!")
        mg = JumpGame(self)
        yield from self.play_mini(mg, v)
        self.give("Sợi dây thun đủ màu")
        v.me.set_expr("smile")
        yield from self.fade(1, 0.8)

    def c2_canh8_cay_trung_ca(self):
        """Chuong 2, canh 8 - Cay trung ca, minigame hung trai."""
        v = Village(self, "tree")
        self.scene = v
        v.me.x = 124
        v.me.facing = 1
        kid = v.add(Kid(150, PAL_KID_ME, facing=1), 150)
        v.add(Kid(238, PAL_KID_NA, facing=-1), 148)
        v.add(Kid(264, PAL_KID_HUNG, facing=-1), 150)
        self.audio.ensure(CH_AMB, "cicada", 0.4)
        self.audio.ensure(CH_MUSIC, "village", 0.42)
        yield from self.fade(0, 0.8)
        yield from self.wait(0.5)
        def look_trunk():
            yield from self.think("Trên thân cây có hai chữ khắc. Tên mình, và tên thằng Tèo.")
            self.give("Tên khắc trên thân cây")
        yield from self.explore(v, 190, [(88, "thân cây", look_trunk)], xmin=64)
        yield from self.say("Thằng nhóc", "Anh đứng dưới hứng nha! Để em rung cành cho!")
        mg = FruitGame(self)
        yield from self.play_mini(mg, v)
        self.give("Trái trứng cá chín")
        for a, _ in v.actors:
            a.state = "sit"
        v.me.state = "sit"
        v.me.facing = -1
        kid.facing = 1
        v.me.set_expr("smile")
        yield from self.think("Một quả trứng cá. Ngọt thanh.")
        yield from self.say("Thằng nhóc", "Anh ơi, sau này em lên thành phố, em có được ăn trứng cá nữa không?")
        yield from self.choose("", ["Chắc là có.", "Anh không biết nữa."])
        if self.choice_result == 0:
            yield from self.say("Tôi", "Chắc là có.")
            yield from self.say("Thằng nhóc", "Vậy tốt quá!")
        else:
            yield from self.say("Tôi", "Anh... không biết nữa.")
            yield from self.say("Thằng nhóc", "Vậy thôi em ăn nhiều nhiều bây giờ luôn!")
        v.me.set_expr("sad")
        yield from self.think("Lớn lên, có những thứ không phải cứ muốn là tìm lại được.")
        v.me.set_expr("wet")
        yield from self.say("Tôi", "Ừ. Bây giờ còn ăn được thì cứ ăn cho đã đi.")
        yield from self.fade(1, 0.8)

    def c2_canh9_con_mua(self):
        """Chuong 2, canh 9 - Con mua chieu: tru mua, gap va dua thuyen, dam tre ve nha."""
        r = Village(self, "road")
        r.storm()
        self.scene = r
        r.me.x = 40
        kid = r.add(Kid(66, PAL_KID_ME, facing=1), 150)
        a = r.add(Kid(90, PAL_KID_TEO, facing=1), 147)
        b = r.add(Kid(112, PAL_KID_NA, facing=1), 149)
        c = r.add(Kid(134, PAL_KID_HUNG, facing=1), 148)
        self.audio.ensure(CH_AMB, "wind", 0.6)
        self.audio.stop(CH_MUSIC, 1500)
        yield from self.fade(0, 0.9)
        yield from self.think("Trời tối sầm lại từ lúc nào.")
        yield from self.say("Tèo", "Ê tụi bây! Hình như sắp mưa rồi!")
        yield from self.say("Na", "Chạy lẹ! Mưa tới giờ!")
        r.rain = True
        self.audio.ensure(CH_AMB, "rain", 0.5)
        for k, off in ((kid, 26), (a, 48), (b, 70), (c, 92)):
            r.followers.append((k, off))
        yield from self.walk(r.me, 300, 84)
        yield from self.fade(1, 0.6)
        v = Village(self, "porch")
        self.scene = v
        v.me.x = 140
        v.me.facing = 1
        v.cam_focus = 122
        kid = v.add(Kid(118, PAL_KID_ME, facing=1), 150)
        v.add(Kid(96, PAL_KID_TEO, facing=1), 148)
        v.add(Kid(76, PAL_KID_NA, facing=1), 150)
        v.add(Kid(56, PAL_KID_HUNG, facing=1), 148)
        self.audio.ensure(CH_AMB, "raintin", 0.7)
        yield from self.fade(0, 0.8)
        yield from self.say("Tụi nhỏ", "Hộc... hộc... Ha ha ha! Ướt hết rồi!")
        yield from self.wait(1.2)
        yield from self.think("Lâu lắm rồi mới đứng yên nhìn mưa như thế này.")
        yield from self.say("Tèo", "Ê, tụi bây nhìn kìa! Nước chảy như con sông luôn!")
        v.me.set_expr("smile")
        yield from self.say("Tôi", "Ê mấy đứa, hay mình đua thuyền đi?")
        yield from self.say("Na", "Thuyền đâu mà chơi anh?")
        yield from self.say("Tôi", "Thuyền giấy chứ thuyền gì! Đó, mấy tờ giấy tập trong túi thằng Tèo kìa.")
        yield from self.say("Thằng nhóc", "Anh biết gấp thuyền hả?")
        yield from self.say("Tôi", "Biết chứ. Hồi nhỏ anh gấp hoài.")
        self.audio.ensure(CH_MUSIC, "village", 0.3)
        yield from self.play_mini(FoldGame(self), v)
        yield from self.say("Na", "Sao thuyền tao méo xẹo vậy?")
        yield from self.say("Tèo", "Tại mày gấp sai rồi!")
        yield from self.play_mini(BoatGame(self), v)
        self.give("Chiếc thuyền giấy")
        self.audio.stop(CH_MUSIC, 2500)
        yield from self.think("Trong khoảnh khắc ấy, mình quên mất mình đã 25 tuổi.")
        yield from self.think("Những chiếc thuyền trôi xa dần, khuất sau khúc cua.")
        yield from self.wait(1.0)
        yield from self.say("Tèo", "Chết! Trễ quá, mẹ tao la!")
        yield from self.say("Thằng nhóc", "Về chi! Trời chưa tối mà!")
        yield from self.say("Na", "Tối thui rồi còn gì!")
        yield from self.say("Na", "Tao cũng về đây! Nãy giờ chắc ba tao kiếm rồi!")
        yield from self.say("Hùng", "Ê! Tối nay ra cuối làng đá banh nha!")
        yield from self.say("Tèo", "Ăn cơm xong ra! Nhớ đem banh đó!")
        for x in (56, 76, 96):
            for a, _ in v.actors:
                if int(a.x) == x:
                    yield from self.walk(a, 320, 110)
                    a.visible = False
        yield from self.wait(0.8)
        v.me.set_expr("sad")
        yield from self.think("Từ khi nào, đội mưa chạy về nhà lại thành một điều xa xỉ.")
        yield from self.wait(0.6)
        yield from self.fade(1, 1.6)

    def c3_canh1_loi_moi(self):
        """Chuong 3, canh 1 - Loi moi ve nha, chay qua lang trong mua."""
        v = Village(self, "porch")
        self.scene = v
        v.me.x = 140
        v.me.facing = -1
        v.cam_focus = 122
        kid = v.add(Kid(118, PAL_KID_ME, facing=1), 150)
        self.audio.ensure(CH_AMB, "raintin", 0.6)
        yield from self.fade(0, 1.0)
        yield from self.say("Thằng nhóc", "Ủa anh, giờ anh đi đâu?")
        yield from self.say("Tôi", "Anh cũng chưa biết nữa.")
        yield from self.say("Thằng nhóc", "Trời còn mưa mà. Hay anh về nhà em ăn cơm đi.")
        yield from self.say("Tôi", "Thôi, anh làm phiền nhà em sao được.")
        yield from self.say("Thằng nhóc", "Có gì đâu anh! Nhà em đông người, ăn thêm một người cũng đâu có sao!")
        yield from self.wait(0.6)
        v.me.set_expr("surprise")
        yield from self.think("Khoan đã. Năm 2008.")
        yield from self.think("Hồi đó cả nhà mình vẫn còn sống chung với ông bà nội.")
        yield from self.think("Giờ bà lãng tai, lúc nhớ lúc quên. Một câu chuyện bà hỏi đi hỏi lại.")
        v.me.set_expr("sad")
        yield from self.think("Còn ông...")
        yield from self.wait(0.8)
        yield from self.think("Ông mất lâu rồi.")
        yield from self.wait(1.0)
        v.me.set_expr("wet")
        yield from self.think("Vậy mà lúc này...")
        yield from self.think("Có lẽ ông vẫn còn ở đó.")
        yield from self.say("Thằng nhóc", "Anh ơi? Anh có đi không?")
        yield from self.wait(0.6)
        v.me.set_expr("smile")
        yield from self.choose("", ["Ừ, đi.", "Thôi, để anh tự lo."])
        if self.choice_result == 1:
            yield from self.say("Thằng nhóc", "Đi mà anh! Đi đi đi!")
        yield from self.say("Tôi", "Ừ. Cho anh về ăn ké một bữa nha.")
        yield from self.say("Thằng nhóc", "Dạ! Nhanh lên anh! Không là cơm nguội hết!")
        self.audio.ensure(CH_AMB, "rain", 0.6)
        v.followers.append((kid, 26))
        kid.state = "walk"
        yield from self.walk(v.me, 318, 90)
        yield from self.fade(1, 0.6)
        al = Village(self, "alley")
        self.scene = al
        al.me.x = 16
        k2 = al.add(Kid(44, PAL_KID_ME, facing=1), 150)
        al.followers.append((k2, 30))
        yield from self.fade(0, 0.6)

        def look_fence():
            yield from self.think("Hàng rào dâm bụt. Hồi nhỏ mình hay vặt hoa mút mật ở đây.")
        yield from self.explore(al, 296, [(140, "hàng rào", look_fence)], speed=72)
        yield from self.fade(1, 0.6)
        h = Village(self, "home_out")
        self.scene = h
        h.me.x = 30
        h.cam_focus = 110
        k3 = h.add(Kid(56, PAL_KID_ME, facing=1), 150)
        yield from self.fade(0, 0.7)
        h.followers.append((k3, 22))
        yield from self.walk(h.me, 66, 60)
        h.followers = []
        k3.state = "idle"
        yield from self.say("Thằng nhóc", "Tới rồi anh! Nhà em nè!")
        yield from self.wait(1.2)
        h.me.set_expr("surprise")
        yield from self.think("Đó là nhà mình.")
        yield from self.wait(0.8)
        yield from self.think("Chiếc cổng cũ. Khoảng sân nhỏ. Mấy chậu cây dọc hiên.")
        h.me.set_expr("wet")
        yield from self.think("Tất cả vẫn còn nguyên.")
        yield from self.wait(0.8)
        yield from self.fade(1, 1.2)

    def c3_canh2_ong_ba(self):
        """Chuong 3, canh 2 - Ong noi, ba noi cua nam 2008."""
        h = Village(self, "home_out")
        self.scene = h
        h.me.x = 112
        h.me.facing = 1
        h.cam_focus = 170
        kid = h.add(Kid(138, PAL_KID_ME, facing=1), 150)
        ong = h.add(Actor(196, PAL_ONG, facing=-1, expr="cross"), 146)
        ong.visible = False
        ba = h.add(Actor(222, PAL_BA_NOI, facing=-1, head=HEAD_BUN, expr="sad"), 146)
        ba.visible = False
        h.props.append((ong, make_rod(), 3, -24))
        self.audio.ensure(CH_AMB, "rain", 0.5)
        yield from self.fade(0, 0.9)
        yield from self.say("Thằng nhóc", "Con về rồi!")
        yield from self.say("Tiếng từ trong nhà", "Cái thằng quỷ! Giờ này mới chịu về hả?")
        self.audio.play("door", 0.4)
        ong.visible = True
        yield from self.wait(0.5)
        ba.visible = True
        yield from self.say("Bà", "Trời mưa lớn vậy mà cũng chạy đi chơi! Từ trưa tới giờ không thấy mặt mũi đâu hết!")
        yield from self.say("Thằng nhóc", "Dạ... tại tụi con chơi ngoài kia rồi trời mưa...")
        yield from self.say("Thằng nhóc", "Ông ơi! Con có dẫn anh này về nè!")
        h.me.set_expr("surprise")
        yield from self.say("Ông", "Ủa? Cậu nào đây?")
        yield from self.wait(1.4)
        yield from self.show_closeup(make_portrait(PAL_ONG, expr="neutral"), 0.9)
        yield from self.wait(1.2)
        yield from self.think("Dáng đứng ấy. Giọng nói ấy.")
        yield from self.think("Chỉ khác là ông đang ở ngay trước mặt.")
        yield from self.wait(0.6)
        yield from self.think("Bằng xương bằng thịt.")
        yield from self.wait(1.0)
        self.closeup = (make_portrait(me_pal(True, True), expr="tear"), 1.0)
        yield from self.think("Muốn gọi một tiếng ông nội... mà cổ họng nghẹn lại.")
        yield from self.hide_closeup(0.6)
        yield from self.say("Ông", "Cậu ơi?")
        yield from self.wait(0.5)
        h.me.set_expr("wet")
        yield from self.say("Tôi", "Dạ... con chào ông.")
        h.props = []
        yield from self.wait(0.4)
        yield from self.say("Thằng nhóc", "Anh này ở thành phố về chơi đó ông! Con rủ anh về ăn cơm luôn!")
        ong.set_expr("neutral")
        ba.set_expr("smile")
        yield from self.say("Bà", "Trời đất, có khách sao không nói sớm. Vô nhà đi con, đứng ngoài đó ướt hết bây giờ.")
        yield from self.show_closeup(make_portrait(PAL_BA_NOI, head=HEAD_BUN), 0.9)
        yield from self.wait(1.0)
        yield from self.think("Bà không phải nghiêng tai để nghe. Mắt bà còn tinh.")
        yield from self.think("Bà không hỏi lại lần thứ hai.")
        yield from self.hide_closeup(0.6)
        yield from self.say("Tôi", "Dạ... con cảm ơn bà.")
        yield from self.say("Bà", "Để bà lấy cái khăn cho lau. Mưa gió vậy mà tụi bây còn chạy ngoài đường!")
        yield from self.wait(1.0)
        h.me.set_expr("shut")
        yield from self.think("Phải cúi đầu xuống một chút. Kẻo ai thấy mắt mình đỏ.")
        yield from self.wait(0.8)
        yield from self.fade(1, 1.4)

    def c3_canh3_ba_me(self):
        """Chuong 3, canh 3 - Gap lai ba me."""
        v = Village(self, "home")
        self.scene = v
        v.me.x = 36
        v.me.facing = 1
        v.cam = 90.0
        v.cam_focus = 100
        set_outfit(v.me, True, False)
        kid = v.add(Kid(62, PAL_KID_ME, facing=1), 151)
        me_ = v.add(Actor(232, PAL_MOTHER, female=True, facing=-1, expr="smile"), 148)
        me_.visible = False
        ba_ = v.add(Actor(232, PAL_FATHER, facing=-1, expr="smile"), 148)
        ba_.visible = False
        v.props.append((me_, make_ladle(), 4, -20))
        v.props.append((ba_, make_towel(), 4, -14))
        self.audio.ensure(CH_AMB, "rain", 0.25)
        yield from self.fade(0, 0.9)
        self.audio.play("clink", 0.5)
        yield from self.wait(0.8)
        self.audio.play("clink", 0.4)
        yield from self.say("Tiếng từ sau bếp", "Ai mới tới vậy má?")
        v.cam_focus = 140
        me_.visible = True
        yield from self.walk(me_, 118, 34)
        yield from self.wait(1.2)
        yield from self.show_closeup(make_portrait(PAL_MOTHER, female=True), 0.9)
        yield from self.wait(1.0)
        v.me.set_expr("surprise")
        yield from self.think("Mẹ.")
        yield from self.wait(1.0)
        yield from self.think("Tóc đen buộc gọn. Khoé mắt chưa có nếp nhăn.")
        yield from self.hide_closeup(0.6)
        yield from self.say("Mẹ", "Ủa, nhà mình có khách hả con?")
        yield from self.say("Thằng nhóc", "Dạ! Anh này chơi chung với con. Con mời anh về ăn cơm!")
        yield from self.say("Mẹ", "Con cứ tự nhiên nha. Nhà có gì ăn nấy thôi.")
        yield from self.wait(0.6)
        v.me.set_expr("wet")
        yield from self.say("Tôi", "Dạ... con cảm ơn cô.")
        yield from self.wait(1.2)
        v.me.set_expr("sad")
        yield from self.think("Hai tiếng \"cảm ơn cô\". Sao mà xa lạ.")
        yield from self.wait(0.6)
        yield from self.say("Tiếng từ sau nhà", "Ủa, ai tới chơi vậy?")
        ba_.visible = True
        yield from self.walk(ba_, 146, 34)
        yield from self.show_closeup(make_portrait(PAL_FATHER), 0.9)
        yield from self.wait(1.0)
        v.me.set_expr("wet")
        yield from self.think("Ba. Tóc đen. Vai còn thẳng.")
        yield from self.hide_closeup(0.6)
        yield from self.say("Ba", "Bạn của thằng nhỏ hả? Cứ vô nhà ngồi chơi con.")
        yield from self.think("Đến khi nhận ra ba mẹ đã già, mình chẳng nhớ nổi họ bắt đầu già từ lúc nào.")
        yield from self.say("Thằng nhóc", "Anh! Lại đây ngồi đi! Em lấy ghế cho!")
        yield from self.wait(0.6)
        v.me.set_expr("wet")
        yield from self.wait(1.2)
        yield from self.fade(1, 1.6)

    def c3_canh4_bua_com(self):
        """Chuong 3, canh 4 - Bua com chieu mua (cutscene, khong co nhiem vu)."""
        v = Village(self, "meal")
        self.scene = v
        v.me.x = 112
        v.me.state = "sit"
        v.me.facing = -1
        set_outfit(v.me, False, False)
        v.me_floor = 150
        v.cam = 100.0
        v.cam_focus = 100
        for pal, x, fc, fem in ((PAL_ONG, 44, 1, False), (PAL_BA_NOI, 66, 1, False), (PAL_FATHER, 88, 1, False), (PAL_MOTHER, 158, -1, True)):
            v.add(Actor(x, pal, female=fem, facing=fc, state="sit", head=HEAD_BUN if pal is PAL_BA_NOI else None, expr="smile"), 150)
        v.add(Kid(136, PAL_KID_ME, facing=-1, state="sit"), 150)
        self.audio.ensure(CH_AMB, "rain", 0.3)
        self.auto_talk = True  # cutscene: khong can bam phim
        yield from self.fade(0, 1.6)
        yield from self.wait(1.5)
        for kind, line in (("canh", "Canh bắp cải hầm xương."), ("suon", "Sườn heo cháy sả."), ("ca", "Cá khô. Chiếc đĩa sứ sứt một góc.")):
            yield from self.show_closeup(make_dish(kind), 0.5)
            yield from self.think(line)
            yield from self.hide_closeup(0.4)
        yield from self.think("Mình nhớ cả chỗ ngồi của từng người.")
        yield from self.say("Bà", "Rồi, ăn cơm thôi!")
        self.audio.play("clink", 0.5)
        yield from self.say("Thằng nhóc", "Con mời ông bà, ba mẹ ăn cơm!")
        self.audio.play("clink", 0.35)
        yield from self.say("Ba", "Đi làm xa chắc cực lắm ha.")
        yield from self.say("Tôi", "Dạ, cũng có lúc cực.")
        yield from self.say("Ba", "Thôi, về quê thì nghỉ ngơi vài bữa. Công việc lúc nào cũng có, chứ đâu phải lúc nào cũng được về nhà.")
        yield from self.wait(1.6)
        yield from self.say("Bà", "Con ăn thêm cơm không? Để bà xới cho.")
        yield from self.say("Bà", "Thanh niên gì mà ăn ít vậy!")
        self.audio.play("clink", 0.4)
        yield from self.wait(1.0)
        v.me.set_expr("wet")
        yield from self.think("Vẫn động tác đó.")
        yield from self.think("Bây giờ bà vẫn hỏi mình ăn cơm chưa. Chỉ là đôi khi hỏi xong, bà lại quên câu trả lời.")
        yield from self.wait(1.0)
        self.audio.play("bite", 0.4)
        yield from self.wait(1.4)
        yield from self.think("Đúng là vị này.")
        v.me.set_expr("sad")
        yield from self.say("Mẹ", "Sao vậy con? Không hợp khẩu vị hả?")
        yield from self.wait(0.5)
        yield from self.say("Tôi", "Dạ không... Ngon lắm cô.")
        yield from self.wait(1.2)
        yield from self.show_closeup(make_portrait(me_pal(False, False), expr="tear"), 0.6)
        yield from self.think("Muốn gọi một tiếng mẹ.")
        yield from self.wait(1.0)
        yield from self.hide_closeup(0.5)
        yield from self.think("Nhưng lúc này, mình chỉ là người khách được mời về ăn cơm.")
        yield from self.think("Có lẽ, như thế cũng đủ rồi.")
        self.audio.loop(CH_MUSIC, "piano", 0.6, 4000)
        self.audio.volume(CH_AMB, 0.2)
        yield from self.say("Thằng nhóc", "Hồi chiều thuyền con chạy nhanh nhất luôn đó mẹ! Thiệt đó!")
        yield from self.wait(2.0)
        yield from self.wait(2.0)
        yield from self.wait(0.8)
        yield from self.wait(0.8)
        yield from self.think("Một bữa cơm mình từng nghĩ, lúc nào muốn cũng có thể trở về.")
        yield from self.wait(1.5)
        self.auto_talk = False
        yield from self.fade(1, 2.2)
        v.outside = True
        v.rain = True
        self.audio.volume(CH_AMB, 0.45)
        yield from self.fade(0, 2.4)
        yield from self.wait(6.0)
        yield from self.fade(1, 3.0)
        self.audio.stop(CH_AMB, 2500)
        self.audio.stop(CH_MUSIC, 3000)
        yield from self.wait(1.0)
        yield

    def c4_canh1_truong_lang(self):
        """Chuong 4, canh 1 - Chao ca nha, ngoi truong lang, uoc mo cua thang nhoc."""
        h = Village(self, "home_out")
        h.rain = False
        h.storm()
        self.scene = h
        h.me.x = 150
        h.me.facing = 1
        h.cam_focus = 170
        set_outfit(h.me, True, True)
        h.add(Kid(128, PAL_KID_ME, facing=1), 150)
        h.add(Actor(222, PAL_BA_NOI, facing=-1, head=HEAD_BUN, expr="smile"), 146)
        h.add(Actor(196, PAL_MOTHER, female=True, facing=-1, expr="smile"), 146)
        self.audio.ensure(CH_AMB, "cicada", 0.22)
        yield from self.fade(0, 1.0)
        yield from self.say("Mẹ", "Nhớ về sớm nghen!")
        yield from self.say("Bà", "Rảnh thì ghé nhà chơi nghen con.")
        h.me.set_expr("wet")
        yield from self.wait(0.8)
        yield from self.say("Tôi", "Dạ... con cảm ơn cả nhà.")
        yield from self.wait(0.6)
        yield from self.fade(1, 0.9)
        v = Village(self, "school")
        self.scene = v
        v.me.x = 24
        kid = v.add(Kid(50, PAL_KID_ME, facing=1), 150)
        v.followers.append((kid, 24))
        self.audio.ensure(CH_AMB, "cicada", 0.22)
        self.audio.ensure(CH_MUSIC, "village", 0.3)
        yield from self.fade(0, 1.2)

        def look_class():
            yield from self.think("Bảng đen còn sót lại một dòng phấn. Bài tập về nhà.")
            self.give("Dòng phấn trên bảng đen")
        yield from self.explore(v, 118, [(78, "cửa lớp", look_class)], xmin=14)
        v.followers = []
        kid.state = "idle"
        kid.facing = -1
        v.me.facing = 1
        v.cam_focus = 140
        yield from self.wait(0.6)
        v.me.set_expr("surprise")
        yield from self.think("Trường này... ở thời của mình, người ta đập bỏ lâu rồi.")
        yield from self.say("Thằng nhóc", "Trường em đó! Em ngồi bàn thứ hai, có khắc tên nữa.")
        v.me.set_expr("smile")
        yield from self.say("Tôi", "Mà nhóc có ước mơ gì không?")
        yield from self.say("Thằng nhóc", "Em muốn làm người lớn! Được lái xe, đi đây đi đó, khỏi xin phép ba mẹ, khỏi phải về nhà trước giờ cơm!")
        yield from self.say("Thằng nhóc", "Rồi em làm nhà khoa học, chế ra máy móc siêu hiện đại luôn!")
        yield from self.think("Đúng là mình hồi nhỏ.")
        v.me.set_expr("sad")
        yield from self.think("Bây giờ không còn ai bắt mình về trước giờ cơm nữa.")
        yield from self.wait(0.8)
        yield from self.say("Thằng nhóc", "Còn anh? Anh làm gì?")
        yield from self.say("Tôi", "Anh... làm việc với máy tính.")
        yield from self.say("Thằng nhóc", "Oa! Anh chế ra máy hả?")
        yield from self.wait(1.4)
        yield from self.choose("", ["Ừ... cũng gần vậy.", "Không. Anh chỉ giữ cho nó chạy thôi."])
        if self.choice_result == 0:
            yield from self.say("Tôi", "Ừ... cũng gần vậy.")
        else:
            yield from self.say("Tôi", "Không. Anh chỉ giữ cho nó chạy thôi.")
            yield from self.say("Thằng nhóc", "Vậy cũng giỏi mà!")
        yield from self.think("Mình viết chương trình cho máy chạy.")
        yield from self.wait(0.6)
        yield from self.think("Rồi từ lúc nào, mình cũng chạy như một cái máy.")
        yield from self.wait(0.8)
        yield from self.fade(1, 1.2)

    def c4_canh2_tran_banh(self):
        """Chuong 4, canh 2 - Da penalty, trai banh, nham mat."""
        v = Village(self, "field")
        self.scene = v
        v.me.x = 118
        v.me.set_expr("smile")
        v.cam_focus = 160
        kid = v.add(Kid(146, PAL_KID_ME, facing=-1), 150)
        v.add(Kid(172, PAL_KID_TEO, facing=-1), 147)
        v.add(Kid(198, PAL_KID_NA, facing=-1), 150)
        hung = v.add(Kid(248, PAL_KID_HUNG, facing=-1), 148)
        self.audio.ensure(CH_AMB, "cicada", 0.25)
        self.audio.ensure(CH_MUSIC, "village", 0.42)
        yield from self.fade(0, 1.0)
        yield from self.say("Hùng", "Tới rồi hả! Sút penalty nha!")
        yield from self.play_mini(PenaltyGame(self), v)
        self.give("Trái banh cuối làng")
        self.audio.stop(CH_MUSIC, 2500)
        v.me.set_expr("sad")
        v.me.facing = -1
        yield from self.wait(0.8)
        yield from self.think("Cái trường. Bữa cơm. Ông...")
        yield from self.say("Tèo", "Thôi về đi tụi bây, tối thui rồi!")
        v.me.set_expr("wet")
        yield from self.say("Thằng nhóc", "Trời chưa tối mà! Sút thêm trái nữa!")
        yield from self.say("Thằng nhóc", "Ê anh ơi, coi chừng!")
        v.me.set_expr("surprise")
        self.audio.play("thud", 0.9)
        e = 0.0
        while e < 0.34:
            e += self.dt
            k = min(1.0, e / 0.34)
            v.ball = (lerp(hung.x, v.me.x, k), lerp(144, 126, k) - math.sin(k * 3.14) * 16)
            yield
        v.ball = None
        self.audio.play("thud", 1.0)
        base = v.me.x
        e = 0.0
        while e < 0.8:
            e += self.dt
            v.me.x = base + math.sin(e * 22) * 2.5
            yield
        v.me.x = base
        v.me.state = "sleep"
        self.audio.stop_all(200)
        yield from self.fade(1, 0.25)
        yield from self.wait(1.4)

    def c5_canh1_tinh_day(self):
        """Chuong 5, canh 1 - Tinh day tren xe, tuong chi la giac mo."""
        b = BusInterior(self)
        b.morning = True
        b.driver = Actor(BUS_X0 + 17, PAL_DRIVER_OLD, facing=-1, state="sit", expr="smile")
        set_outfit(b.me, True, True)
        seat = len(BUS_SEATS) - 2
        b.me_seat = seat
        b.me.x = BUS_SEATS[seat]
        b.me.facing = -1
        b.me.state = "sleep"
        b.sleep = 1.0
        b.target_speed = 70
        b.speed = 70
        self.scene = b
        self.audio.ensure(CH_AMB, "birds", 0.4)
        self.audio.ensure(CH_ENGINE, "engine", 0.2)
        yield from self.fade(0, 1.2)
        yield from self.wait(1.0)
        e = 0.0
        while e < 0.9:
            e += self.dt
            b.sleep = max(0.0, 1 - e / 0.9)
            yield
        b.sleep = 0.0
        b.me.state = "sit"
        b.me.set_expr("surprise")
        yield from self.think("Ghế cạnh cửa sổ, hàng thứ hai từ dưới lên.")
        yield from self.think("Mình... ngủ quên à?")
        self.audio.play("ding", 0.6)
        yield from self.show_closeup(make_phone_now(), 0.5)
        self.audio.play("ding", 0.5)
        yield from self.think("Có sóng lại rồi. Mười hai tin nhắn.")
        yield from self.hide_closeup(0.4)
        b.me.set_expr("sad")
        yield from self.think("Mơ thôi sao...")
        yield from self.wait(1.0)
        yield from self.think("Sờ lên trán. Vẫn còn đau.")
        yield from self.wait(0.8)
        b.target_speed = 0
        b.speed = 0
        self.audio.volume(CH_ENGINE, 0.08)
        drv = b.driver
        drv.state = "idle"
        drv.facing = 1
        drv.x = BUS_SEATS[seat] - 12
        yield from self.wait(0.4)
        yield from self.say("Tài xế", "Tới nơi rồi.")
        b.me.state = "idle"
        b.me_seat = None
        b.door_open = True
        self.audio.play("door", 0.5)
        drv.x = BUS_SEATS[seat] - 22
        yield from self.walk(b.me, BUS_DOOR, 30)
        b.me.visible = False
        yield from self.fade(1, 0.9)

    def c5_canh2_van_kip(self):
        """Chuong 5, canh 2 - Xuong xe, 'Troi chua toi ma', vien bi, 'Van kip'."""
        v = Village(self, "now")
        self.scene = v
        v.bus_x = 190.0
        v.door_open = True
        v.me.x = 206
        v.me.facing = -1
        v.me.set_expr("sad")
        v.cam_focus = 168
        drv = v.add(Actor(212, PAL_DRIVER_OLD, facing=-1, expr="smile"), 148)
        self.audio.ensure(CH_AMB, "birds", 0.5)
        self.audio.ensure(CH_ENGINE, "engine", 0.18)
        yield from self.fade(0, 1.0)
        yield from self.walk(v.me, 150, 26)
        yield from self.wait(0.5)
        yield from self.think("Đường nhựa. Nhà mới. Đúng là năm 2026 rồi.")
        yield from self.wait(0.6)
        yield from self.say("Tài xế", "Cháu ơi!")
        v.me.facing = 1
        v.me.set_expr("surprise")
        yield from self.wait(0.6)
        yield from self.say("Tài xế", "Trời chưa tối mà.")
        drv.set_expr("wink")
        self.audio.play("blip", 0.8)
        yield from self.show_closeup(make_portrait(PAL_DRIVER_OLD, expr="wink"), 0.4)
        yield from self.wait(1.2)
        yield from self.hide_closeup(0.4)
        drv.visible = False
        v.door_open = False
        self.audio.play("hiss", 0.5)
        yield from self.wait(0.6)
        start = v.bus_x
        e = 0.0
        while e < 3.0:
            e += self.dt
            v.bus_x = start - 460 * (e / 3.0) ** 2
            self.audio.volume(CH_ENGINE, 0.3 * max(0.0, 1 - e / 3.0))
            yield
        v.bus_x = None
        self.audio.stop(CH_ENGINE, 400)
        yield from self.wait(1.2)
        yield from self.think("Trời đang sáng trưng mà...")
        yield from self.wait(1.0)
        yield from self.think("Câu đó...")
        yield from self.wait(1.0)
        self.audio.play("ok", 0.35)
        yield from self.show_closeup(make_big_marble(), 0.8)
        yield from self.wait(2.2)
        yield from self.hide_closeup(0.6)
        v.me.set_expr("smile")
        self.audio.loop(CH_MUSIC, "piano", 0.5, 2500)
        yield from self.wait(1.5)
        yield from self.think("Vẫn kịp.")
        yield from self.wait(2.0)
        self.audio.stop(CH_AMB, 2500)
        yield from self.fade(1, 2.6)
        self.audio.stop(CH_MUSIC, 2000)
        yield

    def canh0_lap_lai(self):
        """Chuong 1, canh 1 - Nhung ngay giong nhau: 1 nut bam, mau xam dan."""
        room_m = Room(self)
        room_m.morning = True
        room_m.lying = True
        room_m.jacket = True
        street = Street(self)
        street.morning = True
        street.minutes = 6 * 60 + 41
        street.clock_cap = 6 * 60 + 41
        street.me.x = 222
        street.me.set_expr("neutral")
        office = Office(self)
        office.clock_run = False
        office.minutes = 8 * 60.0
        office.me.state = "type"
        room_n = Room(self)
        room_n.lights = True
        room_n.me.visible = True
        room_n.me.x = 120
        room_n.jacket = True
        beats = [(room_m, "06:30", "ding"), (street, "07:10", None), (office, "08:00", "key1"), (room_n, "22:40", "click")]
        self.audio.ensure(CH_AMB, "rain", 0.12)
        self.fade_a = 0.0
        for d, day in enumerate(("Thứ Ba", "Thứ Tư", "Thứ Năm")):
            self.grey = 0.2 + d * 0.36
            for scene, clock, snd in beats:
                self.scene = scene
                self.stamp = "%s  ·  %s" % (day, clock)
                self.hint = "Nhấn Enter để sang việc tiếp theo"
                if snd:
                    self.audio.play(snd, 0.5)
                yield
                while not self.confirm:
                    yield
                self.hint = ""
                yield
        self.stamp = ""
        self.scene = room_n
        self.audio.loop(CH_PHONE, "ringtone", 0.45, 10)
        yield from self.wait(0.8)
        self.audio.stop(CH_PHONE, 80)
        yield from self.say("Bà (điện thoại)", "Ăn cơm chưa con?")
        yield from self.choose("", ["Dạ rồi."])
        yield from self.say("Tôi", "Dạ rồi.")
        yield from self.wait(1.0)
        yield from self.fade(1, 0.9)
        self.grey = 0.0
        self.audio.stop(CH_AMB, 600)
        yield

    def old_people(self):
        """Ba, me, ba noi cua nam 2026."""
        return (dict(PAL_BA_NOI, h="#d8d4cc", H="#f0ece4"),
                dict(PAL_FATHER, h="#aaa6a0", H="#c8c4bc", s="#dcae88", S="#b98c66", g="#dcae88"),
                dict(PAL_MOTHER, h="#8a8580", H="#aaa49c", s="#e8bc98", S="#c49a78", g="#e8bc98"))

    def c5_canh3_ve_nha(self):
        """Chuong 5, canh 3 - Di qua lang 2026, ba hoi com, thap nhang cho ong."""
        v = Village(self, "now_lane")
        self.scene = v
        v.me.x = 16
        v.me.set_expr("wet")
        self.audio.ensure(CH_AMB, "birds", 0.45)
        yield from self.fade(0, 1.2)

        def look_lot():
            yield from self.think("Chỗ này từng là trường.")

        def look_shop():
            yield from self.think("Tiệm bà Nga.")
        yield from self.explore(v, 300, [(90, "bãi đất", look_lot), (214, "căn tiệm đóng cửa", look_shop)], speed=46)
        yield from self.fade(1, 0.8)
        ba_g, _, _ = self.old_people()
        h = Village(self, "home_now")
        self.scene = h
        h.me.x = 92
        h.me.facing = 1
        h.me.set_expr("smile")
        h.cam_focus = 150
        ba = h.add(Actor(186, ba_g, facing=-1, state="sit", head=HEAD_BUN, expr="neutral"), 146)
        yield from self.fade(0, 1.0)
        yield from self.walk(h.me, 164, 36)
        yield from self.wait(1.0)
        for i, gap in enumerate((1.2, 1.6, 0)):
            yield from self.say("Bà", "Ăn cơm chưa con?")
            yield from self.choose("", ["Dạ, con chưa. Con ăn với bà."])
            if gap:
                yield from self.wait(gap)
        ba.set_expr("smile")
        h.me.set_expr("wet")
        yield from self.say("Bà", "Ừ. Vô ăn cơm đi con.")
        yield from self.fade(1, 1.0)
        v = Village(self, "home")
        self.scene = v
        v.me.x = 124
        v.me.facing = -1
        v.cam = 124.0
        v.cam_focus = 124
        set_outfit(v.me, True, False)
        v.me.set_expr("wet")
        self.audio.ensure(CH_AMB, "birds", 0.25)
        yield from self.fade(0, 1.0)
        yield from self.wait(1.0)
        yield from self.show_closeup(make_portrait(PAL_ONG, expr="smile"), 0.8)
        yield from self.wait(1.6)
        yield from self.say("Tôi", "Con về rồi.")
        yield from self.wait(1.2)
        yield from self.hide_closeup(0.6)
        yield from self.fade(1, 1.2)

    def c5_canh4_bua_com_hai(self):
        """Chuong 5, canh 4 - Bua com 2026: mot chiec bat khong, 'Ngon lam me'."""
        ba_g, ba_o, me_o = self.old_people()
        v = Village(self, "meal")
        self.scene = v
        v.me.x = 112
        v.me.state = "sit"
        v.me.facing = -1
        v.me_floor = 150
        v.cam = 100.0
        v.cam_focus = 100
        set_outfit(v.me, False, False)
        v.me.set_expr("smile")
        v.add(Actor(66, ba_g, facing=1, state="sit", head=HEAD_BUN, expr="smile"), 150)
        v.add(Actor(88, ba_o, facing=1, state="sit", expr="smile"), 150)
        v.add(Actor(158, me_o, female=True, facing=-1, state="sit", expr="smile"), 150)
        self.auto_talk = True
        self.audio.ensure(CH_AMB, "rain", 0.3)
        yield from self.show_caption("Chiều hôm đó, trời lại mưa", "", 2.4)
        yield from self.fade(0, 1.6)
        yield from self.wait(2.0)
        yield from self.show_closeup(make_dish("suon"), 0.5)
        yield from self.wait(1.4)
        yield from self.hide_closeup(0.4)
        self.audio.play("bite", 0.4)
        yield from self.wait(1.6)
        v.me.set_expr("wet")
        yield from self.wait(1.0)
        yield from self.say("Mẹ", "Sao vậy con? Không hợp khẩu vị hả?")
        yield from self.wait(0.8)
        self.audio.loop(CH_MUSIC, "piano", 0.55, 3000)
        yield from self.say("Tôi", "Dạ không... Ngon lắm mẹ.")
        yield from self.wait(3.0)
        self.auto_talk = False
        yield from self.fade(1, 2.2)
        v.outside = True
        v.rain = True
        yield from self.fade(0, 2.2)
        yield from self.wait(5.0)
        yield from self.fade(1, 2.4)

    def c5_canh5_mot_buoi_sang(self):
        """Chuong 5, canh 5 - Mot buoi sang binh thuong va nhung nam ve sau (khong loi)."""
        s = Street(self)
        s.morning = True
        s.minutes = s.clock_cap = 7 * 60
        s.me.x = 222
        set_outfit(s.me, True, True)
        s.me.state = "sit"
        s.me.set_expr("smile")
        self.scene = s
        self.audio.ensure(CH_AMB, "birds", 0.45)
        yield from self.fade(0, 1.4)
        yield from self.wait(1.2)
        yield from self.show_closeup(make_banhmi(), 0.5)
        self.audio.play("bite", 0.6)
        yield from self.wait(1.4)
        yield from self.hide_closeup(0.4)
        self.audio.play("ding", 0.5)
        yield from self.show_closeup(make_phone_now(), 0.4)
        yield from self.wait(1.2)
        yield from self.hide_closeup(0.4)
        yield from self.say("Tôi", "A lô, mẹ hả? Dạ, con ăn sáng rồi. Thiệt đó.")
        yield from self.fade(1, 1.0)
        o = Office(self)
        o.clock_run = False
        o.minutes = 8 * 60 + 5.0
        o.lan.state = "idle"
        o.lan.facing = 1
        o.lan.set_expr("smile")
        o.me.state = "sit"
        o.me.set_expr("smile")
        self.scene = o
        yield from self.fade(0, 0.9)
        yield from self.say("Chị Lan", "Sáng nay trông em khác ghê.")
        yield from self.show_closeup(make_big_marble(), 0.5)
        yield from self.wait(1.6)
        yield from self.hide_closeup(0.4)
        yield from self.fade(1, 0.9)
        b = BusInterior(self)
        b.morning = True
        b.driver = Actor(BUS_X0 + 17, PAL_DRIVER_OLD, facing=-1, state="sit", expr="smile")
        set_outfit(b.me, True, True)
        seat = 4
        b.add_passenger(1, 0)
        b.add_passenger(6, 1)
        b.me_seat = seat
        b.me.x = BUS_SEATS[seat]
        b.me.state = "sit"
        b.me.facing = -1
        b.me.set_expr("smile")
        b.target_speed = 60
        b.speed = 60
        self.scene = b
        self.audio.ensure(CH_ENGINE, "engine", 0.18)
        yield from self.fade(0, 0.8)
        yield from self.wait(1.2)
        b.me.state = "idle"
        b.me_seat = None
        yield from self.walk(b.me, BUS_SEATS[seat] + 12, 30)
        b.me.facing = -1
        b.standing.append(b.me)
        b.add_passenger(seat, 3)
        yield from self.wait(1.8)
        self.audio.stop(CH_ENGINE, 600)
        yield from self.fade(1, 0.9)
        # nhieu nam sau: chu tai xe
        yield from self.show_caption("Nhiều năm sau", "", 2.2)
        st = Street(self)
        st.morning = True
        st.minutes = st.clock_cap = 6 * 60 + 46
        st.bus_x = 226.0
        st.door_open = True
        st.me.x = 180
        st.me.facing = 1
        st.me.set_expr("sad")
        set_outfit(st.me, True, True)
        drv = Actor(208, PAL_DRIVER_OLD, facing=-1, expr="smile")
        st.extras = [drv]
        self.scene = st
        self.audio.ensure(CH_ENGINE, "engine", 0.15)
        yield from self.fade(0, 1.0)
        yield from self.wait(1.0)
        yield from self.show_closeup(make_banhmi(), 0.5)
        yield from self.say("Chú tài xế", "Nè, ăn đi rồi mình đi.")
        yield from self.hide_closeup(0.4)
        st.me.set_expr("smile")
        yield from self.show_closeup(make_crumpled_ticket(), 0.5)
        yield from self.wait(1.2)
        yield from self.hide_closeup(0.4)
        yield from self.say("Chú tài xế", "Đi đây đi đó, khỏi xin phép ai. Ha ha!")
        self.audio.stop(CH_ENGINE, 800)
        yield from self.fade(1, 1.0)
        # nhieu nam nua: ong lao
        yield from self.show_caption("Nhiều năm nữa", "", 2.2)
        n = BusInterior(self)
        seat = 3
        n.add_passenger(1, 2, state="sleep")
        n.add_passenger(6, 4, state="sleep")
        n.me_seat = seat
        n.me.x = BUS_SEATS[seat]
        n.me.state = "sleep"
        n.me.facing = -1
        old = Actor(BUS_SEATS[seat] - 14, PAL_OLD, facing=1, head=HEAD_OLD, expr="smile")
        n.standing = [old]
        n.target_speed = 60
        n.speed = 60
        self.scene = n
        self.audio.ensure(CH_AMB, "rain", 0.25)
        yield from self.fade(0, 1.2)
        yield from self.wait(1.4)
        self.audio.play("ok", 0.3)
        yield from self.show_closeup(make_ticket(), 0.8)
        yield from self.wait(2.4)
        yield from self.hide_closeup(0.6)
        yield from self.wait(0.8)
        self.audio.stop(CH_AMB, 2000)
        yield from self.fade(1, 1.6)
        self.audio.stop(CH_MUSIC, 2500)
        yield from self.wait(1.0)
        self.audio.play("laugh", 0.6)
        yield from self.show_caption("Trời chưa tối mà!", "", 3.2)
        yield from self.wait(0.8)

    def ending(self):
        """Man hinh ket."""
        self.scene = Ending(self)
        self.state = "end"
        self.audio.loop(CH_MUSIC, "music", 0.5, 3000)
        yield from self.fade(0, 2.5)
        self.fade_col = (0, 0, 0)
        while not self.confirm:
            yield
        self.audio.stop(CH_MUSIC, 1000)
        yield from self.fade(1, 1.0)
        self.reset()
        yield
        yield

    # ---- vong lap
    def handle_events(self):
        self.confirm = False
        self.space_pressed = False
        self.nav = 0
        self.mouse_pressed = False
        self.mouse_released = False
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return False
            if e.type == pygame.MOUSEMOTION:
                self.mouse_win = e.pos
                if self.vol_drag:
                    self.volume_from_x(e.pos[0])
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                self.mouse_win = e.pos
                icon, bar = self.vol_rects()
                if icon.collidepoint(e.pos):  # nut am luong khong tinh la thao tac choi
                    self.toggle_mute()
                    continue
                if self.vol_visible() and bar.inflate(12, 20).collidepoint(e.pos):
                    self.vol_drag = True
                    self.volume_from_x(e.pos[0])
                    continue
                self.mouse_pressed = True
                self.mouse_held = True
            if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                if self.vol_drag:
                    self.vol_drag = False
                    save_volume(self.audio.master, self.audio.muted)
                    continue
                self.mouse_released = True
                self.mouse_held = False
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    # o man hinh tieu de: thoat game; trong luc choi: ve tieu de
                    if self.state == "title" and (self.menu is None or self.menu["kind"] == "main"):
                        if not WEB:
                            return False
                    self.back = True
                if self.state == "end" and e.key == pygame.K_g:
                    open_feedback()
                if e.key == pygame.K_F11 and not WEB:
                    pygame.display.toggle_fullscreen()
                if e.key == pygame.K_m:
                    self.toggle_mute()
                if e.key in (pygame.K_MINUS, pygame.K_KP_MINUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
                    step = -0.1 if e.key in (pygame.K_MINUS, pygame.K_KP_MINUS) else 0.1
                    self.audio.apply(master=self.audio.master + step, muted=False)
                    self.vol_t = 2.0
                    save_volume(self.audio.master, self.audio.muted)
                if e.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_e, pygame.K_z):
                    self.confirm = True
                if e.key == pygame.K_SPACE:
                    self.space_pressed = True
                if e.key in (pygame.K_LEFT, pygame.K_a, pygame.K_UP, pygame.K_w):
                    self.nav = -1
                if e.key in (pygame.K_RIGHT, pygame.K_d, pygame.K_DOWN, pygame.K_s):
                    self.nav = 1
        self.keys = pygame.key.get_pressed()
        mx, my = pygame.mouse.get_pos()
        self.mouse = (mx // SCALE, my // SCALE)
        return True

    def vol_rects(self):
        y = 62 if isinstance(self.scene, ChMini) else 14
        return pygame.Rect(WIN_W - 58, y, 40, 40), pygame.Rect(WIN_W - 206, y + 13, 136, 14)

    def vol_visible(self):
        icon, bar = self.vol_rects()
        return self.vol_drag or self.vol_t > 0 or icon.union(bar).inflate(16, 16).collidepoint(self.mouse_win)

    def toggle_mute(self):
        self.audio.apply(muted=not self.audio.muted)
        self.vol_t = 2.0
        save_volume(self.audio.master, self.audio.muted)

    def volume_from_x(self, x):
        bar = self.vol_rects()[1]
        self.audio.apply(master=(x - bar.x) / float(bar.w), muted=False)
        self.vol_t = 2.0

    def draw_volume(self, scr):
        icon, bar = self.vol_rects()
        a = self.audio
        level = a.gain()
        col = (250, 244, 228)
        if self.vol_visible():
            panel = pygame.Surface((bar.w + 28, 40), pygame.SRCALPHA)
            panel.fill((22, 20, 36, 200))
            scr.blit(panel, (bar.x - 14, icon.y))
            pygame.draw.rect(scr, (70, 66, 86), bar)
            pygame.draw.rect(scr, (233, 200, 130), (bar.x, bar.y, int(bar.w * level), bar.h))
            pygame.draw.rect(scr, col, bar, 2)
            kx = bar.x + int(bar.w * level)
            pygame.draw.rect(scr, col, (kx - 4, bar.y - 5, 8, bar.h + 10))
        box = pygame.Surface(icon.size, pygame.SRCALPHA)
        box.fill((22, 20, 36, 200))
        scr.blit(box, icon.topleft)
        x, y = icon.x + 8, icon.centery
        pygame.draw.polygon(scr, col, [(x, y - 5), (x + 6, y - 5), (x + 13, y - 11), (x + 13, y + 11), (x + 6, y + 5), (x, y + 5)])
        if level <= 0:
            pygame.draw.line(scr, (236, 110, 100), (x + 17, y - 6), (x + 28, y + 6), 3)
            pygame.draw.line(scr, (236, 110, 100), (x + 28, y - 6), (x + 17, y + 6), 3)
        else:
            pygame.draw.arc(scr, col, (x + 8, y - 8, 14, 16), -1.1, 1.1, 2)
            if level > 0.5:
                pygame.draw.arc(scr, col, (x + 8, y - 13, 22, 26), -1.0, 1.0, 2)

    def update(self, dt):
        self.dt = dt
        self.vol_t = max(0.0, self.vol_t - dt)
        if self.toast:
            self.toast[1] -= dt
            if self.toast[1] <= 0:
                self.toast = None
        if self.back and self.state != "title":
            self.back = False
            self.audio.stop_all(400)
            self.reset()
            return
        if self.dialog:
            self.dialog.update(dt, self.confirm)
        if self.scene:
            self.scene.update(dt)
        if self.script:
            # khi dang co hoi thoai thi phim xac nhan thuoc ve hoi thoai
            if self.dialog:
                self.confirm = False
            try:
                next(self.script)
            except StopIteration:
                self.script = None

    def draw(self):
        self.canvas.fill((0, 0, 0))
        if self.scene:
            self.scene.draw(self.canvas)
        if self.scene is not None and getattr(self.scene, "wide_view", False):
            self.draw_wide(self.scene)
            self.apply_grey()
            self.draw_ui(self.screen)
            return
        if self.closeup:
            img, k = self.closeup
            c = self.canvas
            ov = pygame.Surface((W, H))
            v = int(255 * (1 - 0.65 * k))
            ov.fill((v, v, v))
            c.blit(ov, (0, 0), special_flags=pygame.BLEND_MULT)
            im = img.copy()
            im.set_alpha(int(255 * k))
            y = int(30 + (1 - k) * 20 + math.sin(pygame.time.get_ticks() / 600.0) * 1.5)
            c.blit(im, (W // 2 - im.get_width() // 2, y))
        pygame.transform.scale(self.canvas, (WIN_W, WIN_H), self.screen)
        self.apply_grey()
        self.draw_ui(self.screen)

    def apply_grey(self):
        """Mo dan mau cua nhung ngay giong nhau."""
        if self.grey > 0:
            g = pygame.transform.grayscale(self.screen)
            g.set_alpha(int(255 * clamp(self.grey, 0, 1)))
            self.screen.blit(g, (0, 0))

    def draw_wide(self, sc):
        """Cat 1 phan canvas theo camera, phong to 6 lan (canh ngoai troi)."""
        cam = sc.cam if sc.cam is not None else sc.me.x + 28
        left = int(clamp(cam - OUT_VW / 2, 0, sc.world_w - OUT_VW))
        view = self.canvas.subsurface((left, sc.cam_top, OUT_VW, OUT_VH))
        pygame.transform.scale(view, self.wide.get_size(), self.wide)
        self.screen.blit(self.wide, (-(self.wide.get_width() - WIN_W) // 2, 0))
        tint = getattr(sc, "tint_hi", None)
        if tint is not None:
            self.screen.blit(tint, (0, 0), special_flags=pygame.BLEND_MULT)
        if self.closeup:
            img, k = self.closeup
            ov = pygame.Surface((WIN_W, WIN_H))
            v = int(255 * (1 - 0.65 * k))
            ov.fill((v, v, v))
            self.screen.blit(ov, (0, 0), special_flags=pygame.BLEND_MULT)
            im = pygame.transform.scale(img, (img.get_width() * SCALE, img.get_height() * SCALE))
            im.set_alpha(int(255 * k))
            y = int(30 + (1 - k) * 20 + math.sin(pygame.time.get_ticks() / 600.0) * 1.5) * SCALE
            self.screen.blit(im, (WIN_W // 2 - im.get_width() // 2, y))

    def draw_ui(self, scr):
        f = self.fonts
        if self.toast and self.state == "play":
            t = f.hint.render("Nhớ lại: " + self.toast[0], True, (36, 30, 40))
            w = t.get_width() + 36
            x = WIN_W // 2 - w // 2
            pygame.draw.rect(scr, (233, 200, 130), (x, 134, w, 42), border_radius=6)
            pygame.draw.rect(scr, (120, 90, 60), (x, 134, w, 42), 3, border_radius=6)
            scr.blit(t, (x + 18, 155 - t.get_height() // 2))
        if self.stamp:
            self.shadow_text(scr, f.cap_sub, self.stamp, (240, 232, 214), WIN_W // 2, 30, off=2)
        if self.minigame:
            self.minigame.draw(scr, f)
        if self.scene is not None and hasattr(self.scene, "draw_hud"):
            self.scene.draw_hud(scr, f)
        if self.state == "title":
            self.draw_title(scr, f)
        elif self.state == "end":
            self.draw_end(scr, f)
        white = self.fade_col != (0, 0, 0)
        if self.dialog and not white:
            self.draw_dialog(scr, f, self.dialog)
        if self.choice:
            self.draw_choice(scr, f, self.choice)
        if self.hint:
            surf = f.hint.render(self.hint, True, (245, 238, 220))
            w = surf.get_width() + 40
            box = pygame.Surface((w, 44), pygame.SRCALPHA)
            box.fill((20, 18, 32, 200))
            x = WIN_W // 2 - w // 2
            y = WIN_H - 70 if not self.minigame else 440
            scr.blit(box, (x, y))
            pygame.draw.rect(scr, (233, 220, 192), (x, y, w, 44), 2)
            scr.blit(surf, (x + 20, y + 22 - surf.get_height() // 2))
        if self.fade_a > 0.001:
            ov = pygame.Surface((WIN_W, WIN_H))
            ov.fill(self.fade_col)
            ov.set_alpha(int(255 * self.fade_a))
            scr.blit(ov, (0, 0))
        if self.dialog and white:
            self.draw_dialog(scr, f, self.dialog)
        if self.caption:
            text, sub, a = self.caption
            t1 = f.cap.render(text, True, (64, 52, 48) if white else (240, 232, 214))
            t1.set_alpha(int(255 * a))
            scr.blit(t1, (WIN_W // 2 - t1.get_width() // 2, WIN_H // 2 - 50))
            if sub:
                t2 = f.cap_sub.render(sub, True, (168, 104, 44) if white else (240, 170, 90))
                t2.set_alpha(int(255 * a))
                scr.blit(t2, (WIN_W // 2 - t2.get_width() // 2, WIN_H // 2 + 16))
        self.draw_volume(scr)

    def shadow_text(self, scr, font, text, col, cx, y, shadow=(20, 16, 30), off=4):
        s = font.render(text, True, shadow)
        t = font.render(text, True, col)
        scr.blit(s, (cx - t.get_width() // 2 + off, y + off))
        scr.blit(t, (cx - t.get_width() // 2, y))

    def donate_image(self, height):
        """Anh QR ung ho, tai 1 lan. Tra ve None neu thieu file."""
        if not hasattr(self, "_donate_img"):
            try:
                img = pygame.image.load(resource_path(os.path.join("assets", "donate_qr.png"))).convert()
                w = img.get_width() * height // img.get_height()
                self._donate_img = pygame.transform.smoothscale(img, (w, height))
            except (pygame.error, OSError):
                self._donate_img = None
        return self._donate_img

    def draw_donate(self, scr, f):
        cx = WIN_W // 2
        dim = pygame.Surface((WIN_W, WIN_H), pygame.SRCALPHA)
        dim.fill((16, 16, 30, 235))
        scr.blit(dim, (0, 0))
        img = self.donate_image(620)
        if img:
            scr.blit(img, (cx - 500, 36))
            pygame.draw.rect(scr, (233, 220, 192), (cx - 500, 36, img.get_width(), 620), 2)
        rx = cx + 270
        self.shadow_text(scr, f.cap_sub, "Ủng hộ tôi", (240, 176, 100), rx, 170, off=2)
        lines = ["Nếu bạn thấy game hay,", "hãy ủng hộ tôi để tôi có động lực",
                 "để phát triển tiếp."]
        for i, line in enumerate(lines):
            self.shadow_text(scr, f.text, line, (236, 232, 220), rx, 270 + i * 50, off=2)
        self.shadow_text(scr, f.hint, "Quét mã QR bằng app ngân hàng.", (200, 190, 170), rx, 470, off=2)
        self.shadow_text(scr, f.hint, "Cảm ơn bạn rất nhiều!", (233, 200, 130), rx, 520, off=2)
        self.shadow_text(scr, f.small, "Enter / Esc: quay lại", (170, 170, 190), cx, 680, off=2)

    def draw_title(self, scr, f):
        if self.menu and self.menu["kind"] == "donate":
            self.draw_donate(scr, f)
            return
        cx = WIN_W // 2
        top = 40 if (self.menu and self.menu["kind"] != "main") else 90
        long_menu = bool(self.menu and self.menu["kind"] != "main" and len(self.menu["items"]) > 7)
        if not long_menu:
            self.shadow_text(scr, f.title, "THE TICKET", (246, 232, 200), cx, top, off=6)
        if top == 90:
            self.shadow_text(scr, f.cap_sub, "một chuyến xe lúc 11:11", (240, 176, 100), cx, 232, off=2)
        m = self.menu
        if m and m["kind"] == "main":
            y0 = 456
            for i, it in enumerate(m["items"]):
                sel = i == m["idx"]
                y = y0 + i * 52
                if sel:
                    tw = f.text.size(it[1])[0] + 60
                    pygame.draw.rect(scr, (233, 200, 130), (cx - tw // 2, y - 4, tw, 48))
                    t = f.text.render(it[1], True, (36, 30, 40))
                    scr.blit(t, (cx - t.get_width() // 2, y))
                else:
                    self.shadow_text(scr, f.text, it[1], (226, 222, 212), cx, y, off=2)
            self.shadow_text(scr, f.small, "Nếu bạn thấy game hay, hãy ủng hộ tôi để tôi có động lực để phát triển tiếp",
                             (240, 176, 100), cx, y0 + len(m["items"]) * 52, off=2)
            tip = "↑ ↓  chọn  ·  Enter  ·  F11: toàn màn hình  ·  M: tắt tiếng  ·  Esc: thoát"
        elif m:
            n = len(m["items"])
            ph = 40 + n * 54
            py = 110 if long_menu else 250
            self.shadow_text(scr, f.cap_sub, m["title"], (240, 176, 100), cx, py - 50, off=2)
            panel = pygame.Surface((760, ph), pygame.SRCALPHA)
            panel.fill((16, 16, 30, 215))
            scr.blit(panel, (cx - 380, py))
            pygame.draw.rect(scr, (233, 220, 192), (cx - 380, py, 760, ph), 2)
            for i, it in enumerate(m["items"]):
                sel = i == m["idx"]
                off = it[0] is None
                y = py + 20 + i * 54
                if sel:
                    pygame.draw.rect(scr, (120, 116, 130) if off else (233, 200, 130), (cx - 366, y - 4, 732, 50))
                col = (36, 30, 40) if sel else ((120, 120, 132) if off else (236, 232, 220))
                sub = (60, 56, 66) if sel else ((130, 130, 145) if off else (160, 160, 175))
                scr.blit(f.text.render(it[1], True, col), (cx - 346, y))
                t = f.small.render(it[2], True, sub)
                scr.blit(t, (cx + 346 - t.get_width(), y + 8))
            if m["kind"] == "chapters":
                tip = "↑ ↓  chọn chương  ·  Enter: xem các cảnh  ·  Esc: quay lại"
            else:
                tip = "↑ ↓  chọn cảnh  ·  Enter: chơi từ cảnh này  ·  Esc: quay lại"
        else:
            tip = ""
        self.shadow_text(scr, f.small, tip, (170, 170, 190), cx, 690, off=2)

    def draw_end(self, scr, f):
        cx = WIN_W // 2
        self.shadow_text(scr, f.title, "THE TICKET", (246, 232, 200), cx, 90, off=6)
        self.shadow_text(scr, f.cap_sub, "Cảm ơn bạn đã đi cùng chuyến xe này.", (240, 176, 100), cx, 232, off=2)
        if self.memories:
            self.shadow_text(scr, f.hint, "Những điều bạn đã nhớ lại", (230, 226, 216), cx, 300, off=2)
            for i, name in enumerate(self.memories):
                col = cx - 330 if i < 7 else cx + 330
                row = i if i < 7 else i - 7
                self.shadow_text(scr, f.small, name, (200, 190, 170), col, 350 + row * 34, off=2)
        self.shadow_text(scr, f.small, "G: gửi góp ý cho game", (240, 176, 100), cx, 586, off=2)
        self.shadow_text(scr, f.small, "Enter: về màn hình tiêu đề", (170, 170, 190), cx, 620, off=2)

    def draw_choice(self, scr, f, ch):
        x, y, w, h = 60, 604, WIN_W - 120, 106
        box = pygame.Surface((w, h), pygame.SRCALPHA)
        box.fill((22, 26, 44, 225))
        scr.blit(box, (x, y))
        pygame.draw.rect(scr, (233, 220, 192), (x, y, w, h), 4)
        scr.blit(f.thought.render(ch["prompt"], True, (186, 198, 236)), (x + 40, y + 12))
        ox = x + 40
        for i, opt in enumerate(ch["opts"]):
            sel = i == ch["idx"]
            t = f.text.render(opt, True, (36, 30, 40) if sel else (230, 224, 210))
            bw = t.get_width() + 56
            r = pygame.Rect(ox, y + 56, bw, 40)
            if sel:
                pygame.draw.rect(scr, (233, 200, 130), r)
                pygame.draw.polygon(scr, (36, 30, 40), [(ox + 14, y + 66), (ox + 14, y + 86), (ox + 26, y + 76)])
            else:
                pygame.draw.rect(scr, (90, 84, 110), r, 2)
            scr.blit(t, (ox + 36, y + 76 - t.get_height() // 2))
            ox += bw + 24
        hint = f.small.render("← →  chọn    Enter  xác nhận", True, (150, 150, 170))
        scr.blit(hint, (x + w - hint.get_width() - 24, y + 66))

    def draw_dialog(self, scr, f, d):
        x, y, w, h = 60, 604, WIN_W - 120, 106
        box = pygame.Surface((w, h), pygame.SRCALPHA)
        box.fill((22, 20, 36, 232) if not d.thought else (22, 26, 44, 205))
        scr.blit(box, (x, y))
        border = (233, 220, 192) if not d.thought else (150, 165, 205)
        pygame.draw.rect(scr, border, (x, y, w, h), 4)
        pygame.draw.rect(scr, (70, 62, 80), (x + 6, y + 6, w - 12, h - 12), 2)
        if d.name:
            ns = f.name.render(d.name, True, (36, 30, 40))
            nw = ns.get_width() + 30
            pygame.draw.rect(scr, (233, 200, 130), (x + 24, y - 22, nw, 40))
            pygame.draw.rect(scr, (120, 90, 60), (x + 24, y - 22, nw, 40), 3)
            scr.blit(ns, (x + 39, y - 2 - ns.get_height() // 2))
        font = f.thought if d.thought else f.text
        col = (186, 198, 236) if d.thought else (244, 238, 224)
        shown = d.text[:int(d.shown)]
        lines = wrap(font, d.text, w - 80)
        # cat theo so ky tu da hien
        left = len(shown)
        ty = y + 14
        for ln in lines:
            if left <= 0:
                break
            part = ln[:left]
            left -= len(ln) + 1
            scr.blit(font.render(part, True, col), (x + 40, ty))
            ty += 40
        if d.shown >= len(d.text) and int(d.age * 3) % 2 == 0:
            ax, ay = x + w - 34, y + h - 22
            pygame.draw.polygon(scr, border, [(ax - 9, ay - 5), (ax + 9, ay - 5), (ax, ay + 5)])

    async def run(self):
        while True:
            dt = min(self.clock.tick(FPS) / 1000.0, 1 / 20.0)
            if not self.handle_events():
                break
            self.update(dt)
            self.draw()
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()


async def main():
    try:
        await Game().run()
    except Exception:
        import traceback
        log = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "the-ticket-error.txt")
        with open(log, "w", encoding="utf-8") as fh:
            traceback.print_exc(file=fh)
        raise


if __name__ == "__main__":
    asyncio.run(main())
